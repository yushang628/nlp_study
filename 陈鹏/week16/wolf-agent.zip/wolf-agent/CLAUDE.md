# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

AI 狼人杀 — 基于 LLM 的多智能体博弈系统。每个角色（狼人、预言家、女巫、猎人、村民）拥有独立 Agent，在严格信息隔离下通过 LLM 生成发言、逻辑推理和决策。游戏结束后自动复盘总结、保存经验。

## 启动命令

```bash
# 后端服务（必须从项目根目录启动，因为使用 backend.xxx 包导入路径）
python -m backend.main serve         # FastAPI 服务模式，端口 8000
python -m backend.main               # CLI 模式，运行一局完整游戏

# 前端观战台
cd frontend && npm install && npm run dev   # Vue3 + Vite，端口 5173

# 自进化训练（独立模块，不在正常游戏流程中）
cd advanced/self_improvement
python main.py --iterations 10 --games 100 --method evolutionary              # 纯启发式快速训练
python main.py --iterations 5 --games 50 --method evolutionary --use-llm      # LLM 真实对局训练
```

配置：`cp .env.example .env`，填入通义千问 API Key。优先级：环境变量 > .env 文件 > 代码默认值。

## 架构

```
前端 Vue3 ← WebSocket ← FastAPI ← GameEngine（状态机） ← Agents ← LLM（通义千问）
                                              ↕                  ↕
                                            ActionValidator      MemoryStore（Chroma，可选）
                                              ↕                  ↕
                                            WinChecker           ExperienceStore（JSON）
```

核心流程：`GameEngine.run()` 驱动状态机日夜循环 → `PhaseExecutor` 按固定顺序执行阶段 → 每个 Agent 通过 `get_private_context()` 获取角色允许的信息 → LLM 做决策 → `ActionValidator` 校验合法性 → 执行并广播事件 → `WinChecker` 判定胜负 → `SummaryAgent` 自动复盘保存经验。

### 信息隔离（核心不变量）

`GameState.get_private_context(player_id)` 是信息隔离的唯一入口：
- 狼人能看到同伴身份和狼人夜间行动
- 预言家能看到自己的查验历史
- 女巫能看到被杀玩家信息
- 其他角色只看到公开信息（发言、投票、死亡、存活列表）
- **严禁在 Agent 间泄露角色私有信息**

### 狼人协商机制

多狼场景下两轮协商：每只狼提议击杀目标 → 共享提议 → 再次决策投票 → 多数票确定目标。平票随机选。单狼直接 LLM 决策。`WerewolfAgent.decide_wolf_target()` 处理提议和最终决策。

### 女巫双药互斥

同一夜不能同时使用解药和毒药。`ActionValidator._validate_witch_heal/poison()` 通过 `witch_healed_this_round` / `witch_poisoned_this_round` 标记强制互斥。女巫不能自救（`target == player_id` 时校验失败）。被毒杀的猎人技能锁定（`hunter_can_shoot = False`）。

### 策略参数系统

`StrategyParams` 定义 6 个可调参数（suspicion_threshold、herd_tendency、wolf_aggression、god_claim_tendency、speech_detail_level、memory_weight），影响 Agent 行为：
- `herd_tendency` 控制投票从众概率（`BaseAgent.decide_vote()`）
- `wolf_aggression > 0.7` 时狼人优先击杀神职而非村民（`WerewolfAgent`）
- `god_claim_tendency < 0.3` 时预言家发言隐藏身份（`SeerAgent.decide_speech()`）

参数支持 `mutate()` 变异和 `crossover()` 交叉，用于自进化训练的进化搜索。

### 经验积累

游戏结束后 `SummaryAgent` 为每位玩家生成结构化复盘 → 按角色保存到 `data/experiences/{role}.json` → 最多保留 50 条 → 下局游戏通过 `get_experience_prompt()` 注入 Agent 的 System Prompt。

## 关键文件

| 文件 | 核心逻辑 |
|------|---------|
| `backend/engine/state.py` | 所有数据模型：Role/Camp/Phase 枚举、PlayerState、GameState、NightAction、SpeechRecord、VoteRecord、GameEvent、ROLE_CONFIGS |
| `backend/engine/phase.py` | PhaseExecutor：夜（wolf→seer→witch）→日（speech→vote）→结算夜间死亡→猎人开枪→平票PK随机 |
| `backend/engine/game_engine.py` | GameEngine：状态机主循环，游戏结束触发 SummaryAgent 复盘 |
| `backend/engine/action_validator.py` | 校验所有行动合法性，双药互斥、女巫不能自救、被毒猎人闷枪 |
| `backend/engine/win_checker.py` | 所有狼人死亡=好人胜，狼人>=好人=邪恶胜 |
| `backend/agents/base_agent.py` | BaseAgent：observe→think→act，注入经验 + 向量记忆回溯，策略参数影响投票/发言 |
| `backend/agents/werewolf_agent.py` | 狼人协商两轮决策 + 侵略性策略 |
| `backend/agents/seer_agent.py` | 预言家查验回退逻辑 + god_claim_tendency 控制发言是否隐藏身份 |
| `backend/llm/client.py` | OpenAI 兼容客户端，chat_json 使用 `response_format={"type":"json_object"}` 获取结构化决策 |
| `backend/llm/prompts.py` | 角色 System Prompt + 阶段 Prompt 模板（夜行动/发言/投票/猎人开枪/狼人协商） |
| `backend/memory/experience.py` | JSON 经验存储，按角色类型分文件，最多 50 条，自动注入 System Prompt |
| `backend/memory/store.py` | Chroma 向量记忆（可选，未安装 chromadb 时自动禁用） |
| `backend/agents/summary_agent.py` | 复盘 Agent：LLM 生成结构化总结 → 保存每位玩家经验 |

## 角色配置

| 配置名 | 角色 |
|--------|------|
| `simple_4` | 1狼人、1预言家、1女巫、1村民 |
| `standard_6` | 2狼人、1预言家、1女巫、1猎人、1村民 |
| `big_9` | 3狼人、1预言家、1女巫、1猎人、3村民 |

## API

- REST：`POST /api/games`（创建）、`POST /api/games/{id}/start`（开始）、`GET /api/games/{id}`（状态）、`GET /api/games/{id}/log`（日志）
- WebSocket：`ws://localhost:8000/ws/game/{game_id}`，事件类型包括 phase_change、speech、vote_result、death、skill、hunter_shoot、game_summary、game_over、wolf_negotiate
- 前端 Vite 代理：`/api` → `http://127.0.0.1:8000`，`/ws` → `ws://127.0.0.1:8000`

## 自进化训练模块

`advanced/self_improvement/` 是独立训练闭环：对局 → 分析胜负 → 优化策略参数 → 再对局。4 种优化方法：evolutionary（进化搜索，推荐）、random、grid、reinforce。纯启发式模式不调 LLM 可秒级完成，LLM 模式更准确但慢。输出目录：`data/self_improvement/`。

## 注意事项

- **包导入路径**：项目使用 `backend.xxx` 包路径，必须从项目根目录用 `python -m backend.main` 启动，不能 cd 到 backend 后直接 `python main.py`
- **LLM JSON 输出**：所有 Agent 决策依赖 LLM 返回合法 JSON，`LLMClient.chat_json()` 有容错解析（提取 `{...}` 段），但非法 JSON 仍会导致回退逻辑（如随机目标）
- **游戏事件广播**：`PhaseExecutor._emit()` 同时写入 `game.events` 和 `self.events`，`GameEngine._flush_events()` 在日夜阶段结束后统一推送
- **平票处理**：当前简化为随机淘汰，未实现完整 PK 发言再投票流程
- **无测试文件**：项目目前没有单元测试