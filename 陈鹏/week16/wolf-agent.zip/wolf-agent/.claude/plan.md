# Wolf Agent Implementation Plan

## Context

Based on README.md and the existing `evo-werewolf-agent` project, we need to build a full AI werewolf game system with:
- FastAPI + WebSocket backend
- Multi-agent system with information isolation
- LLM-powered speech & reasoning
- Vector memory (Chroma)
- Vue 3 frontend
- Self-improvement loop (direction ③)

## Phase 1: Backend Core — Engine & Data Models

### 1.1 Project structure
```
wolf-agent/
├── backend/
│   ├── main.py                    # FastAPI app entry
│   ├── config.py                  # Settings (pydantic-settings)
│   ├── requirements.txt
│   ├── engine/
│   │   ├── __init__.py
│   │   ├── game_engine.py         # State machine: night→day→vote→check win
│   │   ├── state.py               # GameState, PlayerState, Phase enum
│   │   ├── phase.py               # Phase executor (night_actions, day_speech, vote)
│   │   ├── action_validator.py    # Validate skill usage per role
│   │   └── win_checker.py         # Win condition evaluation
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── base_agent.py          # Abstract base: observe() → think() → act()
│   │   ├── werewolf_agent.py
│   │   ├── seer_agent.py
│   │   ├── witch_agent.py
│   │   ├── hunter_agent.py
│   │   └── villager_agent.py
│   ├── llm/
│   │   ├── __init__.py
│   │   ├── client.py              # OpenAI-compatible LLM client
│   │   └── prompts.py             # Role-specific prompt templates
│   ├── memory/
│   │   ├── __init__.py
│   │   └── store.py               # Chroma vector store for game memory
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py              # REST endpoints
│   │   ├── websocket.py           # WebSocket game room
│   │   └── models.py              # Pydantic schemas
│   └── logs/
│       └── game_logger.py         # Structured JSON logger
├── frontend/                      # Phase 3
└── advanced/                      # Phase 4: self-improvement
```

### 1.2 State model (engine/state.py)
- `Role` enum: WEREWOLF, SEER, WITCH, HUNTER, VILLAGER
- `Phase` enum: NIGHT_START, WOLF_TURN, SEER_TURN, WITCH_TURN, NIGHT_END, DAY_START, SPEECH, VOTE, DAY_END, GAME_OVER
- `PlayerState`: player_id, name, role, alive, protected, poisoned
- `GameState`: players, phase, round_num, current_speaker, vote_results, night_actions, winner

### 1.3 Game engine (engine/game_engine.py)
- State machine driving phase transitions
- `start_game()` → `next_phase()` → ... → `check_win()`
- Event-based: emits events for WebSocket broadcast
- Strict phase ordering enforced

### 1.4 Phase executor (engine/phase.py)
- `execute_night()`: wolf kill → seer check → witch save/poison
- `execute_day()`: speech round → vote → eliminate
- Each step calls agent.act() and validates via action_validator

### 1.5 Action validator (engine/action_validator.py)
- Per-role skill validation (alive? correct phase? target valid? already used?)
- Witch: antidote/poison each usable once per game
- Seer: check one alive non-self player per night
- Hunter: shoot on death only

### 1.6 Win checker (engine/win_checker.py)
- Werewolf wins: wolves >= villagers
- Good side wins: all wolves eliminated

## Phase 2: Agents & LLM

### 2.1 Base agent (agents/base_agent.py)
```python
class BaseAgent(ABC):
    def __init__(self, player_id, role, llm_client, memory):
        self.player_id = player_id
        self.role = role
        self.llm = llm_client
        self.memory = memory
        self.knowledge = []  # what this agent knows

    @abstractmethod
    async def act(self, game_state: GameState, phase: Phase) -> Action:
        """Observe → Think → Act cycle"""

    def receive_info(self, info: dict):
        """Receive role-specific info (maintains isolation)"""

    async def generate_speech(self, context: str) -> str:
        """LLM-generated speech"""
```

### 2.2 Role agents — each with specialized prompts & strategies
- **WerewolfAgent**: coordinate kills at night, deceive during day, defend teammates subtly
- **SeerAgent**: decide who to investigate, when to reveal info
- **WitchAgent**: decide save/poison usage timing
- **HunterAgent**: decide shoot target on death
- **VillagerAgent**: analyze speeches, identify wolves

### 2.3 LLM client (llm/client.py)
- OpenAI-compatible (dashscope/qwen)
- Structured output for decisions (JSON mode)
- Retry + timeout handling

### 2.4 Prompts (llm/prompts.py)
- Role-specific system prompts
- Phase-specific user prompts
- Strategy hints embedded in prompts

## Phase 3: API & WebSocket

### 3.1 REST API (api/routes.py)
- POST /api/games — create game
- GET /api/games/{id} — game state
- POST /api/games/{id}/start — start game
- GET /api/games/{id}/log — game log

### 3.2 WebSocket (api/websocket.py)
- /ws/game/{id} — real-time game events
- Broadcast: phase changes, speeches, votes, eliminations
- Client can observe (no manual control — agents play autonomously)

## Phase 4: Memory & Logging

### 4.1 Vector memory (memory/store.py)
- Store speech embeddings per player
- Retrieve relevant past speeches for context
- Long-term role memory across games

### 4.2 Game logger (logs/game_logger.py)
- Structured JSON per round
- All events: speeches, votes, skills, state transitions
- Enables replay and analysis

## Phase 5: Frontend (Vue 3)

- Game lobby + game board
- Real-time WebSocket updates
- Player cards with role reveal (when eliminated)
- Speech bubbles, vote display, night/day visual toggle
- Game log timeline

## Phase 6: Self-Improvement Loop

### 6.1 Strategy parameters
Each agent has tunable params: suspicion_threshold, herd_tendency, aggression, deception_level

### 6.2 Play → Analyze → Optimize loop
1. Run N games with current params
2. Analyze win rates per role
3. Adjust params via grid search or REINFORCE
4. Validate with 500-game convergence curve

### 6.3 Benchmark framework (advanced/benchmark/)
- Automated game runner
- Win rate statistics
- Replay from logs
- Leaderboard

## Implementation Order

1. **engine/state.py** — data models first
2. **engine/action_validator.py** — rules
3. **engine/win_checker.py** — win conditions
4. **llm/client.py** + **llm/prompts.py** — LLM layer
5. **agents/base_agent.py** — base class
6. **agents/{werewolf,seer,witch,hunter,villager}_agent.py** — role agents
7. **engine/phase.py** — phase execution (uses agents)
8. **engine/game_engine.py** — state machine (uses phases)
9. **logs/game_logger.py** — logging
10. **memory/store.py** — vector memory
11. **api/models.py** + **api/routes.py** + **api/websocket.py** — API
12. **main.py** + **config.py** — app entry
13. Frontend (Phase 5)
14. Self-improvement (Phase 6)
