# AI 狼人杀 Agent

基于 LLM 的狼人杀智能体对战系统，支持多角色 Agent 自动对局、复盘总结、经验积累与自进化训练。

## 项目结构

```
wolf-agent/
├── backend/                        # 后端服务
│   ├── agents/                     # Agent 实现
│   │   ├── base_agent.py           # 基础 Agent（含经验注入）
│   │   ├── werewolf_agent.py       # 狼人 Agent（含狼协商）
│   │   ├── seer_agent.py           # 预言家 Agent
│   │   ├── witch_agent.py          # 女巫 Agent
│   │   ├── hunter_agent.py         # 猎人 Agent
│   │   ├── villager_agent.py       # 村民 Agent
│   │   └── summary_agent.py        # 复盘总结 Agent
│   ├── engine/                     # 游戏引擎
│   │   ├── game_engine.py          # 主引擎（状态机 + 自动复盘）
│   │   ├── phase.py                # 日夜阶段执行 + PK 机制
│   │   ├── state.py                # 游戏状态 & 角色配置 (simple_4/standard_6/big_9)
│   │   ├── action_validator.py     # 行动校验器（含女巫双药互斥）
│   │   └── win_checker.py          # 胜负判定器
│   ├── api/                        # API 层
│   │   ├── routes.py               # REST 接口
│   │   ├── websocket.py            # WebSocket 实时推送
│   │   └── models.py               # 请求/响应模型
│   ├── llm/                        # LLM 抽象层
│   │   ├── client.py               # 统一 LLM 客户端
│   │   └── prompts.py              # Prompt 模板管理
│   ├── memory/                     # 记忆系统
│   │   ├── store.py                # Chroma 向量记忆
│   │   └── experience.py           # JSON 经验存储
│   ├── logs/                       # 日志
│   │   └── game_logger.py          # 结构化游戏日志
│   ├── config/                     # 配置（已迁移到根目录 .env）
│   ├── config.py                   # 配置加载（env > json > 默认值）
│   └── main.py                     # 服务入口
├── advanced/                       # 自进化模块
│   └── self_improvement/
│       ├── main.py                 # 训练 CLI 入口
│       ├── batch_runner.py         # 批量对局运行
│       ├── analyzer.py             # 对局数据分析
│       ├── optimizer.py            # LLM 策略优化器
│       ├── trainer.py              # 训练循环 + 收敛曲线
│       └── strategy_params.py      # 可调策略参数
├── frontend/                       # 前端观战台 (Vue3 + Vite)
│   ├── src/
│   │   ├── App.vue
│   │   ├── api.js
│   │   ├── components/
│   │   │   ├── GameBoard.vue       # 游戏面板
│   │   │   ├── GameLog.vue         # 日志面板
│   │   │   ├── GameSetup.vue       # 创建游戏
│   │   │   ├── PlayerCard.vue      # 玩家卡片
│   │   │   ├── SpeechPanel.vue      # 发言面板
│   │   │   └── VotePanel.vue        # 投票面板
│   │   ├── main.js
│   │   └── style.css
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── requirements.txt
├── CLAUDE.md
└── README.md
```

## 快速开始

以下为 Windows 环境（Python 3.12）的操作步骤。

### 1. 环境准备

```powershell
# 进入项目目录


# 激活 conda 环境（已有 py312）
conda activate py312

# 安装依赖
pip install -r requirements.txt
```

### 2. 配置 API Key

复制 `.env.example` 为 `.env`，填上你的通义千问 Key：

```powershell
copy .env.example .env
```

编辑 `.env`：

```
API_KEY=sk-你的dashscope-key
BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

优先级：环境变量 > `.env` 文件 > 代码默认值。

### 3. 启动后端服务

```powershell
# 在项目根目录下运行
python -m backend.main
```

服务默认运行在 `http://localhost:8000`，可在 `system_config.json` 中修改 `host` 和 `port`。

启动成功后会看到：

```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
```

> **注意**：因为项目使用 `backend.xxx` 的包导入路径，必须从项目根目录用 `python -m backend.main` 启动，不能 cd 到 backend 目录后直接 `python main.py`。

### 4. 启动前端（可选）

```powershell
cd frontend
npm install
npm run dev
```

前端默认运行在 `http://localhost:5173`，浏览器打开即可观战。

### 5. 快速测试（不需要前端）

启动后端后，用 curl 或 PowerShell 测试：

```powershell
# 创建标准6人局
Invoke-RestMethod -Uri "http://localhost:8000/game/create" -Method Post -ContentType "application/json" -Body '{"config":"standard_6"}'

# 创建标准9人局
Invoke-RestMethod -Uri "http://localhost:8000/game/create" -Method Post -ContentType "application/json" -Body '{"config":"big_9"}'

# 开始游戏（game_id 替换为上面返回的 ID）
Invoke-RestMethod -Uri "http://localhost:8000/game/GAME_ID/start" -Method Post

# 查看游戏状态
Invoke-RestMethod -Uri "http://localhost:8000/game/GAME_ID/state"
```

`advanced/self_improvement/` 是独立的训练模块，不属于游戏正常流程，不需要日常启动。

它的作用是让 Agent 通过大量对局自动寻找更优策略参数：

```
批量对局 → 分析胜负数据 → 优化策略参数 → 再批量对局 → 重复 N 轮 → 输出收敛曲线
```

| 文件 | 作用 |
|------|------|
| `strategy_params.py` | 定义 6 个可调参数（怀疑阈值、从众倾向、狼人侵略性、神职声明倾向、发言详细度、记忆权重），支持变异和交叉 |
| `batch_runner.py` | 快速跑 100~500 局，支持纯启发式（不调 LLM，秒级完成）和 LLM 模式 |
| `analyzer.py` | 分析每局胜负，给关键决策打分 |
| `optimizer.py` | 4 种优化方法：进化搜索、随机搜索、网格搜索、强化学习式 |
| `trainer.py` | 主循环 + 输出收敛曲线图到 `data/self_improvement/` |
| `main.py` | CLI 入口，参数见下方 |

什么时候用：想让 Agent 自动学出更优策略时，手动跑一次即可。

```powershell
cd advanced\self_improvement

# 纯启发式快速训练（不调用 LLM，适合快速验证参数趋势）
python main.py --iterations 10 --games 100 --method evolutionary

# 使用 LLM 的真实对局训练（更准确，但很慢）
python main.py --iterations 5 --games 50 --method evolutionary --use-llm

# 强化学习式优化
python main.py --iterations 20 --games 100 --method reinforce

# 查看参数说明
python main.py --help
```

输出目录：`data/self_improvement/`，包含 `training_results.json` 和 `convergence_curve.png`。

## API 接口

### REST

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/game/create` | 创建游戏（指定角色配置） |
| POST | `/game/{game_id}/start` | 开始游戏 |
| GET | `/game/{game_id}/state` | 获取游戏状态 |
| GET | `/game/{game_id}/log` | 获取游戏日志 |

#### 创建游戏示例

```powershell
# 标准6人局
Invoke-RestMethod -Uri "http://localhost:8000/game/create" -Method Post -ContentType "application/json" -Body '{"config":"standard_6"}'

# 标准9人局
Invoke-RestMethod -Uri "http://localhost:8000/game/create" -Method Post -ContentType "application/json" -Body '{"config":"big_9"}'

# 自定义角色
Invoke-RestMethod -Uri "http://localhost:8000/game/create" -Method Post -ContentType "application/json" -Body '{"roles":["werewolf","werewolf","seer","witch","hunter","villager"]}'
```

### WebSocket

连接 `ws://localhost:8000/ws/{game_id}`，实时接收游戏事件：

- `game_start` — 游戏开始
- `phase_change` — 阶段切换
- `speech` — 发言
- `vote` — 投票
- `vote_eliminated` — 投票出局
- `pk_start` / `pk_result` — 平票 PK
- `night_death` — 夜晚死亡
- `hunter_shoot` — 猎人开枪
- `game_summary` — 复盘总结
- `game_over` — 游戏结束

## 角色配置

| 配置名 | 说明 | 角色组成 |
|--------|------|---------|
| `simple_4` | 简易4人局 | 1狼人、1预言家、1女巫、1村民 |
| `standard_6` | 标准6人局 | 2狼人、1预言家、1女巫、1猎人、1村民 |
| `big_9` | 标准9人局 | 3狼人、1预言家、1女巫、1猎人、3村民 |

## 核心功能

- **多角色 Agent** — 每个角色独立 Agent + 专属 Prompt，决策差异化
- **行动校验** — ActionValidator 确保所有操作合法（双药互斥、技能使用限制等）
- **复盘总结** — 游戏结束自动生成结构化复盘（关键决策、策略评价、改进建议）
- **经验积累** — 按角色存储游戏经验，自动注入 Agent 的 System Prompt
- **自进化训练** — 批量对局 → 数据分析 → LLM 策略优化 → 重新对局
- **WebSocket 实时推送** — 前端实时观看对局进程