"""行动校验器 — 校验角色技能使用是否合法"""

from typing import Optional, List

from .state import GameState, PlayerState, Role, Phase, NightAction


class ActionValidationError(Exception):
    """行动校验失败时抛出，包含具体原因"""
    pass


class ActionValidator:
    """每步行动前必须通过校验，确保信息隔离和游戏规则"""

    def validate_night_action(
        self,
        game: GameState,
        player: PlayerState,
        action_type: str,
        target: Optional[int] = None,
        *,
        used_heal_this_round: bool = False,
        used_poison_this_round: bool = False,
    ) -> None:
        if not player.alive:
            raise ActionValidationError(f"玩家 {player.name} 已死亡，无法行动")

        if game.phase not in (Phase.WOLF_TURN, Phase.SEER_TURN, Phase.WITCH_TURN):
            raise ActionValidationError(f"当前阶段 {game.phase.value} 不允许夜间行动")

        if action_type == "kill":
            self._validate_wolf_kill(game, player, target)
        elif action_type == "check":
            self._validate_seer_check(game, player, target)
        elif action_type == "heal":
            self._validate_witch_heal(game, player, target)
        elif action_type == "poison":
            self._validate_witch_poison(game, player, target)
        else:
            raise ActionValidationError(f"未知行动类型: {action_type}")

    def validate_vote(
        self,
        game: GameState,
        voter: PlayerState,
        target_id: int,
    ) -> None:
        if not voter.alive:
            raise ActionValidationError(f"玩家 {voter.name} 已死亡，无法投票")
        if game.phase != Phase.VOTE:
            raise ActionValidationError("当前阶段不是投票阶段")
        target = game.get_player(target_id)
        if not target or not target.alive:
            raise ActionValidationError(f"投票目标 {target_id} 不存在或已死亡")
        if voter.player_id == target_id:
            raise ActionValidationError("不能投自己")

    def validate_hunter_shoot(
        self,
        game: GameState,
        hunter: PlayerState,
        target_id: int,
    ) -> None:
        if hunter.role != Role.HUNTER:
            raise ActionValidationError("只有猎人可以开枪")
        if not hunter.hunter_can_shoot:
            raise ActionValidationError("猎人已被毒杀，无法开枪")
        target = game.get_player(target_id)
        if not target or not target.alive:
            raise ActionValidationError(f"射击目标 {target_id} 不存在或已死亡")

    def _validate_wolf_kill(self, game: GameState, player: PlayerState, target: Optional[int]) -> None:
        """校验狼人击杀：目标必须存活且非狼人"""
        if player.role != Role.WEREWOLF:
            raise ActionValidationError("只有狼人可以击杀")
        if game.phase != Phase.WOLF_TURN:
            raise ActionValidationError("不是狼人行动阶段")
        if target is None:
            raise ActionValidationError("击杀必须指定目标")
        target_player = game.get_player(target)
        if not target_player or not target_player.alive:
            raise ActionValidationError(f"击杀目标 {target} 不存在或已死亡")
        if target_player.role == Role.WEREWOLF:
            raise ActionValidationError("狼人不能击杀同伴")

    def _validate_seer_check(self, game: GameState, player: PlayerState, target: Optional[int]) -> None:
        """校验预言家查验：目标必须存活且不能查验自己"""
        if player.role != Role.SEER:
            raise ActionValidationError("只有预言家可以查验")
        if game.phase != Phase.SEER_TURN:
            raise ActionValidationError("不是预言家行动阶段")
        if target is None:
            raise ActionValidationError("查验必须指定目标")
        target_player = game.get_player(target)
        if not target_player or not target_player.alive:
            raise ActionValidationError(f"查验目标 {target} 不存在或已死亡")
        if target == player.player_id:
            raise ActionValidationError("不能查验自己")

    def _validate_witch_heal(self, game: GameState, player: PlayerState, target: Optional[int]) -> None:
        """校验女巫解药：不能自救、只能救被杀的人、双药互斥"""
        if player.role != Role.WITCH:
            raise ActionValidationError("只有女巫可以使用解药")
        if game.phase != Phase.WITCH_TURN:
            raise ActionValidationError("不是女巫行动阶段")
        if not player.witch_has_heal:
            raise ActionValidationError("解药已用完")
        if target == player.player_id:
            raise ActionValidationError("女巫不能对自己使用解药（不能自救）")
        if target != game.wolf_target:
            raise ActionValidationError("解药只能救今晚被杀的人")
        if player.witch_poisoned_this_round:
            raise ActionValidationError("同一夜不能同时使用解药和毒药")

    def _validate_witch_poison(self, game: GameState, player: PlayerState, target: Optional[int]) -> None:
        """校验女巫毒药：目标必须存活、双药互斥"""
        if player.role != Role.WITCH:
            raise ActionValidationError("只有女巫可以使用毒药")
        if game.phase != Phase.WITCH_TURN:
            raise ActionValidationError("不是女巫行动阶段")
        if not player.witch_has_poison:
            raise ActionValidationError("毒药已用完")
        if target is None:
            raise ActionValidationError("毒杀必须指定目标")
        target_player = game.get_player(target)
        if not target_player or not target_player.alive:
            raise ActionValidationError(f"毒杀目标 {target} 不存在或已死亡")
        if player.witch_healed_this_round:
            raise ActionValidationError("同一夜不能同时使用解药和毒药")
