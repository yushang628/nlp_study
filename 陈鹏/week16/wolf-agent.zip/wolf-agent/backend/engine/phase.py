"""阶段执行器 — 夜间行动、白天发言、投票

夜间顺序：狼人击杀→预言家查验→女巫用药→结算夜间死亡→猎人开枪
白天顺序：公布死亡→公开演讲→投票→结算投票→猎人开枪
多狼协商：提议→共享→再决策→多数票确定，平票随机
"""

import random
from typing import List, Optional, Dict

from .state import (
    GameState, Phase, Role, Camp, PlayerState,
    NightAction, SpeechRecord, VoteRecord, GameEvent,
    NIGHT_ORDER,
)
from .action_validator import ActionValidator, ActionValidationError
from .win_checker import WinChecker
from ..agents.base_agent import BaseAgent
from ..agents.werewolf_agent import WerewolfAgent
from ..agents.seer_agent import SeerAgent
from ..agents.witch_agent import WitchAgent
from ..agents.hunter_agent import HunterAgent
from ..agents.villager_agent import VillagerAgent
from ..llm.client import LLMClient


# 角色到 Agent 类的映射
AGENT_CLASS_MAP = {
    Role.WEREWOLF: WerewolfAgent,
    Role.SEER: SeerAgent,
    Role.WITCH: WitchAgent,
    Role.HUNTER: HunterAgent,
    Role.VILLAGER: VillagerAgent,
}


def create_agents(players: List[PlayerState], llm: LLMClient, memory=None, strategy_params=None) -> dict[int, BaseAgent]:
    agents: dict[int, BaseAgent] = {}
    for p in players:
        cls = AGENT_CLASS_MAP[p.role]
        agents[p.player_id] = cls(
            player_id=p.player_id, role=p.role, llm=llm,
            memory=memory, strategy_params=strategy_params,
        )
    return agents


class PhaseExecutor:
    """阶段执行器：驱动每个游戏阶段的具体逻辑"""
    def __init__(self, game: GameState, agents: dict[int, BaseAgent], validator: ActionValidator, memory=None):
        self.game = game
        self.agents = agents
        self.validator = validator
        self.memory = memory
        self.win_checker = WinChecker()
        self.events: List[GameEvent] = []

    def _emit(self, event_type: str, data: dict = None):
        event = GameEvent(
            event_type=event_type,
            data=data or {},
            day=self.game.round_num,
        )
        self.game.events.append(event)
        self.events.append(event)

    async def run_night(self) -> Optional[Camp]:
        """执行一整晚：狼人杀人→预言家查验→女巫用药→结算死亡→猎人开枪"""
        """执行一整晚：狼人杀人 → 预言家查验 → 女巫用药"""
        self.game.phase = Phase.NIGHT_START
        self._emit("phase_change", {"phase": "night_start", "day": self.game.round_num})

        self.game.night_actions = []
        self.game.wolf_target = None
        self.game.witch_heal_target = None
        self.game.witch_poison_target = None

        # 重置玩家夜间状态
        for p in self.game.players:
            p.witch_healed_this_round = False
            p.witch_poisoned_this_round = False

        # 1. 狼人击杀
        await self._wolf_turn()
        # 2. 预言家查验
        await self._seer_turn()
        # 3. 女巫行动
        await self._witch_turn()

        # 记录夜间行动到向量记忆
        if self.memory:
            for na in self.game.night_actions:
                player = self.game.get_player(na.player_id)
                if player:
                    self.memory.add_night_action(
                        game_id=self.game.game_id,
                        round_num=self.game.round_num,
                        player_id=na.player_id,
                        role=na.role.value,
                        action=f"{na.action_type} -> {na.target}" if na.target else na.action_type,
                    )

        # 结算夜间死亡
        deaths = self._resolve_night_deaths()

        # 猎人开枪
        winner = await self._handle_hunter_shoot(deaths)
        if winner:
            self.game.winner = winner
            self.game.phase = Phase.GAME_OVER
            self._emit("game_over", {"winner": winner.value})
            return winner

        winner = self.win_checker.check(self.game)
        if winner:
            self.game.winner = winner
            self.game.phase = Phase.GAME_OVER
            self._emit("game_over", {"winner": winner.value})
            return winner

        self.game.phase = Phase.NIGHT_END
        self._emit("phase_change", {"phase": "night_end"})
        return None

    async def run_day(self) -> Optional[Camp]:
        """执行白天：发言 → 投票 → 结算"""
        self.game.phase = Phase.DAY_START
        self._emit("phase_change", {"phase": "day_start", "day": self.game.round_num})

        # 公布夜间死亡（不透露死因）
        self._emit("night_deaths", {
            "deaths": self.game.night_deaths,
            "day": self.game.round_num,
        })

        # 发言阶段
        await self._speech_phase()

        # 投票阶段
        await self._vote_phase()

        # 结算投票
        eliminated_id = self._resolve_vote()

        # 猎人开枪
        if eliminated_id is not None:
            player = self.game.get_player(eliminated_id)
            if player and player.role == Role.HUNTER and player.hunter_can_shoot:
                winner = await self._execute_hunter_shoot(player)
                if winner:
                    return winner

        winner = self.win_checker.check(self.game)
        if winner:
            self.game.winner = winner
            self.game.phase = Phase.GAME_OVER
            self._emit("game_over", {"winner": winner.value})
            return winner

        self.game.phase = Phase.DAY_END
        self._emit("phase_change", {"phase": "day_end"})
        self.game.round_num += 1
        return None

    async def _wolf_turn(self):
        """狼人阶段：单狼直接决策，多狼两轮协商"""
        self.game.phase = Phase.WOLF_TURN
        self._emit("phase_change", {"phase": "wolf_turn"})

        wolves = [p for p in self.game.get_alive_players() if p.role == Role.WEREWOLF]
        if not wolves:
            return

        if len(wolves) == 1:
            # 单狼：直接用原有逻辑
            wolf_agent = self.agents[wolves[0].player_id]
            result = await wolf_agent.decide_night_action(self.game)
            target = result.get("target")
            if isinstance(target, int):
                try:
                    self.validator.validate_night_action(self.game, wolves[0], "kill", target)
                    self.game.wolf_target = target
                    self.game.night_actions.append(NightAction(
                        role=Role.WEREWOLF, player_id=wolves[0].player_id,
                        action_type="kill", target=target,
                        reasoning=result.get("reasoning", ""),
                    ))
                    self._emit("skill", {"role": "werewolf", "target": target})
                    return
                except ActionValidationError:
                    pass
        else:
            # 多狼协商：每只狼先提议 → 共享建议 → 再次决策 → 多数票
            # 第一轮：每只狼提议
            proposals = []
            for wolf in wolves:
                agent = self.agents[wolf.player_id]
                proposal = await agent.decide_wolf_target(self.game)
                if proposal:
                    proposals.append(proposal)

            self._emit("wolf_negotiate", {
                "phase": "proposal",
                "proposals": [{"player_id": p["player_id"], "target": p["target"]} for p in proposals],
            })

            # 第二轮：每只狼结合队友建议做最终决定
            final_votes: dict[int, int] = {}  # target_id -> count
            final_reasoning = ""
            for wolf in wolves:
                agent = self.agents[wolf.player_id]
                decision = await agent.decide_wolf_target(self.game, teammate_suggestions=proposals)
                if decision and isinstance(decision.get("target"), int):
                    t = decision["target"]
                    final_votes[t] = final_votes.get(t, 0) + 1
                    final_reasoning = decision.get("reasoning", "")

            self._emit("wolf_negotiate", {
                "phase": "decision",
                "votes": final_votes,
            })

            # 多数票确定目标
            if final_votes:
                max_count = max(final_votes.values())
                top_targets = [t for t, c in final_votes.items() if c == max_count]
                target = random.choice(top_targets)  # 平票随机选
                try:
                    self.validator.validate_night_action(self.game, wolves[0], "kill", target)
                    self.game.wolf_target = target
                    self.game.night_actions.append(NightAction(
                        role=Role.WEREWOLF, player_id=wolves[0].player_id,
                        action_type="kill", target=target,
                        reasoning=f"协商结果(票数:{final_votes}): {final_reasoning}",
                    ))
                    self._emit("skill", {"role": "werewolf", "target": target, "negotiation": True})
                    return
                except ActionValidationError:
                    pass

        # 回退：随机杀一个非狼人
        targets = [p for p in self.game.get_alive_players() if p.role != Role.WEREWOLF]
        if targets:
            t = random.choice(targets)
            self.game.wolf_target = t.player_id
            self.game.night_actions.append(NightAction(
                role=Role.WEREWOLF, player_id=wolves[0].player_id,
                action_type="kill", target=t.player_id, reasoning="随机回退",
            ))

    async def _seer_turn(self):
        """预言家阶段：查验一名玩家，获知其阵营"""
        self.game.phase = Phase.SEER_TURN
        self._emit("phase_change", {"phase": "seer_turn"})

        seer = next(
            (p for p in self.game.get_alive_players() if p.role == Role.SEER), None
        )
        if not seer:
            return
        agent = self.agents[seer.player_id]
        result = await agent.decide_night_action(self.game)
        target = result.get("target")

        if isinstance(target, int):
            try:
                self.validator.validate_night_action(self.game, seer, "check", target)
                target_player = self.game.get_player(target)
                camp = "werewolf" if target_player.role == Role.WEREWOLF else "good"
                seer.seer_checks.append({"target": target, "result": camp})
                self.game.night_actions.append(NightAction(
                    role=Role.SEER, player_id=seer.player_id,
                    action_type="check", target=target,
                    result=camp, reasoning=result.get("reasoning", ""),
                ))
                self._emit("skill", {"role": "seer", "target": target, "result": camp})
            except ActionValidationError:
                pass

    async def _witch_turn(self):
        """女巫阶段：决定是否使用解药/毒药，同一夜双药互斥"""
        self.game.phase = Phase.WITCH_TURN
        self._emit("phase_change", {"phase": "witch_turn"})

        witch = next(
            (p for p in self.game.get_alive_players() if p.role == Role.WITCH), None
        )
        if not witch:
            return
        agent = self.agents[witch.player_id]
        result = await agent.decide_night_action(self.game)
        action_type = result.get("action", "pass")
        target = result.get("target")

        if action_type == "heal" and witch.witch_has_heal and self.game.wolf_target is not None:
            try:
                self.validator.validate_night_action(
                    self.game, witch, "heal", self.game.wolf_target,
                    used_poison_this_round=witch.witch_poisoned_this_round,
                )
                witch.witch_has_heal = False
                witch.witch_healed_this_round = True
                self.game.witch_heal_target = self.game.wolf_target
                self.game.night_actions.append(NightAction(
                    role=Role.WITCH, player_id=witch.player_id,
                    action_type="heal", target=self.game.wolf_target,
                    reasoning=result.get("reasoning", ""),
                ))
                self._emit("skill", {"role": "witch", "action": "heal", "target": self.game.wolf_target})
            except ActionValidationError:
                pass
        elif action_type == "poison" and witch.witch_has_poison and isinstance(target, int):
            try:
                self.validator.validate_night_action(
                    self.game, witch, "poison", target,
                    used_heal_this_round=witch.witch_healed_this_round,
                )
                witch.witch_has_poison = False
                witch.witch_poisoned_this_round = True
                self.game.witch_poison_target = target
                self.game.night_actions.append(NightAction(
                    role=Role.WITCH, player_id=witch.player_id,
                    action_type="poison", target=target,
                    reasoning=result.get("reasoning", ""),
                ))
                self._emit("skill", {"role": "witch", "action": "poison", "target": target})
            except ActionValidationError:
                pass

    def _resolve_night_deaths(self) -> List[PlayerState]:
        """结算夜间死亡，返回死亡玩家列表"""
        deaths: List[PlayerState] = []
        wolf_killed = self.game.wolf_target

        if wolf_killed is not None:
            # 女巫救了
            if self.game.witch_heal_target == wolf_killed:
                self._emit("save", {"target": wolf_killed})
            else:
                player = self.game.get_player(wolf_killed)
                if player and player.alive:
                    player.alive = False
                    deaths.append(player)

        # 女巫毒杀
        if self.game.witch_poison_target is not None:
            target = self.game.get_player(self.game.witch_poison_target)
            if target and target.alive:
                target.alive = False
                deaths.append(target)
                # 被毒杀的猎人不能开枪
                if target.role == Role.HUNTER:
                    target.hunter_can_shoot = False

        # 被狼杀的猎人可以开枪
        for p in deaths:
            if p.role == Role.HUNTER and p.hunter_can_shoot:
                pass  # 标记已设置

        self.game.night_deaths = [p.player_id for p in deaths]
        for p in deaths:
            self._emit("death", {"player_id": p.player_id, "cause": "night", "role": p.role.value})

        return deaths

    async def _handle_hunter_shoot(self, night_deaths: List[PlayerState]) -> Optional[Camp]:
        """处理夜间猎人开枪"""
        for p in night_deaths:
            if p.role == Role.HUNTER and p.hunter_can_shoot:
                winner = await self._execute_hunter_shoot(p)
                if winner:
                    return winner
        return None

    async def _execute_hunter_shoot(self, hunter: PlayerState) -> Optional[Camp]:
        """执行猎人开枪"""
        if not hunter.hunter_can_shoot:
            return None

        agent = self.agents.get(hunter.player_id)
        if not agent:
            return None

        shoot_target = await agent.decide_hunter_shoot(self.game)
        if isinstance(shoot_target, int):
            target_player = self.game.get_player(shoot_target)
            if target_player and target_player.alive:
                target_player.alive = False
                self._emit("hunter_shoot", {
                    "hunter_id": hunter.player_id,
                    "target_id": shoot_target,
                    "target_role": target_player.role.value,
                })
                self._emit("death", {
                    "player_id": shoot_target,
                    "cause": "hunter",
                    "role": target_player.role.value,
                })

        hunter.hunter_can_shoot = False
        return self.win_checker.check(self.game)

    async def _speech_phase(self):
        """发言阶段：每个存活玩家依次发言"""
        self.game.phase = Phase.SPEECH
        self._emit("phase_change", {"phase": "speech", "day": self.game.round_num})

        alive = self.game.get_alive_players()
        for player in alive:
            agent = self.agents[player.player_id]
            speech = await agent.decide_speech(self.game)
            record = SpeechRecord(
                player_id=player.player_id,
                content=speech,
                day=self.game.round_num,
            )
            self.game.speeches.append(record)
            self._emit("speech", {"player_id": player.player_id, "content": speech, "day": self.game.round_num})
            # 记录发言到向量记忆
            if self.memory:
                self.memory.add_speech(
                    game_id=self.game.game_id,
                    round_num=self.game.round_num,
                    player_id=player.player_id,
                    role=player.role.value,
                    speech=speech,
                )

    async def _vote_phase(self):
        """投票阶段"""
        self.game.phase = Phase.VOTE
        self._emit("phase_change", {"phase": "vote", "day": self.game.round_num})

        self.game.votes = []
        alive = self.game.get_alive_players()
        for player in alive:
            agent = self.agents[player.player_id]
            target = await agent.decide_vote(self.game)
            if isinstance(target, int):
                try:
                    self.validator.validate_vote(self.game, player, target)
                    self.game.votes.append(VoteRecord(
                        voter_id=player.player_id,
                        target_id=target,
                        day=self.game.round_num,
                    ))
                except ActionValidationError:
                    pass  # 弃票

        self._emit("vote_result", {
            "votes": [{"voter": v.voter_id, "target": v.target_id} for v in self.game.votes],
            "day": self.game.round_num,
        })

    def _resolve_vote(self) -> Optional[int]:
        """结算投票，返回被淘汰玩家ID。平票时随机淘汰（简化处理）"""
        if not self.game.votes:
            return None

        tally: dict[int, int] = {}
        for v in self.game.votes:
            tally[v.target_id] = tally.get(v.target_id, 0) + 1

        max_votes = max(tally.values())
        top_targets = [pid for pid, cnt in tally.items() if cnt == max_votes]

        eliminated_id = None
        if len(top_targets) == 1:
            eliminated_id = top_targets[0]
            player = self.game.get_player(eliminated_id)
            if player:
                player.alive = False
                self.game.vote_eliminated = eliminated_id
                self._emit("vote_eliminated", {
                    "player_id": eliminated_id,
                    "role": player.role.value,
                    "votes": tally[eliminated_id],
                })
        else:
            # 平票：PK 发言 + 再投票
            eliminated_id = self._pk_vote(top_targets)

        return eliminated_id

    def _pk_vote(self, candidates: List[int]) -> Optional[int]:
        """平票 PK：从候选人中随机选择一人出局（简化处理）"""
        self._emit("pk_start", {
            "candidates": candidates,
            "day": self.game.round_num,
        })

        # 简化：平票时随机淘汰一人
        eliminated_id = random.choice(candidates)
        player = self.game.get_player(eliminated_id)
        if player:
            player.alive = False
            self.game.vote_eliminated = eliminated_id
            self._emit("pk_result", {
                "player_id": eliminated_id,
                "role": player.role.value,
                "method": "pk_random",
            })
        return eliminated_id