"""胜负判定"""

from typing import Optional

from .state import GameState, Camp, Role


class WinChecker:
    """判定游戏是否结束及胜方

    好人胜利：所有狼人被消灭
    狼人胜利：存活狼人数 >= 存活好人数（屠边/屠城）
    """

    def check(self, game: GameState) -> Optional[Camp]:
        alive = game.get_alive_players()
        if not alive:
            return Camp.GOOD

        alive_wolves = [p for p in alive if p.role == Role.WEREWOLF]
        alive_good = [p for p in alive if p.camp == Camp.GOOD]

        if not alive_wolves:
            return Camp.GOOD
        if len(alive_wolves) >= len(alive_good):
            return Camp.EVIL
        return None
