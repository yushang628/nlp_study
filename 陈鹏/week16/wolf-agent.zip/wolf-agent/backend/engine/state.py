"""游戏状态与数据模型

核心类：Role/Camp/Phase 枚举、PlayerState、GameState、NightAction、GameEvent
关键约束：get_private_context() 是信息隔离唯一入口，不同角色看到不同信息
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any


class Role(Enum):
    """角色枚举"""
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    VILLAGER = "villager"


class Camp(Enum):
    """阵营枚举：好人/狼人"""
    GOOD = "good"
    EVIL = "evil"


class Phase(Enum):
    """游戏阶段状态机"""
    NIGHT_START = "night_start"
    WOLF_TURN = "wolf_turn"
    SEER_TURN = "seer_turn"
    WITCH_TURN = "witch_turn"
    NIGHT_END = "night_end"
    DAY_START = "day_start"
    SPEECH = "speech"
    VOTE = "vote"
    DAY_END = "day_end"
    GAME_OVER = "game_over"


ROLE_CAMP = {
    # 角色→阵营映射：狼人→邪恶，其余→善良
    Role.WEREWOLF: Camp.EVIL,
    Role.SEER: Camp.GOOD,
    Role.WITCH: Camp.GOOD,
    Role.HUNTER: Camp.GOOD,
    Role.VILLAGER: Camp.GOOD,
}

ROLE_NAMES = {
    Role.WEREWOLF: "狼人",
    Role.SEER: "预言家",
    Role.WITCH: "女巫",
    Role.HUNTER: "猎人",
    Role.VILLAGER: "村民",
}

NIGHT_ORDER = [Phase.WOLF_TURN, Phase.SEER_TURN, Phase.WITCH_TURN]


@dataclass
class PlayerState:
    """玩家状态：角色、存活、技能标记（hunter_can_shoot/药水/守卫记忆）"""
    player_id: int
    name: str
    role: Role
    alive: bool = True
    is_sheriff: bool = False
    # 角色技能状态
    witch_has_heal: bool = True       # 女巫是否还有解药
    witch_has_poison: bool = True     # 女巫是否还有毒药
    witch_healed_this_round: bool = False  # 本轮女巫是否已用解药（双药互斥标记）
    witch_poisoned_this_round: bool = False # 本轮女巫是否已用毒药（双药互斥标记）
    hunter_can_shoot: bool = True     # 猎人能否开枪（被毒杀时为 False，即"闷枪"）
    # 预言家查验记录
    seer_checks: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def camp(self) -> Camp:
        """从 role 自动推导阵营"""
        return ROLE_CAMP[self.role]

    @property
    def role_name(self) -> str:
        return ROLE_NAMES[self.role]

    @property
    def is_god(self) -> bool:
        """是否神职（预言家/女巫/猎人）"""
        return self.role in (Role.SEER, Role.WITCH, Role.HUNTER)

    def to_dict(self, reveal_role: bool = False) -> Dict[str, Any]:
        """转换为 dict，reveal_role=True 或死亡时暴露角色"""
        d = {
            "player_id": self.player_id,
            "name": self.name,
            "alive": self.alive,
            "is_sheriff": self.is_sheriff,
        }
        if reveal_role or not self.alive:
            d["role"] = self.role.value
            d["role_name"] = self.role_name
            d["camp"] = self.camp.value
        return d

    def to_private_dict(self) -> Dict[str, Any]:
        """转换包含私有信息的 dict（仅自己可见）"""
        d = self.to_dict(reveal_role=True)
        if self.role == Role.WITCH:
            d["has_heal"] = self.witch_has_heal
            d["has_poison"] = self.witch_has_poison
        if self.role == Role.SEER:
            d["checks"] = self.seer_checks
        if self.role == Role.HUNTER:
            d["can_shoot"] = self.hunter_can_shoot
        return d


@dataclass
class NightAction:
    """夜间行动记录：kill/check/heal/poison/guard"""
    """夜间行动记录"""
    role: Role
    player_id: int
    action_type: str  # "kill", "check", "heal", "poison", "shoot"
    target: Optional[int] = None
    result: Optional[str] = None
    reasoning: Optional[str] = None


@dataclass
class SpeechRecord:
    """公开发言记录"""
    """发言记录"""
    player_id: int
    content: str
    day: int


@dataclass
class VoteRecord:
    """投票记录"""
    """投票记录"""
    voter_id: int
    target_id: int
    day: int


@dataclass
class GameEvent:
    """游戏事件，用于日志和 WebSocket 推送"""
    """游戏事件（用于 WebSocket 广播和日志）"""
    event_type: str  # "phase_change", "speech", "vote", "death", "skill", "game_over"
    data: Dict[str, Any] = field(default_factory=dict)
    day: int = 0
    timestamp: str = ""


@dataclass
class GameState:
    """游戏全局状态，核心不变量是信息隔离"""
    """游戏全局状态"""
    players: List[PlayerState] = field(default_factory=list)
    phase: Phase = Phase.NIGHT_START
    round_num: int = 1
    # 夜间行动
    night_actions: List[NightAction] = field(default_factory=list)
    wolf_target: Optional[int] = None
    witch_heal_target: Optional[int] = None
    witch_poison_target: Optional[int] = None
    night_deaths: List[int] = field(default_factory=list)
    # 白天
    speeches: List[SpeechRecord] = field(default_factory=list)
    votes: List[VoteRecord] = field(default_factory=list)
    vote_eliminated: Optional[int] = None
    # 全局
    events: List[GameEvent] = field(default_factory=list)
    winner: Optional[Camp] = None
    game_id: Optional[str] = None

    def get_alive_players(self) -> List[PlayerState]:
        return [p for p in self.players if p.alive]

    def get_player(self, player_id: int) -> Optional[PlayerState]:
        for p in self.players:
            if p.player_id == player_id:
                return p
        return None

    def get_players_by_role(self, role: Role) -> List[PlayerState]:
        return [p for p in self.players if p.role == role]

    def get_players_by_camp(self, camp: Camp) -> List[PlayerState]:
        return [p for p in self.players if p.camp == camp]

    def get_public_context(self) -> Dict[str, Any]:
        """所有人可见的信息"""
        return {
            "round": self.round_num,
            "phase": self.phase.value,
            "alive_players": [p.to_dict() for p in self.get_alive_players()],
            "dead_players": [p.to_dict(reveal_role=True) for p in self.players if not p.alive],
            "speeches": [
                {"player_id": s.player_id, "content": s.content, "day": s.day}
                for s in self.speeches
            ],
            "votes": [
                {"voter_id": v.voter_id, "target_id": v.target_id, "day": v.day}
                for v in self.votes
            ],
            "night_deaths": self.night_deaths,
        }

    def get_private_context(self, player_id: int) -> Dict[str, Any]:
        """某个玩家的私有上下文（信息隔离核心）"""
        player = self.get_player(player_id)
        if not player:
            return {}
        ctx = self.get_public_context()
        ctx["my_info"] = player.to_private_dict()
        # 狼人知道同伴
        if player.role == Role.WEREWOLF:
            ctx["wolf_teammates"] = [
                p.to_dict(reveal_role=True) for p in self.get_players_by_role(Role.WEREWOLF)
                if p.player_id != player_id and p.alive
            ]
        # 预言家查验历史
        if player.role == Role.SEER:
            ctx["my_checks"] = player.seer_checks
        # 过滤对话：仅公开+自己的夜间行动
        visible_actions = []
        for action in self.night_actions:
            if action.player_id == player_id:
                visible_actions.append({
                    "action_type": action.action_type,
                    "target": action.target,
                    "result": action.result,
                    "reasoning": action.reasoning,
                })
            elif action.role == Role.WEREWOLF and player.role == Role.WEREWOLF:
                visible_actions.append({
                    "player_id": action.player_id,
                    "action_type": action.action_type,
                    "target": action.target,
                })
        ctx["visible_night_actions"] = visible_actions
        return ctx


# 预定义角色配置（simple_4/standard_6/big_9）
ROLE_CONFIGS = {
    "standard_6": {
        "name": "标准6人局",
        "description": "2狼人、1预言家、1女巫、1猎人、1村民",
        "roles": [Role.WEREWOLF, Role.WEREWOLF, Role.SEER, Role.WITCH, Role.HUNTER, Role.VILLAGER],
    },
    "simple_4": {
        "name": "简易4人局",
        "description": "1狼人、1预言家、1女巫、1村民",
        "roles": [Role.WEREWOLF, Role.SEER, Role.WITCH, Role.VILLAGER],
    },
    "big_9": {
        "name": "标准9人局",
        "description": "3狼人、1预言家、1女巫、1猎人、3村民",
        "roles": [Role.WEREWOLF, Role.WEREWOLF, Role.WEREWOLF, Role.SEER, Role.WITCH, Role.HUNTER, Role.VILLAGER, Role.VILLAGER, Role.VILLAGER],
    },
}