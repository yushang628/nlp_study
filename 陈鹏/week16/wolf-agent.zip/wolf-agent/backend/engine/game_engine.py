"""游戏引擎 — 状态机驱动日夜循环，游戏结束自动复盘"""

import uuid
import random
import asyncio
import logging
from typing import List, Optional, Callable, Awaitable

from .state import (
    GameState, Phase, Role, Camp, PlayerState,
    ROLE_CONFIGS, GameEvent,
)
from .phase import PhaseExecutor, create_agents
from .action_validator import ActionValidator
from .win_checker import WinChecker
from ..llm.client import LLMClient
from ..agents.summary_agent import SummaryAgent

logger = logging.getLogger(__name__)


class GameEngine:
    """游戏引擎：初始化玩家/Agent → 循环 night/day → 自动复盘"""
    def __init__(
        self,
        role_config: str = "standard_6",
        player_names: Optional[List[str]] = None,
        llm: Optional[LLMClient] = None,
        on_event: Optional[Callable[[GameEvent], Awaitable[None]]] = None,
        strategy_params=None,
    ):
        self.game = GameState(game_id=str(uuid.uuid4())[:8])
        self.validator = ActionValidator()
        self.win_checker = WinChecker()
        self.llm = llm or LLMClient()
        self.on_event = on_event
        self._running = False
        self.strategy_params = strategy_params
        self.summary_agent = SummaryAgent(self.llm)

        # 向量记忆（根据配置决定是否启用）
        self.memory = None
        try:
            from ..config import settings
            if settings.memory.enabled:
                from ..memory.store import MemoryStore
                self.memory = MemoryStore(persist_dir=settings.memory.chroma_persist_dir)
        except Exception:
            pass

        self._init_players(role_config, player_names)
        self.agents = create_agents(self.game.players, self.llm, memory=self.memory, strategy_params=strategy_params)
        self.executor = PhaseExecutor(self.game, self.agents, self.validator, memory=self.memory)

    def _init_players(self, role_config: str, player_names: Optional[List[str]]):
        config = ROLE_CONFIGS.get(role_config, ROLE_CONFIGS["standard_6"])
        roles = list(config["roles"])
        random.shuffle(roles)

        n = len(roles)
        if not player_names:
            player_names = [f"玩家{i+1}" for i in range(n)]
        elif len(player_names) < n:
            player_names += [f"玩家{i+1}" for i in range(len(player_names), n)]

        for i, role in enumerate(roles):
            self.game.players.append(PlayerState(
                player_id=i + 1,
                name=player_names[i],
                role=role,
            ))

    async def run(self) -> Camp:
        """运行完整一局游戏，返回胜方阵营"""
        """运行完整一局游戏"""
        if self._running:
            return self.game.winner or Camp.GOOD
        self._running = True

        self.game.phase = Phase.NIGHT_START
        await self._notify("game_start", {
            "game_id": self.game.game_id,
            "players": [p.to_dict(reveal_role=False) for p in self.game.players],
        })

        max_rounds = 20
        while self.game.phase != Phase.GAME_OVER and self.game.round_num <= max_rounds:
            winner = await self.executor.run_night()
            await self._flush_events()
            if winner:
                self.game.winner = winner
                self.game.phase = Phase.GAME_OVER
                break

            winner = await self.executor.run_day()
            await self._flush_events()
            if winner:
                self.game.winner = winner
                self.game.phase = Phase.GAME_OVER
                break

        if not self.game.winner:
            self.game.winner = Camp.GOOD
            self.game.phase = Phase.GAME_OVER
        self._running = False

        # 游戏结束后自动复盘
        await self._run_summary()

        return self.game.winner

    async def _flush_events(self):
        """将 PhaseExecutor 产生的事件统一推送"""
        for event in self.executor.events:
            await self._notify(event.event_type, event.data)
        self.executor.events.clear()

    async def _notify(self, event_type: str, data: dict):
        """通过 on_event 回调推送事件（WebSocket 或 CLI）"""
        if self.on_event:
            try:
                await self.on_event(GameEvent(
                    event_type=event_type, data=data, day=self.game.round_num,
                ))
            except Exception:
                pass

    def get_state(self) -> dict:
        """返回游戏状态摘要（不含角色私有信息）"""
        return {
            "game_id": self.game.game_id,
            "phase": self.game.phase.value,
            "round": self.game.round_num,
            "winner": self.game.winner.value if self.game.winner else None,
            "players": [p.to_dict(reveal_role=False) for p in self.game.players],
            "speeches": [
                {"player_id": s.player_id, "content": s.content, "day": s.day}
                for s in self.game.speeches
            ],
            "votes": [
                {"voter_id": v.voter_id, "target_id": v.target_id, "day": v.day}
                for v in self.game.votes
            ],
            "night_deaths": self.game.night_deaths,
            "events": [
                {"type": e.event_type, "data": e.data, "day": e.day}
                for e in self.game.events
            ],
        }

    async def _run_summary(self) -> None:
        """游戏结束后调用 SummaryAgent 生成复盘总结并保存经验"""
        game_log = self._build_game_log()
        players_info = self._build_players_info()
        try:
            self.summary_result = await self.summary_agent.generate_summary(game_log, players_info)
            await self._notify("game_summary", {
                "game_id": self.game.game_id,
                "overview": self.summary_result.get("game_overview", ""),
                "key_moments": self.summary_result.get("key_moments", []),
            })
        except Exception as e:
            logger.warning(f"复盘总结生成失败: {e}")

    def _build_game_log(self) -> list:
        """从游戏事件中构建结构化日志供复盘使用"""
        log = []
        current_round = 1
        round_events = {"round": current_round, "phase": "night", "actions": {}}

        for event in self.game.events:
            day = event.day or current_round
            if day != current_round:
                log.append(round_events)
                current_round = day
                round_events = {"round": current_round, "phase": "night", "actions": {}}

            et = event.event_type
            if et == "phase_change":
                round_events["phase"] = event.data.get("phase", "")
            elif et == "skill":
                role = event.data.get("role", "未知")
                action = f"目标:玩家{event.data.get('target', '?')}"
                if event.data.get("result"):
                    action += f" 结果:{event.data['result']}"
                if event.data.get("action"):
                    action = f"{event.data['action']} {action}"
                round_events["actions"][role] = action
            elif et == "speech":
                phase = "day_speech" if "speech" in event.data.get("phase", "") else "night"
                if phase not in round_events:
                    round_events.setdefault("speeches", []).append(
                        {"player": f"玩家{event.data.get('player_id', '?')}",
                         "content": event.data.get("content", "")[:100]})
            elif et == "vote_result":
                votes = event.data.get("votes", [])
                vote_dict = {f"玩家{v['voter']}": f"玩家{v['target']}" for v in votes}
                round_events["votes"] = vote_dict
                if event.data.get("eliminated"):
                    round_events["eliminated"] = f"玩家{event.data['eliminated']}"
            elif et == "death":
                round_events.setdefault("deaths", []).append(
                    f"玩家{event.data.get('player_id', '?')}")

        log.append(round_events)
        return log

    def _build_players_info(self) -> dict:
        """构建玩家信息供复盘使用"""
        winner = self.game.winner
        return {
            p.name: {
                "role": p.role_name,
                "is_alive": p.alive,
                "is_winner": p.camp == winner if winner else False,
                "camp": p.camp.value,
            }
            for p in self.game.players
        }