"""结构化游戏日志"""

import json
import os
from datetime import datetime
from typing import Dict, Any, List

from ..engine.state import GameEvent


class GameLogger:
    """结构化游戏日志：收集事件并保存为 JSON 文件"""
    def __init__(self, game_id: str, log_dir: str = "./data/logs"):
        self.game_id = game_id
        self.log_dir = log_dir
        self.entries: List[Dict[str, Any]] = []
        os.makedirs(log_dir, exist_ok=True)

    def log_event(self, event: GameEvent):
        """记录一条游戏事件到日志列表"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "game_id": self.game_id,
            "day": event.day,
            "event_type": event.event_type,
            "data": event.data,
        }
        self.entries.append(entry)

    def save(self):
        """将所有日志事件保存为 JSON 文件，返回文件路径"""
        filename = f"game_{self.game_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        path = os.path.join(self.log_dir, filename)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.entries, f, ensure_ascii=False, indent=2)
        return path