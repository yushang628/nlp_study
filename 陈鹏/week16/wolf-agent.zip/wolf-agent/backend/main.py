"""AI 狼人杀 — 多智能体协作博弈系统"""

import asyncio
import logging

from fastapi import FastAPI, WebSocket
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import router
from .api.websocket import websocket_endpoint, manager
from .engine.state import GameEvent
from .engine.game_engine import GameEngine
from .logs.game_logger import GameLogger
from .config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)

# FastAPI 应用实例
app = FastAPI(title="AI 狼人杀", version="1.0.0")  # FastAPI 应用实例

# CORS 中间件：允许前端跨域访问
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)


@app.websocket("/ws/game/{game_id}")
async def ws_game(websocket: WebSocket, game_id: str):
    await websocket_endpoint(websocket, game_id)


@app.get("/")
async def root():
    return {"message": "AI 狼人杀 API", "version": "1.0.0"}


@app.get("/api/configs")
async def list_configs():
    from .engine.state import ROLE_CONFIGS
    return {
        name: {"name": cfg["name"], "description": cfg["description"], "player_count": len(cfg["roles"])}
        for name, cfg in ROLE_CONFIGS.items()
    }


async def run_cli():
    """命令行模式：运行一局完整游戏"""
    print("=" * 50)
    print("AI 狼人杀 — 命令行模式")
    print("=" * 50)

    engine = GameEngine(role_config="standard_6")
    game_id = engine.game.game_id
    game_logger = GameLogger(game_id, log_dir=settings.log.log_dir)

    async def on_event(event: GameEvent):
        game_logger.log_event(event)
        # 简单打印
        if event.event_type == "speech":
            pid = event.data.get("player_id", "?")
            content = event.data.get("content", "")
            print(f"  玩家{pid}: {content[:80]}")
        elif event.event_type == "vote_result":
            votes = event.data.get("votes", [])
            for v in votes:
                print(f"  玩家{v['voter']} → 玩家{v['target']}")
        elif event.event_type == "death":
            pid = event.data.get("player_id", "?")
            print(f"  ✝ 玩家{pid} 死亡")
        elif event.event_type == "game_over":
            winner = event.data.get("winner", "?")
            print(f"\n游戏结束！胜方：{'好人阵营' if winner == 'good' else '狼人阵营'}")
        elif event.event_type == "phase_change":
            phase = event.data.get("phase", "")
            day = event.data.get("day", "")
            if phase == "night_start":
                print(f"\n{'='*30} 第 {day} 夜 {'='*30}")
            elif phase == "day_start":
                print(f"\n{'='*30} 第 {day} 天 {'='*30}")
            elif phase == "speech":
                print("\n--- 公开演讲 ---")
            elif phase == "vote":
                print("\n--- 投票环节 ---")

    engine.on_event = on_event

    # 显示角色分配
    print(f"\n游戏ID: {game_id}")
    print("角色分配：")
    for p in engine.game.players:
        print(f"  {p.name} → {p.role_name} ({p.camp.value})")

    winner = await engine.run()

    # 保存日志
    log_path = game_logger.save()
    print(f"\n游戏日志已保存: {log_path}")

    return winner


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "serve":
        import uvicorn
        uvicorn.run(app, host=settings.server.host, port=settings.server.port)
    else:
        asyncio.run(run_cli())