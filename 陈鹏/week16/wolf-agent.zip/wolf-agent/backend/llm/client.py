"""LLM 客户端 — OpenAI 兼容接口（通义千问）"""

import json
import asyncio
import logging
from typing import Optional, Dict, Any, List

from openai import OpenAI

from ..config import settings

logger = logging.getLogger(__name__)


class LLMClient:
    """OpenAI 兼容客户端，通过 chat_json 获取结构化 JSON 决策"""
    def __init__(
        self,
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ):
        self.model = model or settings.llm.default_model
        self.client = OpenAI(
            api_key=api_key or settings.llm.api_key,
            base_url=base_url or settings.llm.base_url,
        )

    async def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 1024,
        response_format: Optional[Dict[str, str]] = None,
    ) -> str:
        """通用聊天接口，返回原始文本"""
        kwargs: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        if response_format:
            kwargs["response_format"] = response_format

        try:
            resp = await asyncio.to_thread(self.client.chat.completions.create, **kwargs)
            return resp.choices[0].message.content or ""
        except Exception as e:
            logger.error("LLM call failed: %s", e)
            raise

    async def chat_json(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 1024,
    ) -> Dict[str, Any]:
        """结构化聊天：强制 JSON 输出，解析失败时尝试提取 {...} 段"""
        content = await self.chat(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": "json_object"},
        )
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            logger.warning("LLM returned invalid JSON, attempting extraction")
            start = content.find("{")
            end = content.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(content[start:end])
            return {"raw_response": content}

    async def generate_speech(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.8,
    ) -> str:
        """生成发言文本，temperature 较高以增加多样性"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        return await self.chat(messages=messages, temperature=temperature, max_tokens=512)

    async def decide_action(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.3,
    ) -> Dict[str, Any]:
        """决策接口：返回 JSON 格式的行动决策"""
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        return await self.chat_json(messages=messages, temperature=temperature)