"""REST API 路由"""

import asyncio
from fastapi import APIRouter, HTTPException
from typing import Dict, Any

from .models import CreateGameRequest, GameResponse
from ..engine.game_engine import GameEngine
from ..engine.state import GameEvent
from .websocket import manager

router = APIRouter(prefix="/api/games", tags=["games"])

# 内存中的游戏实例映射（game_id -> GameEngine）
games: Dict[str, GameEngine] = {}


async def _make_event_sender(game_id: str):
    async def sender(event: GameEvent):
        await manager.broadcast(game_id, event)
    return sender


@router.post("", response_model=GameResponse)
async def create_game(req: CreateGameRequest):
    """创建新游戏并返回 game_id"""
    engine = GameEngine(
        role_config=req.role_config,
        player_names=req.player_names,
    )
    gid = engine.game.game_id
    engine.on_event = await _make_event_sender(gid)
    games[gid] = engine
    return GameResponse(**engine.get_state())


@router.get("/{game_id}", response_model=GameResponse)
async def get_game(game_id: str):
    """获取游戏状态"""
    engine = games.get(game_id)
    if not engine:
        raise HTTPException(status_code=404, detail="Game not found")
    return GameResponse(**engine.get_state())


@router.post("/{game_id}/start")
async def start_game(game_id: str):
    """启动游戏运行，后台执行完整日夜循环"""
    engine = games.get(game_id)
    if not engine:
        raise HTTPException(status_code=404, detail="Game not found")
    if engine._running:
        raise HTTPException(status_code=400, detail="Game already running")
    # 在后台运行，立即返回
    asyncio.create_task(engine.run())
    return {"message": "Game started", "game_id": game_id}


@router.get("/{game_id}/log")
async def get_game_log(game_id: str):
    engine = games.get(game_id)
    if not engine:
        raise HTTPException(status_code=404, detail="Game not found")
    return {"events": engine.get_state()["events"]}