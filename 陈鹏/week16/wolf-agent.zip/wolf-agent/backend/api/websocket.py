"""WebSocket 实时游戏事件推送"""

import json
from typing import Dict, Set
from fastapi import WebSocket, WebSocketDisconnect

from ..engine.state import GameEvent


class ConnectionManager:
    """WebSocket 连接管理器：管理每个 game_id 的连接集合"""
    def __init__(self):
        self.active: Dict[str, Set[WebSocket]] = {}

    async def connect(self, game_id: str, ws: WebSocket):
        """接受 WebSocket 连接并加入 game_id 对应的集合"""
        await ws.accept()
        if game_id not in self.active:
            self.active[game_id] = set()
        self.active[game_id].add(ws)

    def disconnect(self, game_id: str, ws: WebSocket):
        """断开连接并从集合中移除"""
        if game_id in self.active:
            self.active[game_id].discard(ws)

    async def broadcast(self, game_id: str, event: GameEvent):
        """向所有订阅该 game_id 的客户端广播事件"""
        if game_id not in self.active or not self.active[game_id]:
            return
        msg = json.dumps({
            "event_type": event.event_type,
            "data": event.data,
            "day": event.day,
        }, ensure_ascii=False)
        dead = []
        for ws in self.active[game_id]:
            try:
                await ws.send_text(msg)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.active[game_id].discard(ws)

    async def send_text(self, game_id: str, text: str):
        """发送原始 JSON 文本（用于非 GameEvent 场景）"""
        if game_id not in self.active or not self.active[game_id]:
            return
        dead = []
        for ws in self.active[game_id]:
            try:
                await ws.send_text(text)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.active[game_id].discard(ws)


# 全局 WebSocket 连接管理器实例
manager = ConnectionManager()


async def websocket_endpoint(websocket: WebSocket, game_id: str):
    await manager.connect(game_id, websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(game_id, websocket)