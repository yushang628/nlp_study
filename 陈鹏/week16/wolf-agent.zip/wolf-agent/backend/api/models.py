"""API 数据模型"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class CreateGameRequest(BaseModel):
    """创建游戏请求：指定角色配置和玩家名称"""
    role_config: str = "standard_6"
    player_names: Optional[List[str]] = None


class GameResponse(BaseModel):
    """游戏状态响应：返回完整游戏状态（不含角色私有信息）"""
    game_id: str
    phase: str
    round: int
    winner: Optional[str] = None
    players: List[Dict[str, Any]]
    speeches: List[Dict[str, Any]] = []
    votes: List[Dict[str, Any]] = []
    night_deaths: List[int] = []
    events: List[Dict[str, Any]] = []

    model_config = {"extra": "ignore"}


class EventMessage(BaseModel):
    """WebSocket 事件消息格式"""
    event_type: str
    data: Dict[str, Any] = {}
    day: int = 0