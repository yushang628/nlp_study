"""
系统配置 — 从项目根目录 .env 文件加载
优先级：环境变量 > .env 文件 > 代码默认值
"""

import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

_PROJECT_ROOT = Path(__file__).parent.parent
_ENV_FILE = _PROJECT_ROOT / ".env"


def _load_env() -> dict:
    """解析 .env 文件为 dict"""
    cfg = {}
    if not _ENV_FILE.exists():
        return cfg
    with open(_ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, value = line.split("=", 1)
                cfg[key.strip()] = value.strip()
    return cfg


_env = _load_env()


def _get(key: str, default=None):
    """优先环境变量，其次 .env 文件，最后默认值"""
    if key in os.environ:
        return os.environ[key]
    return _env.get(key, default)

@dataclass
class LLMConfig:
    """LLM 配置：API Key、模型名、Base URL"""
    api_key: str = field(default_factory=lambda: _get("API_KEY", ""))
    default_model: str = field(default_factory=lambda: _get("DEFAULT_MODEL", "qwen-flash"))
    speech_model: str = field(default_factory=lambda: _get("SPEECH_MODEL", "qwen-flash"))
    decision_model: str = field(default_factory=lambda: _get("DECISION_MODEL", "qwen-flash"))
    base_url: str = field(default_factory=lambda: _get("BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"))


@dataclass
class ServerConfig:
    """服务配置：监听地址和端口"""
    host: str = field(default_factory=lambda: _get("HOST", "0.0.0.0"))
    port: int = field(default_factory=lambda: int(_get("PORT", 8000)))


@dataclass
class MemoryConfig:
    """记忆配置：Chroma 向量记忆开关和持久化目录"""
    enabled: bool = field(default_factory=lambda: _get("MEMORY_ENABLED", "false") in ("true", "1", "True"))
    chroma_persist_dir: str = field(default_factory=lambda: _get("CHROMA_PERSIST_DIR", "./data/chroma"))


@dataclass
class LogConfig:
    """日志配置：日志文件存储目录"""
    log_dir: str = field(default_factory=lambda: _get("LOG_DIR", "./data/logs"))


@dataclass
class SystemConfig:
    """全局配置：聚合所有子配置"""
    llm: LLMConfig = field(default_factory=LLMConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    log: LogConfig = field(default_factory=LogConfig)


# 全局配置单例
settings = SystemConfig()
