"""经验存储系统 — 按角色类型保存和加载过往游戏经验"""

import json
import os
import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# 经验文件存储路径：data/experiences/{role}.json
EXPERIENCES_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "experiences")


def _ensure_dir() -> None:
    os.makedirs(EXPERIENCES_DIR, exist_ok=True)


def _get_file_path(role_type: str) -> str:
    return os.path.join(EXPERIENCES_DIR, f"{role_type}.json")


def load_experiences(role_type: str) -> List[Dict]:
    _ensure_dir()
    filepath = _get_file_path(role_type)
    if not os.path.exists(filepath):
        return []
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"加载 {role_type} 经验失败: {e}")
        return []


def save_experience(role_type: str, experience: Dict) -> None:
    _ensure_dir()
    filepath = _get_file_path(role_type)
    experiences = load_experiences(role_type)
    experiences.append(experience)
    # 最多保留最近 50 条
    if len(experiences) > 50:
        experiences = experiences[-50:]
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(experiences, f, ensure_ascii=False, indent=2)
    logger.info(f"保存 {role_type} 经验成功 (共 {len(experiences)} 条)")


def get_experience_prompt(role_type: str, max_entries: int = 3) -> str:
    """将过往经验格式化为提示词文本，供 Agent 构建指令时使用"""
    experiences = load_experiences(role_type)
    if not experiences:
        return ""

    recent = experiences[-max_entries:]
    lines = ["", "## 你的过往游戏经验", "以下是以往扮演此角色时学到的经验教训："]

    for i, exp in enumerate(recent, 1):
        outcome = "胜利" if exp.get("is_winner", False) else "失败"
        lines.append(f"\n--- 第{i}次经验（{outcome}）---")
        if exp.get("summary"):
            lines.append(f"  总结：{exp['summary']}")
        if exp.get("strategies"):
            lines.append(f"  策略：{exp['strategies']}")
        if exp.get("mistakes"):
            lines.append(f"  教训：{exp['mistakes']}")
        if exp.get("lessons"):
            lines.append(f"  建议：{exp['lessons']}")

    return "\n".join(lines)