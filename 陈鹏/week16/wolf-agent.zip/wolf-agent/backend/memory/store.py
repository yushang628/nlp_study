"""向量记忆存储 — Chroma"""

import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

try:
    import chromadb
    HAS_CHROMA = True
except ImportError:
    HAS_CHROMA = False


class MemoryStore:
    """基于 Chroma 的向量记忆，存储发言和行动，支持按角色相似查询"""

    def __init__(self, persist_dir: str = "./data/chroma"):
        self.persist_dir = persist_dir
        self._client = None
        self._collection = None

        if HAS_CHROMA:
            try:
                self._client = chromadb.PersistentClient(path=persist_dir)
                self._collection = self._client.get_or_create_collection(
                    name="wolf_agent_memory",
                    metadata={"hnsw:space": "cosine"},
                )
            except Exception as e:
                logger.warning(f"ChromaDB 初始化失败: {e}，记忆功能不可用")
                self._collection = None

    def add_speech(self, game_id: str, round_num: int, player_id: int,
                   role: str, speech: str, metadata: Optional[dict] = None):
        """存储发言记录"""
        if not self._collection:
            return
        doc_id = f"{game_id}_r{round_num}_p{player_id}"
        doc = f"[{role}] 玩家{player_id} 第{round_num}轮发言: {speech}"
        meta = {"game_id": game_id, "round": round_num, "player_id": player_id, "role": role}
        if metadata:
            meta.update(metadata)
        try:
            self._collection.upsert(ids=[doc_id], documents=[doc], metadatas=[meta])
        except Exception as e:
            logger.warning(f"add_speech 失败: {e}")

    def add_night_action(self, game_id: str, round_num: int, player_id: int,
                         role: str, action: str, metadata: Optional[dict] = None):
        """存储夜间行动记录"""
        if not self._collection:
            return
        doc_id = f"{game_id}_r{round_num}_p{player_id}_night"
        doc = f"[{role}] 玩家{player_id} 第{round_num}轮夜间行动: {action}"
        meta = {"game_id": game_id, "round": round_num, "player_id": player_id, "role": role, "phase": "night"}
        if metadata:
            meta.update(metadata)
        try:
            self._collection.upsert(ids=[doc_id], documents=[doc], metadatas=[meta])
        except Exception as e:
            logger.warning(f"add_night_action 失败: {e}")

    def query_similar(self, query: str, n_results: int = 5, role: Optional[str] = None) -> List[Dict[str, Any]]:
        """查询相似记忆：向量检索 + 可选角色过滤"""
        if not self._collection:
            return []
        try:
            count = self._collection.count()
            if count == 0:
                return []
            where = {"role": role} if role else None
            results = self._collection.query(
                query_texts=[query],
                n_results=min(n_results, count),
                where=where,
            )
            docs = []
            for i, doc in enumerate(results["documents"][0]):
                docs.append({
                    "content": doc,
                    "metadata": results["metadatas"][0][i],
                    "distance": results["distances"][0][i] if "distances" in results else None,
                })
            return docs
        except Exception as e:
            logger.warning(f"query_similar 失败: {e}")
            return []

    def query_by_role(self, query: str, role: str, n_results: int = 3) -> List[Dict[str, Any]]:
        """按角色查询：先按角色过滤再做向量检索"""
        return self.query_similar(query, n_results=n_results, role=role)