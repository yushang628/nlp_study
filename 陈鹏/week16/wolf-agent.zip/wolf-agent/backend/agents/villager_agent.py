"""村民 Agent"""

from ..engine.state import GameState
from .base_agent import BaseAgent


class VillagerAgent(BaseAgent):
    """村民 Agent：无特殊技能，通过发言和投票参与游戏"""

    async def decide_night_action(self, game: GameState) -> dict:
        return {"action": "pass", "target": None}