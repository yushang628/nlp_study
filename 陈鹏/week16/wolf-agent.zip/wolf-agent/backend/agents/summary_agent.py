"""复盘总结 Agent — 游戏结束后生成结构化复盘并保存经验"""

import logging
from typing import Dict, List, Optional

from ..llm.client import LLMClient
from ..memory.experience import save_experience

logger = logging.getLogger(__name__)

SUMMARY_SYSTEM_PROMPT = """你是一个狼人杀游戏复盘分析专家。你需要根据游戏记录，为每位玩家生成客观、有建设性的复盘总结。

分析要点：
1. 关键决策点：哪些决策改变了游戏走向
2. 发言质量：逻辑是否自洽、是否成功说服他人
3. 策略评价：策略选择是否合理
4. 改进建议：具体的改进方向

输出 JSON 格式：
{
  "game_overview": "2-3句游戏概述",
  "key_moments": ["关键转折点1", "关键转折点2"],
  "players": {
    "玩家名": {
      "role": "角色",
      "is_winner": true/false,
      "summary": "一句话总结表现",
      "strategies": "使用的主要策略",
      "mistakes": "主要失误",
      "lessons": "改进建议"
    }
  }
}"""


class SummaryAgent:
    """复盘 Agent：游戏结束后生成总结并提取经验供后续对局参考"""

    def __init__(self, llm_client: Optional[LLMClient] = None):
        self.llm = llm_client or LLMClient()

    async def generate_summary(self, game_log: List[Dict], players_info: Dict) -> Dict:
        """
        生成游戏复盘总结

        Args:
            game_log: 游戏日志，包含每轮的阶段、发言、投票、行动记录
            players_info: 玩家信息 {玩家名: {role, is_alive, is_winner, ...}}

        Returns:
            结构化复盘结果 dict
        """
        game_text = self._format_game_log(game_log, players_info)

        user_prompt = f"请对以下狼人杀对局进行复盘分析：\n\n{game_text}"

        try:
            result = await self.llm.chat_json(
                messages=[
                    {"role": "system", "content": SUMMARY_SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
            )
            if not result or "players" not in result:
                result = self._fallback_summary(game_log, players_info)
        except Exception as e:
            logger.warning(f"LLM 复盘失败，使用简化总结: {e}")
            result = self._fallback_summary(game_log, players_info)

        # 保存每位玩家的经验
        self._save_experiences(result, players_info)

        return result

    def _format_game_log(self, game_log: List[Dict], players_info: Dict) -> str:
        """将游戏日志格式化为可读文本，供 LLM 分析"""
        lines = ["=== 游戏记录 ==="]

        for entry in game_log:
            phase = entry.get("phase", "")
            round_num = entry.get("round", "")

            if phase == "night":
                lines.append(f"\n--- 第{round_num}夜 ---")
                actions = entry.get("actions", {})
                for role, action in actions.items():
                    lines.append(f"  {role}: {action}")

            elif phase == "day_speech":
                lines.append(f"\n--- 第{round_num}天 发言阶段 ---")
                speeches = entry.get("speeches", [])
                for s in speeches:
                    player = s.get("player", "未知")
                    content = s.get("content", "")
                    lines.append(f"  {player}: {content[:100]}...")

            elif phase == "day_vote":
                lines.append(f"\n--- 第{round_num}天 投票阶段 ---")
                votes = entry.get("votes", {})
                for voter, target in votes.items():
                    lines.append(f"  {voter} -> {target}")
                eliminated = entry.get("eliminated", "")
                if eliminated:
                    lines.append(f"  出局: {eliminated}")

        # 玩家信息
        lines.append("\n=== 玩家结果 ===")
        for name, info in players_info.items():
            role = info.get("role", "未知")
            winner = "胜利" if info.get("is_winner", False) else "失败"
            alive = "存活" if info.get("is_alive", False) else "死亡"
            lines.append(f"  {name}: {role} | {alive} | {winner}")

        return "\n".join(lines)

    def _fallback_summary(self, game_log: List[Dict], players_info: Dict) -> Dict:
        """LLM 失败时的简化总结"""
        players = {}
        for name, info in players_info.items():
            players[name] = {
                "role": info.get("role", "未知"),
                "is_winner": info.get("is_winner", False),
                "summary": "复盘生成失败",
                "strategies": "",
                "mistakes": "",
                "lessons": "",
            }
        return {
            "game_overview": "复盘生成失败",
            "key_moments": [],
            "players": players,
        }

    def _save_experiences(self, summary: Dict, players_info: Dict) -> None:
        """将复盘结果中每位玩家的经验保存到经验库"""
        players_summary = summary.get("players", {})

        for name, player_summary in players_summary.items():
            role = player_summary.get("role", "未知")
            # 映射角色名到经验分类
            role_type = self._normalize_role(role)

            experience = {
                "is_winner": player_summary.get("is_winner", False),
                "summary": player_summary.get("summary", ""),
                "strategies": player_summary.get("strategies", ""),
                "mistakes": player_summary.get("mistakes", ""),
                "lessons": player_summary.get("lessons", ""),
            }

            try:
                save_experience(role_type, experience)
            except Exception as e:
                logger.warning(f"保存 {name}({role_type}) 经验失败: {e}")

    @staticmethod
    def _normalize_role(role: str) -> str:
        """统一角色名称用于经验分类"""
        mapping = {
            "werewolf": "werewolf", "狼人": "werewolf",
            "seer": "seer", "预言家": "seer",
            "witch": "witch", "女巫": "witch",
            "hunter": "hunter", "猎人": "hunter",
            "villager": "villager", "村民": "villager",
        }
        return mapping.get(role.lower(), role.lower())
