"""猎人 Agent"""

from typing import Optional

from ..engine.state import GameState
from .base_agent import BaseAgent


class HunterAgent(BaseAgent):
    """猎人 Agent：死亡时可开枪带走一名玩家，被毒杀时不能开枪（闷枪）"""

    async def decide_night_action(self, game: GameState) -> dict:
        """猎人在夜间无行动"""
        return {"action": "pass", "target": None}

    async def decide_hunter_shoot(self, game: GameState) -> Optional[int]:
        """决策开枪目标，被毒杀时返回 None"""
        player = game.get_player(self.player_id)
        if not player or player.hunter_can_shoot is False:
            return None
        return await super().decide_hunter_shoot(game)