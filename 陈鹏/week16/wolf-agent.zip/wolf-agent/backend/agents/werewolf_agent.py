"""狼人 Agent"""

import json
from typing import Dict, Any, Optional, List

from ..llm.prompts import format_prompt, NIGHT_ACTION_PROMPTS, WOLF_PROPOSAL_PROMPT, WOLF_DECIDE_PROMPT
from ..engine.state import Role, GameState
from .base_agent import BaseAgent


class WerewolfAgent(BaseAgent):
    """狼人 Agent：夜间击杀 + 多狼协商"""

    async def decide_night_action(self, game: GameState) -> Dict[str, Any]:
        # 狼人看到同伴信息，LLM 决策
        result = await super().decide_night_action(game)
        target = result.get("target")

        # 策略参数：wolf_aggression 影响目标选择
        sp = self.strategy_params
        if sp and sp.wolf_aggression > 0.7 and isinstance(target, int):
            # 高侵略性：优先击杀神职玩家
            target_player = game.get_player(target)
            if target_player and target_player.role == Role.VILLAGER:
                # 如果 LLM 选了村民且侵略性高，考虑换目标
                gods = [p for p in game.get_alive_players()
                        if p.role in (Role.SEER, Role.WITCH, Role.HUNTER) and p.player_id != self.player_id]
                if gods:
                    import random as _r
                    target = _r.choice(gods).player_id
                    result["target"] = target
                    result["reasoning"] = f"高侵略性策略：优先击杀神职 ({result.get('reasoning', '')})"

        if isinstance(target, int):
            target_player = game.get_player(target)
            if target_player and target_player.alive and target_player.role != Role.WEREWOLF:
                return result
        # 回退：随机选一个存活的非狼人
        alive_non_wolves = [
            p for p in game.get_alive_players() if p.role != Role.WEREWOLF
        ]
        if alive_non_wolves:
            return {"target": alive_non_wolves[0].player_id, "reasoning": "默认目标"}
        return {"target": None, "reasoning": "无可用目标"}

    async def decide_wolf_target(self, game: GameState, teammate_suggestions: Optional[List[Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
        """狼人协商：先提议或结合队友建议做最终决定"""
        ctx = game.get_private_context(self.player_id)
        alive_non_wolves = [str(p.player_id) for p in game.get_alive_players() if p.role != Role.WEREWOLF]

        if not teammate_suggestions:
            # 第一轮：提议目标
            prompt = format_prompt(
                WOLF_PROPOSAL_PROMPT,
                game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
                private_info=json.dumps(ctx.get("my_info", {}), ensure_ascii=False),
                alive_non_wolves=", ".join(alive_non_wolves),
            )
        else:
            # 第二轮：结合队友建议最终决定
            proposals_text = "\n".join(
                f"- 玩家{s['player_id']}建议击杀玩家{s['target']}，理由：{s.get('reasoning', '无')}"
                for s in teammate_suggestions
            )
            prompt = format_prompt(
                WOLF_DECIDE_PROMPT,
                game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
                private_info=json.dumps(ctx.get("my_info", {}), ensure_ascii=False),
                proposals=proposals_text,
                alive_non_wolves=", ".join(alive_non_wolves),
            )

        result = await self.llm.decide_action(self.system_prompt, prompt)
        target = result.get("target")

        # 校验目标合法性
        if isinstance(target, int):
            target_player = game.get_player(target)
            if target_player and target_player.alive and target_player.role != Role.WEREWOLF:
                return {"player_id": self.player_id, "target": target, "reasoning": result.get("reasoning", "")}

        # 回退
        alive_non_wolves_list = [p for p in game.get_alive_players() if p.role != Role.WEREWOLF]
        if alive_non_wolves_list:
            return {"player_id": self.player_id, "target": alive_non_wolves_list[0].player_id, "reasoning": "回退默认"}
        return None