"""预言家 Agent"""

import json
from typing import Dict, Any

from ..llm.prompts import format_prompt, SPEECH_PROMPT
from ..engine.state import Role, GameState
from .base_agent import BaseAgent


class SeerAgent(BaseAgent):
    """预言家 Agent：夜间查验一名玩家，获知其阵营"""

    async def decide_night_action(self, game: GameState) -> Dict[str, Any]:
        """决策查验目标，优先查未查过的存活玩家"""
        result = await super().decide_night_action(game)
        target = result.get("target")
        if isinstance(target, int):
            target_player = game.get_player(target)
            if target_player and target_player.alive and target != self.player_id:
                return result
        # 回退：查验一个未查验过的存活玩家
        me = game.get_player(self.player_id)
        checked_ids = set() if not me else {c["target"] for c in me.seer_checks}
        unchecked = [
            p for p in game.get_alive_players()
            if p.player_id != self.player_id and p.player_id not in checked_ids
        ]
        if unchecked:
            return {"target": unchecked[0].player_id, "reasoning": "查验未查过的玩家"}
        return {"target": None, "reasoning": "无可用目标"}

    async def decide_speech(self, game: GameState) -> str:
        """预言家发言 — god_claim_tendency 影响是否跳预言家"""
        sp = self.strategy_params
        ctx = game.get_private_context(self.player_id)

        # 策略参数：god_claim_tendency 影响是否在发言中暴露身份
        if sp and sp.god_claim_tendency < 0.3:
            # 低声明倾向：隐藏身份，不提及查验结果
            memory_context = ""
            recalled = self._recall("预言家隐藏策略")
            if recalled:
                memory_context = f"\n历史经验参考：\n{recalled}\n"
            prompt = format_prompt(
                SPEECH_PROMPT,
                game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
                private_info="你的角色是村民（隐藏预言家身份）",
                role_name="村民",
                memory_context=memory_context,
            )
        else:
            # 正常或高声明倾向：可能跳预言家
            memory_context = ""
            recalled = self._recall("预言家跳身份策略")
            if recalled:
                memory_context = f"\n历史经验参考：\n{recalled}\n"
            prompt = format_prompt(
                SPEECH_PROMPT,
                game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
                private_info=json.dumps(ctx.get("my_info", {}), ensure_ascii=False),
                role_name="预言家",
                memory_context=memory_context,
            )

        result = await self.llm.decide_action(self.system_prompt, prompt)
        return result.get("content", "我暂时没有什么要说的。")