"""女巫 Agent"""

from typing import Dict, Any, Optional

from ..engine.state import GameState
from .base_agent import BaseAgent


class WitchAgent(BaseAgent):
    """女巫 Agent：解药救人 / 毒药杀人，同一夜双药互斥"""

    async def decide_night_action(self, game: GameState) -> Dict[str, Any]:
        """决策是否使用解药或毒药，同夜只能选一种"""
        player = game.get_player(self.player_id)
        if not player or not player.alive:
            return {"action": "pass", "target": None}

        # 没有被杀的人，或既无解药也无毒药
        if game.wolf_target is None and not player.witch_has_poison:
            return {"action": "pass", "target": None}

        result = await super().decide_night_action(game)
        action = result.get("action", "pass")
        target = result.get("target")

        # 校验药物是否可用
        if action == "heal" and not player.witch_has_heal:
            action = "pass"
        # 安全防护：女巫不能自救
        if action == "heal" and target == self.player_id:
            action = "pass"
        if action == "poison" and not player.witch_has_poison:
            action = "pass"

        return result if action != "pass" else {"action": "pass", "target": None}