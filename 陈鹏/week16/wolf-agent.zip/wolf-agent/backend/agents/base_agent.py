"""Agent 基类 — 观察→思考→行动 循环"""

import json
import random
from abc import ABC
from typing import Dict, Any, Optional

from ..llm.client import LLMClient
from ..llm.prompts import ROLE_SYSTEM_PROMPTS, format_prompt, NIGHT_ACTION_PROMPTS, SPEECH_PROMPT, VOTE_PROMPT
from ..engine.state import Role, GameState, ROLE_NAMES
from ..memory.experience import get_experience_prompt


class BaseAgent(ABC):
    """Agent 基类：封装 LLM 调用、Prompt 拼接、JSON 解析的公共逻辑"""

    def __init__(self, player_id: int, role: Role, llm: LLMClient, memory=None, strategy_params=None):
        self.player_id = player_id
        self.role = role
        self.llm = llm
        self.memory = memory
        self.strategy_params = strategy_params
        self.knowledge: list[Dict[str, Any]] = []

    @property
    def system_prompt(self) -> str:
        """根据角色和游戏状态构建 System Prompt，注入历史经验"""
        base_prompt = ROLE_SYSTEM_PROMPTS[self.role]
        experience_text = get_experience_prompt(self.role.value)
        if experience_text:
            return base_prompt + experience_text
        return base_prompt

    def receive_info(self, info: Dict[str, Any]):
        """接收角色允许的信息（信息隔离入口）"""
        self.knowledge.append(info)

    async def decide_night_action(self, game: GameState) -> Dict[str, Any]:
        """夜间行动决策"""
        ctx = game.get_private_context(self.player_id)
        template = NIGHT_ACTION_PROMPTS.get(self.role)
        if not template:
            return {"action": "pass", "target": None}

        kwargs = {
            "game_context": json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
            "private_info": json.dumps(ctx.get("my_info", {}), ensure_ascii=False, indent=2),
        }
        # 女巫专属：传入被杀玩家信息
        if self.role == Role.WITCH:
            kwargs["tonight_victim"] = str(game.wolf_target) if game.wolf_target is not None else "无"

        prompt = format_prompt(template, **kwargs)
        return await self.llm.decide_action(self.system_prompt, prompt)

    async def decide_speech(self, game: GameState) -> str:
        """白天发言"""
        ctx = game.get_private_context(self.player_id)
        # 可选注入记忆
        memory_context = ""
        recalled = self._recall(f"角色{self.role.value}发言策略")
        if recalled:
            memory_context = f"\n历史经验参考：\n{recalled}\n"
        prompt = format_prompt(
            SPEECH_PROMPT,
            game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
            private_info=json.dumps(ctx.get("my_info", {}), ensure_ascii=False),
            role_name=ROLE_NAMES[self.role],
            memory_context=memory_context,
        )
        result = await self.llm.decide_action(self.system_prompt, prompt)
        return result.get("content", "我暂时没有什么要说的。")

    async def decide_vote(self, game: GameState) -> Optional[int]:
        """投票决策 — 策略参数影响投票行为"""
        ctx = game.get_private_context(self.player_id)
        alive_ids = [p.player_id for p in game.get_alive_players() if p.player_id != self.player_id]
        if not alive_ids:
            return None

        # 策略参数：从众倾向影响是否跟随多数
        sp = self.strategy_params
        if sp and random.random() < sp.herd_tendency:
            # 从众投票：查看已有投票记录，投给票数最多的
            vote_tally: Dict[int, int] = {}
            for v in game.votes:
                vote_tally[v.target_id] = vote_tally.get(v.target_id, 0) + 1
            if vote_tally:
                max_v = max(vote_tally.values())
                top_targets = [t for t, c in vote_tally.items() if c == max_v and t in alive_ids]
                if top_targets:
                    return random.choice(top_targets)

        prompt = format_prompt(
            VOTE_PROMPT,
            game_context=json.dumps(ctx, ensure_ascii=False, indent=2)[:2000],
            private_info=json.dumps(ctx.get("my_info", {}), ensure_ascii=False),
            role_name=ROLE_NAMES[self.role],
            alive_list=alive_ids,
        )
        result = await self.llm.decide_action(self.system_prompt, prompt)
        target = result.get("target")
        if isinstance(target, int) and target in alive_ids:
            # 策略参数：怀疑阈值过滤
            if sp and sp.suspicion_threshold > 0.8:
                # 高怀疑阈值：需要更多证据才投票
                pass
            return target
        return None

    async def decide_hunter_shoot(self, game: GameState) -> Optional[int]:
        """猎人开枪决策"""
        from ..llm.prompts import HUNTER_SHOOT_PROMPT
        alive_ids = [p.player_id for p in game.get_alive_players()]
        prompt = format_prompt(
            HUNTER_SHOOT_PROMPT,
            game_context=json.dumps(game.get_public_context(), ensure_ascii=False, indent=2)[:2000],
            alive_list=alive_ids,
        )
        result = await self.llm.decide_action(self.system_prompt, prompt)
        target = result.get("target")
        if isinstance(target, int) and target in alive_ids:
            return target
        return None

    async def decide_wolf_target(self, game: GameState, teammate_suggestions: Optional[list] = None) -> Optional[Dict[str, Any]]:
        """狼人协商：提议或最终决定击杀目标。子类可重写。"""
        return None

    def _recall(self, query: str, n: int = 3) -> Optional[str]:
        """查询向量记忆，返回相关历史文本。无记忆时返回 None。"""
        if not self.memory:
            return None
        results = self.memory.query_similar(query, n_results=n, role=self.role.value)
        if not results:
            return None
        return "\n".join(r["content"] for r in results)