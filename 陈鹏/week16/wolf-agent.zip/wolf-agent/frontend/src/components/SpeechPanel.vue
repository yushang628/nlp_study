<script setup>
import { ref, watch, nextTick } from 'vue'

const props = defineProps({
  speeches: { type: Array, default: () => [] },
  players: { type: Array, default: () => [] },
})

const container = ref(null)

watch(() => props.speeches.length, async () => {
  await nextTick()
  if (container.value) {
    container.value.scrollTop = container.value.scrollHeight
  }
})

function playerName(pid) {
  const p = props.players.find(x => x.player_id === pid)
  return p?.name || `玩家${pid}`
}

function playerRole(pid) {
  const p = props.players.find(x => x.player_id === pid)
  return p?.role || ''
}

const roleIcon = {
  werewolf: '🐺',
  seer: '🔮',
  witch: '🧪',
  hunter: '🏹',
  villager: '👤',
}

function bubbleClass(pid) {
  const role = playerRole(pid)
  return role || 'unknown'
}
</script>

<template>
  <section class="speech-panel">
    <h3 class="panel-title">💬 公开演讲</h3>
    <div class="speech-list" ref="container">
      <div
        v-for="(s, i) in speeches"
        :key="i"
        class="speech-bubble"
        :class="bubbleClass(s.player_id)"
      >
        <div class="bubble-header">
          <span class="bubble-name">
            {{ roleIcon[playerRole(s.player_id)] || '' }}
            {{ playerName(s.player_id) }}
          </span>
        </div>
        <div class="bubble-content">{{ s.content }}</div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.speech-panel {
  margin-bottom: 24px;
}

.panel-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 12px;
}

.speech-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 400px;
  overflow-y: auto;
  padding-right: 4px;
}

.speech-list::-webkit-scrollbar {
  width: 5px;
}

.speech-list::-webkit-scrollbar-thumb {
  background: var(--border-color);
  border-radius: 3px;
}

.speech-bubble {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 10px 14px;
  animation: fadeSlideIn 0.3s ease;
}

.speech-bubble.werewolf {
  border-left: 3px solid var(--wolf-color);
}

.speech-bubble.seer {
  border-left: 3px solid var(--seer-color);
}

.speech-bubble.witch {
  border-left: 3px solid var(--witch-color);
}

.speech-bubble.hunter {
  border-left: 3px solid var(--hunter-color);
}

.speech-bubble.villager {
  border-left: 3px solid var(--villager-color);
}

.bubble-header {
  margin-bottom: 4px;
}

.bubble-name {
  font-size: 13px;
  font-weight: 600;
}

.bubble-content {
  font-size: 14px;
  line-height: 1.7;
  color: var(--text-primary);
  white-space: pre-wrap;
}

@keyframes fadeSlideIn {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>