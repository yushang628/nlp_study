<script setup>
import { ref } from 'vue'

const props = defineProps({
  configs: { type: Object, default: () => ({}) },
})

const emit = defineEmits(['create'])

const selectedConfig = ref('standard_6')
const playerNames = ref('')

function handleSubmit() {
  const names = playerNames.value.trim()
    ? playerNames.value.split(/[,，\s]+/).filter(Boolean)
    : null
  emit('create', selectedConfig.value, names)
}
</script>

<template>
  <div class="setup-container">
    <div class="setup-card">
      <h2 class="setup-title">创建新游戏</h2>

      <div class="form-group">
        <label class="form-label">游戏配置</label>
        <select v-model="selectedConfig">
          <option v-for="(cfg, key) in configs" :key="key" :value="key">
            {{ cfg.name }}（{{ cfg.player_count }}人）— {{ cfg.description }}
          </option>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label">玩家名称（可选，逗号分隔）</label>
        <input
          v-model="playerNames"
          type="text"
          placeholder="玩家1,玩家2,玩家3..."
          class="form-input"
        />
      </div>

      <button class="primary submit-btn" @click="handleSubmit">
        开始游戏
      </button>
    </div>
  </div>
</template>

<style scoped>
.setup-container {
  display: flex;
  justify-content: center;
  padding-top: 60px;
}

.setup-card {
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  padding: 36px;
  width: 100%;
  max-width: 520px;
}

.setup-title {
  font-size: 22px;
  font-weight: 600;
  margin-bottom: 28px;
  text-align: center;
}

.form-group {
  margin-bottom: 20px;
}

.form-label {
  display: block;
  font-size: 14px;
  font-weight: 500;
  color: var(--text-secondary);
  margin-bottom: 8px;
}

.form-input {
  width: 100%;
  background: var(--bg-primary);
  color: var(--text-primary);
  border: 1px solid var(--border-color);
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 14px;
  font-family: inherit;
}

.form-input:focus {
  outline: none;
  border-color: var(--accent-blue);
}

.submit-btn {
  width: 100%;
  padding: 12px;
  font-size: 16px;
  font-weight: 600;
}
</style>