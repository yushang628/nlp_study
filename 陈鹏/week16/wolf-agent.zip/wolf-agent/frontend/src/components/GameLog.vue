<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  events: { type: Array, default: () => [] },
})

const expanded = ref(true)
const autoScroll = ref(true)
const logContainer = ref(null)

watch(() => props.events.length, () => {
  if (autoScroll.value && logContainer.value) {
    logContainer.value.scrollTop = logContainer.value.scrollHeight
  }
})

const eventIcons = {
  game_start: '🎮',
  phase_change: '🔄',
  skill: '⚡',
  save: '💊',
  death: '✝️',
  speech: '💬',
  vote_result: '🗳️',
  vote_eliminated: '⚠️',
  hunter_can_shoot: '🏹',
  night_deaths: '🌙',
  game_over: '🏆',
}

const phaseLabels = {
  night_start: '夜晚降临',
  wolf_turn: '狼人行动',
  seer_turn: '预言家查验',
  witch_turn: '女巫用药',
  night_end: '夜晚结束',
  day_start: '天亮了',
  speech: '公开演讲',
  vote: '投票环节',
  day_end: '白天结束',
  game_over: '游戏结束',
}

function eventText(e) {
  const data = e.data || {}
  switch (e.event_type) {
    case 'game_start':
      return `游戏开始！${(data.players || []).length}名玩家参与`
    case 'phase_change':
      return phaseLabels[data.phase] || data.phase || '阶段变更'
    case 'speech':
      return `玩家${data.player_id} 发言`
    case 'vote_result': {
      const votes = data.votes || []
      return `投票完成，共${votes.length}票`
    }
    case 'death':
      return `玩家${data.player_id} 死亡`
    case 'save':
      return `玩家${data.target} 被救活`
    case 'skill': {
      const roleMap = { werewolf: '狼人', seer: '预言家', witch: '女巫' }
      return `${roleMap[data.role] || data.role} 使用技能`
    }
    case 'night_deaths': {
      const deaths = data.deaths || []
      return deaths.length ? `夜晚死亡：${deaths.map(d => '玩家' + d).join('、')}` : '平安夜'
    }
    case 'vote_eliminated':
      return `玩家${data.player_id} 被投票出局`
    case 'vote_tie':
      return `平票，无人出局`
    case 'hunter_shoot':
      return `猎人开枪带走玩家${data.target_id}`
    case 'game_over':
      return data.winner === 'good' ? '好人阵营胜利！' : '狼人阵营胜利！'
    default:
      return e.event_type
  }
}
</script>

<template>
  <section class="log-panel">
    <div class="log-header" @click="expanded = !expanded">
      <h3 class="panel-title">📜 游戏日志</h3>
      <span class="toggle">{{ expanded ? '▼' : '▶' }}</span>
    </div>

    <div v-if="expanded" class="log-list" ref="logContainer">
      <div
        v-for="(e, i) in events"
        :key="i"
        class="log-entry"
        :class="e.event_type"
      >
        <span class="log-icon">{{ eventIcons[e.event_type] || '•' }}</span>
        <span class="log-day" v-if="e.day">D{{ e.day }}</span>
        <span class="log-text">{{ eventText(e) }}</span>
      </div>
      <div v-if="!events.length" class="log-empty">暂无事件</div>
    </div>
  </section>
</template>

<style scoped>
.log-panel {
  margin-top: 24px;
  border-top: 1px solid var(--border-color);
  padding-top: 20px;
}

.log-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  user-select: none;
}

.panel-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-secondary);
}

.toggle {
  font-size: 12px;
  color: var(--text-muted);
}

.log-list {
  max-height: 300px;
  overflow-y: auto;
  padding: 8px 0;
}

.log-list::-webkit-scrollbar {
  width: 5px;
}

.log-list::-webkit-scrollbar-thumb {
  background: var(--border-color);
  border-radius: 3px;
}

.log-entry {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 5px 8px;
  border-radius: 4px;
  font-size: 13px;
  transition: background 0.2s;
}

.log-entry:hover {
  background: var(--bg-hover);
}

.log-entry.death,
.log-entry.vote_eliminated {
  color: var(--accent-red);
}

.log-entry.save {
  color: var(--accent-green);
}

.log-entry.game_over {
  font-weight: 600;
}

.log-icon {
  font-size: 14px;
  width: 20px;
  text-align: center;
}

.log-day {
  font-size: 11px;
  color: var(--text-muted);
  font-family: monospace;
  min-width: 28px;
}

.log-text {
  flex: 1;
}

.log-empty {
  text-align: center;
  color: var(--text-muted);
  padding: 24px;
  font-size: 14px;
}
</style>