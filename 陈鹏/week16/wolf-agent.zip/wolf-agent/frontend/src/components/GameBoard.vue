<script setup>
import { computed } from 'vue'
import PlayerCard from './PlayerCard.vue'
import SpeechPanel from './SpeechPanel.vue'
import VotePanel from './VotePanel.vue'

const props = defineProps({
  game: { type: Object, required: true },
  events: { type: Array, default: () => [] },
})

const alivePlayers = computed(() =>
  (props.game.players || []).filter(p => p.alive)
)

const deadPlayers = computed(() =>
  (props.game.players || []).filter(p => !p.alive)
)

const isNight = computed(() => {
  const nightPhases = ['night_start', 'wolf_turn', 'seer_turn', 'witch_turn', 'night_end']
  return nightPhases.includes(props.game.phase)
})

const currentSpeeches = computed(() => {
  const day = props.game.round || 1
  return (props.game.speeches || []).filter(s => s.day === day)
})

const currentVotes = computed(() => {
  const day = props.game.round || 1
  return (props.game.votes || []).filter(v => v.day === day)
})
</script>

<template>
  <div class="board" :class="{ night: isNight }">
    <!-- 玩家区域 -->
    <section class="section">
      <h3 class="section-title">
        存活玩家
        <span class="count">{{ alivePlayers.length }}</span>
      </h3>
      <div class="player-grid">
        <PlayerCard
          v-for="p in alivePlayers"
          :key="p.player_id"
          :player="p"
          :alive="true"
          :show-role="false"
        />
      </div>
    </section>

    <section class="section" v-if="deadPlayers.length">
      <h3 class="section-title">
        已出局
        <span class="count dead">{{ deadPlayers.length }}</span>
      </h3>
      <div class="player-grid dead-grid">
        <PlayerCard
          v-for="p in deadPlayers"
          :key="p.player_id"
          :player="p"
          :alive="false"
          :show-role="true"
        />
      </div>
    </section>

    <!-- 发言面板 -->
    <SpeechPanel
      v-if="currentSpeeches.length"
      :speeches="currentSpeeches"
      :players="game.players"
    />

    <!-- 投票面板 -->
    <VotePanel
      v-if="currentVotes.length"
      :votes="currentVotes"
      :players="game.players"
    />
  </div>
</template>

<style scoped>
.board {
  transition: background 0.5s;
  padding: 20px 0;
}

.board.night {
  background: radial-gradient(ellipse at center, rgba(10, 14, 26, 0.4) 0%, transparent 70%);
}

.section {
  margin-bottom: 24px;
}

.section-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.count {
  background: var(--bg-hover);
  color: var(--text-primary);
  font-size: 12px;
  padding: 2px 8px;
  border-radius: 10px;
}

.count.dead {
  background: rgba(248, 81, 73, 0.15);
  color: var(--accent-red);
}

.player-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 12px;
}

.dead-grid {
  opacity: 0.7;
}
</style>