<script setup>
import { computed } from 'vue'

const props = defineProps({
  player: { type: Object, required: true },
  alive: { type: Boolean, default: true },
  showRole: { type: Boolean, default: false },
})

const roleLabels = {
  werewolf: '🐺 狼人',
  seer: '🔮 预言家',
  witch: '🧪 女巫',
  hunter: '🏹 猎人',
  villager: '👤 村民',
}

const roleColors = {
  werewolf: 'var(--wolf-color)',
  seer: 'var(--seer-color)',
  witch: 'var(--witch-color)',
  hunter: 'var(--hunter-color)',
  villager: 'var(--villager-color)',
}

// camp 可能不存在（存活玩家不揭示角色时）
const campClass = computed(() => {
  if (props.player.camp) return props.player.camp
  return props.alive ? 'unknown' : ''
})

const campText = computed(() => {
  if (props.player.camp === 'good') return '好人'
  if (props.player.camp === 'evil') return '狼人'
  return props.alive ? '未知' : ''
})
</script>

<template>
  <div class="card" :class="{ dead: !alive, [campClass]: true }">
    <div class="status-dot" :class="alive ? 'alive' : 'dead'"></div>

    <div class="player-id">#{{ player.player_id }}</div>
    <div class="player-name">{{ player.name }}</div>

    <div
      v-if="showRole || !alive"
      class="role-badge"
      :style="{ color: roleColors[player.role] || '#ccc' }"
    >
      {{ roleLabels[player.role] || player.role }}
    </div>
    <div v-else class="role-badge unknown">❓ 未知</div>

    <div v-if="campText" class="camp-badge" :class="player.camp || 'unknown'">
      {{ campText }}
    </div>
  </div>
</template>

<style scoped>
.card {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 14px 10px;
  text-align: center;
  position: relative;
  transition: all 0.3s;
}

.card.good {
  border-left: 3px solid var(--good-color);
}

.card.evil {
  border-left: 3px solid var(--evil-color);
}

.card.unknown {
  border-left: 3px solid var(--text-muted);
}

.card.dead {
  opacity: 0.45;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  position: absolute;
  top: 10px;
  right: 10px;
}

.status-dot.alive {
  background: var(--accent-green);
  box-shadow: 0 0 6px var(--accent-green);
}

.status-dot.dead {
  background: var(--accent-red);
}

.player-id {
  font-size: 11px;
  color: var(--text-muted);
  margin-bottom: 2px;
}

.player-name {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 8px;
}

.role-badge {
  font-size: 13px;
  margin-bottom: 6px;
}

.role-badge.unknown {
  color: var(--text-muted);
}

.camp-badge {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 10px;
  display: inline-block;
  font-weight: 500;
}

.camp-badge.good {
  background: rgba(63, 185, 80, 0.15);
  color: var(--good-color);
}

.camp-badge.evil {
  background: rgba(248, 81, 73, 0.15);
  color: var(--evil-color);
}

.camp-badge.unknown {
  background: rgba(139, 148, 158, 0.15);
  color: var(--text-muted);
}
</style>