<script setup>
import { computed } from 'vue'

const props = defineProps({
  votes: { type: Array, default: () => [] },
  players: { type: Array, default: () => [] },
})

function playerName(pid) {
  const p = props.players.find(x => x.player_id === pid)
  return p?.name || `玩家${pid}`
}

// 计票结果
const tally = computed(() => {
  const counts = {}
  for (const v of props.votes) {
    counts[v.target_id] = (counts[v.target_id] || 0) + 1
  }
  return Object.entries(counts)
    .map(([id, cnt]) => ({ id: Number(id), count: cnt, name: playerName(Number(id)) }))
    .sort((a, b) => b.count - a.count)
})
</script>

<template>
  <section class="vote-panel">
    <h3 class="panel-title">🗳️ 投票结果</h3>

    <!-- 投票详情 -->
    <div class="vote-details">
      <div v-for="(v, i) in votes" :key="i" class="vote-row">
        <span class="voter">{{ playerName(v.voter_id) }}</span>
        <span class="arrow">→</span>
        <span class="target">{{ playerName(v.target_id) }}</span>
      </div>
    </div>

    <!-- 计票柱状 -->
    <div class="tally" v-if="tally.length">
      <div class="panel-subtitle">计票统计</div>
      <div v-for="t in tally" :key="t.id" class="tally-row">
        <span class="tally-name">{{ t.name }}</span>
        <div class="tally-bar-bg">
          <div
            class="tally-bar"
            :style="{ width: (t.count / votes.length * 100) + '%' }"
          ></div>
        </div>
        <span class="tally-count">{{ t.count }}票</span>
      </div>
    </div>
  </section>
</template>

<style scoped>
.vote-panel {
  margin-bottom: 24px;
}

.panel-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 12px;
}

.panel-subtitle {
  font-size: 13px;
  color: var(--text-muted);
  margin: 16px 0 8px;
}

.vote-details {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.vote-row {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 8px;
  padding: 6px 12px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.voter {
  color: var(--text-primary);
  font-weight: 500;
}

.arrow {
  color: var(--text-muted);
}

.target {
  color: var(--accent-yellow);
  font-weight: 500;
}

.tally {
  margin-top: 12px;
}

.tally-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 6px;
}

.tally-name {
  font-size: 13px;
  width: 70px;
  text-align: right;
  color: var(--text-secondary);
}

.tally-bar-bg {
  flex: 1;
  height: 8px;
  background: var(--bg-primary);
  border-radius: 4px;
  overflow: hidden;
}

.tally-bar {
  height: 100%;
  background: var(--accent-yellow);
  border-radius: 4px;
  transition: width 0.5s ease;
  min-width: 4px;
}

.tally-count {
  font-size: 12px;
  color: var(--text-muted);
  width: 40px;
}
</style>