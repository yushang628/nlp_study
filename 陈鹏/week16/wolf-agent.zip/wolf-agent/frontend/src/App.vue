<script setup>
import { ref, computed } from 'vue'
import { fetchConfigs, createGame, startGame, connectGameWS } from './api.js'
import GameSetup from './components/GameSetup.vue'
import GameBoard from './components/GameBoard.vue'
import GameLog from './components/GameLog.vue'

const view = ref('setup') // setup | playing
const gameId = ref(null)
const gameState = ref(null)
const events = ref([])
const ws = ref(null)
const gameStarted = ref(false)
const configs = ref({})

fetchConfigs().then(c => configs.value = c).catch(() => {})

function onEvent(event) {
  events.value.push(event)

  if (!gameState.value) return

  // 更新阶段
  if (event.event_type === 'phase_change') {
    gameState.value.phase = event.data.phase
    // 日夜切换时更新轮次
    if (event.data.day) {
      gameState.value.round = event.data.day
    }
  }

  // 死亡
  if (event.event_type === 'death') {
    const pid = event.data.player_id
    const p = gameState.value.players.find(x => x.player_id === pid)
    if (p) {
      p.alive = false
      // 死亡揭示角色
      if (event.data.role) p.role = event.data.role
      if (event.data.role === 'werewolf') p.camp = 'evil'
      else if (event.data.role) p.camp = 'good'
    }
  }

  // 发言
  if (event.event_type === 'speech') {
    gameState.value.speeches.push({
      player_id: event.data.player_id,
      content: event.data.content,
      day: event.data.day || gameState.value.round,
    })
  }

  // 投票
  if (event.event_type === 'vote_result') {
    for (const v of (event.data.votes || [])) {
      gameState.value.votes.push({
        voter_id: v.voter,
        target_id: v.target,
        day: event.data.day || gameState.value.round,
      })
    }
  }

  // 游戏结束 — 揭示所有角色
  if (event.event_type === 'game_over') {
    gameState.value.winner = event.data.winner
    gameState.value.phase = 'game_over'
    // 重新获取完整状态（含角色揭示）
    fetch(`/api/games/${gameId.value}`)
      .then(r => r.json())
      .then(data => { gameState.value = data })
      .catch(() => {})
    ws.value?.close()
  }
}

async function handleCreateGame(roleConfig, playerNames) {
  const game = await createGame(roleConfig, playerNames)
  gameId.value = game.game_id
  gameState.value = game
  events.value = []
  gameStarted.value = false
  view.value = 'playing'

  ws.value = connectGameWS(game.game_id, onEvent)
}

async function handleStartGame() {
  if (gameStarted.value) return
  gameStarted.value = true
  try {
    await startGame(gameId.value)
  } catch (e) {
    console.error('Start game failed:', e)
    gameStarted.value = false
  }
}

function handleNewGame() {
  ws.value?.close()
  gameId.value = null
  gameState.value = null
  events.value = []
  gameStarted.value = false
  view.value = 'setup'
}

const phaseLabel = computed(() => {
  const labels = {
    night_start: '夜晚降临',
    wolf_turn: '狼人行动',
    seer_turn: '预言家查验',
    witch_turn: '女巫用药',
    night_end: '夜晚结束',
    day_start: '天亮了',
    speech: '公开演讲',
    vote: '投票环节',
    day_end: '白天结束',
    game_over: '游戏结束',
  }
  return labels[gameState.value?.phase] || gameState.value?.phase || ''
})
</script>

<template>
  <div class="app-container">
    <header class="app-header">
      <h1 class="app-title" @click="handleNewGame" style="cursor:pointer">
        AI 狼人杀
      </h1>
      <span v-if="gameId" class="game-id">Game #{{ gameId }}</span>
    </header>

    <GameSetup
      v-if="view === 'setup'"
      :configs="configs"
      @create="handleCreateGame"
    />

    <template v-else-if="view === 'playing' && gameState">
      <div class="game-controls">
        <span class="phase-badge" :class="gameState.phase">
          {{ phaseLabel }}
        </span>
        <span class="round-badge" v-if="gameState.round">
          第 {{ gameState.round }} 轮
        </span>
        <button
          v-if="gameState.phase !== 'game_over' && !gameStarted"
          class="primary"
          @click="handleStartGame"
        >
          开始游戏
        </button>
        <span v-else-if="gameStarted && gameState.phase !== 'game_over'" class="running-hint">
          游戏进行中...
        </span>
        <button v-if="gameState.phase === 'game_over'" @click="handleNewGame">
          新游戏
        </button>
      </div>

      <div v-if="gameState.winner" class="winner-banner" :class="gameState.winner">
        {{ gameState.winner === 'good' ? '好人阵营胜利！' : '狼人阵营胜利！' }}
      </div>

      <GameBoard :game="gameState" :events="events" />
      <GameLog :events="events" />
    </template>
  </div>
</template>

<style scoped>
.app-container {
  min-height: 100vh;
}

.app-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 0;
  border-bottom: 1px solid var(--border-color);
  margin-bottom: 24px;
}

.app-title {
  font-size: 24px;
  font-weight: 700;
  letter-spacing: 1px;
}

.game-id {
  color: var(--text-muted);
  font-size: 13px;
  font-family: monospace;
}

.game-controls {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 20px;
}

.phase-badge {
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 13px;
  font-weight: 600;
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
}

.phase-badge.night_start,
.phase-badge.wolf_turn,
.phase-badge.seer_turn,
.phase-badge.witch_turn,
.phase-badge.night_end {
  background: rgba(88, 166, 255, 0.1);
  border-color: var(--accent-blue);
  color: var(--accent-blue);
}

.phase-badge.day_start,
.phase-badge.speech,
.phase-badge.vote,
.phase-badge.day_end {
  background: rgba(227, 179, 65, 0.1);
  border-color: var(--accent-yellow);
  color: var(--accent-yellow);
}

.phase-badge.game_over {
  background: rgba(63, 185, 80, 0.1);
  border-color: var(--accent-green);
  color: var(--accent-green);
}

.round-badge {
  color: var(--text-secondary);
  font-size: 13px;
}

.running-hint {
  color: var(--text-muted);
  font-size: 13px;
}

.winner-banner {
  text-align: center;
  padding: 16px;
  border-radius: 8px;
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 20px;
}

.winner-banner.good {
  background: rgba(63, 185, 80, 0.15);
  color: var(--accent-green);
  border: 1px solid rgba(63, 185, 80, 0.3);
}

.winner-banner.evil {
  background: rgba(248, 81, 73, 0.15);
  color: var(--accent-red);
  border: 1px solid rgba(248, 81, 73, 0.3);
}
</style>