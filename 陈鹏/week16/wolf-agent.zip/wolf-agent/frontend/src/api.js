/**
 * API 客户端 + WebSocket 连接
 */

const API_BASE = '/api/games'

export async function fetchConfigs() {
  const resp = await fetch('/api/configs')
  return resp.json()
}

export async function createGame(roleConfig = 'standard_6', playerNames = null) {
  const body = { role_config: roleConfig }
  if (playerNames) body.player_names = playerNames
  const resp = await fetch(API_BASE, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  return resp.json()
}

export async function getGame(gameId) {
  const resp = await fetch(`${API_BASE}/${gameId}`)
  return resp.json()
}

export async function startGame(gameId) {
  const resp = await fetch(`${API_BASE}/${gameId}/start`, { method: 'POST' })
  return resp.json()
}

export async function getGameLog(gameId) {
  const resp = await fetch(`${API_BASE}/${gameId}/log`)
  return resp.json()
}

/**
 * WebSocket 连接，监听游戏实时事件
 * @param {string} gameId
 * @param {function} onEvent - (event) => void
 * @returns {WebSocket}
 */
export function connectGameWS(gameId, onEvent) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws'
  const ws = new WebSocket(`${proto}://${location.host}/ws/game/${gameId}`)

  ws.onmessage = (e) => {
    try {
      const event = JSON.parse(e.data)
      onEvent(event)
    } catch (err) {
      console.error('WS parse error:', err)
    }
  }

  ws.onerror = (e) => console.error('WS error:', e)
  ws.onclose = () => console.log('WS closed')

  return ws
}