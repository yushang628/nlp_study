"""策略优化器 — 网格搜索、随机搜索、进化搜索"""

import random
import logging
from typing import List, Dict, Any, Optional, Callable

from strategy_params import StrategyParams
from batch_runner import BatchRunner
from analyzer import GameAnalyzer

logger = logging.getLogger(__name__)


class StrategyOptimizer:
    """优化 Agent 策略参数"""

    def __init__(self, runner: BatchRunner, analyzer: GameAnalyzer, games_per_eval: int = 50):
        self.runner = runner
        self.analyzer = analyzer
        self.games_per_eval = games_per_eval
        self.history: List[Dict[str, Any]] = []

    async def _evaluate(self, params: StrategyParams) -> float:
        """评估一组策略参数的好人胜率"""
        results = await self.runner.run_batch(
            n_games=self.games_per_eval,
            good_params=params,
        )
        stats = BatchRunner.compute_stats(results)
        return stats.get("good_win_rate", 0.5)

    async def grid_search(
        self,
        param_name: str,
        values: List[float],
        base_params: Optional[StrategyParams] = None,
    ) -> Dict[str, Any]:
        """网格搜索：对单个参数搜索最优值"""
        base = base_params or StrategyParams()
        best_value = None
        best_score = -1
        results = []

        for v in values:
            params = StrategyParams(**base.to_dict())
            setattr(params, param_name, v)
            score = await self._evaluate(params)
            results.append({"value": v, "score": score})
            logger.info(f"grid_search: {param_name}={v:.2f} → win_rate={score:.3f}")
            if score > best_score:
                best_score = score
                best_value = v

        self.history.append({
            "method": "grid_search",
            "param_name": param_name,
            "best_value": best_value,
            "best_score": best_score,
            "all_results": results,
        })

        return {
            "param_name": param_name,
            "best_value": best_value,
            "best_score": best_score,
            "results": results,
        }

    async def random_search(
        self,
        n_trials: int = 20,
    ) -> Dict[str, Any]:
        """随机搜索：随机采样策略参数空间"""
        best_params = None
        best_score = -1
        results = []

        for i in range(n_trials):
            params = StrategyParams.random_params()
            score = await self._evaluate(params)
            results.append({"params": params.to_dict(), "score": score})
            logger.info(f"random_search trial {i+1}/{n_trials}: win_rate={score:.3f}")
            if score > best_score:
                best_score = score
                best_params = params

        self.history.append({
            "method": "random_search",
            "best_score": best_score,
            "best_params": best_params.to_dict() if best_params else None,
        })

        return {
            "best_params": best_params.to_dict() if best_params else None,
            "best_score": best_score,
            "n_trials": n_trials,
        }

    async def evolutionary_search(
        self,
        population_size: int = 12,
        generations: int = 10,
        elite_ratio: float = 0.3,
        mutation_rate: float = 0.3,
        mutation_range: float = 0.2,
    ) -> Dict[str, Any]:
        """进化搜索：模拟自然选择优化策略参数（推荐方法）

        1. 初始化随机种群
        2. 评估每个个体的胜率
        3. 选择精英
        4. 交叉 + 变异产生下一代
        5. 重复
        """
        # 1. 初始化种群
        population = [StrategyParams.random_params() for _ in range(population_size)]
        best_ever = None
        best_ever_score = -1
        generation_scores = []

        for gen in range(generations):
            # 2. 评估
            scored = []
            for i, ind in enumerate(population):
                score = await self._evaluate(ind)
                scored.append((ind, score))
                if score > best_ever_score:
                    best_ever_score = score
                    best_ever = ind

            scored.sort(key=lambda x: x[1], reverse=True)
            gen_best = scored[0][1]
            gen_avg = sum(s for _, s in scored) / len(scored)
            generation_scores.append({"gen": gen, "best": gen_best, "avg": gen_avg})
            logger.info(
                f"evolutionary gen {gen+1}/{generations}: "
                f"best={gen_best:.3f} avg={gen_avg:.3f} ever={best_ever_score:.3f}"
            )

            # 3. 选择精英
            n_elite = max(2, int(population_size * elite_ratio))
            elites = [ind for ind, _ in scored[:n_elite]]

            # 4. 交叉 + 变异产生下一代
            new_population = list(elites)
            while len(new_population) < population_size:
                # 锦标赛选择
                parent1 = self._tournament_select(scored)
                parent2 = self._tournament_select(scored)
                child = parent1.crossover(parent2)
                child = child.mutate(mutation_rate=mutation_rate, mutation_range=mutation_range)
                new_population.append(child)

            population = new_population

        self.history.append({
            "method": "evolutionary_search",
            "best_score": best_ever_score,
            "best_params": best_ever.to_dict() if best_ever else None,
            "generation_scores": generation_scores,
        })

        return {
            "best_params": best_ever.to_dict() if best_ever else None,
            "best_score": best_ever_score,
            "generation_scores": generation_scores,
        }

    @staticmethod
    def _tournament_select(scored: List[tuple], k: int = 3) -> StrategyParams:
        """锦标赛选择"""
        candidates = random.sample(scored, min(k, len(scored)))
        winner = max(candidates, key=lambda x: x[1])
        return winner[0]

    async def reinforce_optimize(
        self,
        initial_params: Optional[StrategyParams] = None,
        learning_rate: float = 0.1,
        n_iterations: int = 20,
    ) -> Dict[str, Any]:
        """强化学习式优化：基于胜率反馈逐步调整参数"""
        params = initial_params or StrategyParams()
        best_score = await self._evaluate(params)
        best_params = StrategyParams(**params.to_dict())
        iteration_scores = []

        for i in range(n_iterations):
            # 尝试小幅调整
            candidate = params.mutate(mutation_rate=0.5, mutation_range=learning_rate)
            score = await self._evaluate(candidate)
            iteration_scores.append({"iter": i, "score": score})

            if score >= best_score:
                params = candidate
                best_score = score
                best_params = StrategyParams(**candidate.to_dict())
                logger.info(f"reinforce iter {i+1}: improved → {score:.3f}")
            else:
                logger.info(f"reinforce iter {i+1}: no improvement ({score:.3f})")

        self.history.append({
            "method": "reinforce",
            "best_score": best_score,
            "best_params": best_params.to_dict(),
            "iteration_scores": iteration_scores,
        })

        return {
            "best_params": best_params.to_dict(),
            "best_score": best_score,
            "iteration_scores": iteration_scores,
        }