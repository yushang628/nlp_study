"""AI 狼人杀自进化训练 CLI 入口

用法:
    python main.py --iterations 10 --games 100 --method evolutionary
    python main.py --iterations 3 --games 10 --method reinforce
    python main.py --use-llm --iterations 5 --games 50
"""

import asyncio
import logging
import sys
import os

# 将项目根目录加入 path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from trainer import SelfImprovementTrainer


async def run():
    import argparse
    parser = argparse.ArgumentParser(description="AI 狼人杀 自进化训练")
    parser.add_argument("--iterations", type=int, default=10, help="训练迭代次数 (default: 10)")
    parser.add_argument("--games", type=int, default=100, help="每次迭代的对局数 (default: 100)")
    parser.add_argument("--method", type=str, default="evolutionary",
                        choices=["evolutionary", "random", "reinforce", "grid"],
                        help="优化方法 (default: evolutionary)")
    parser.add_argument("--use-llm", action="store_true", help="使用 LLM 运行对局（默认纯启发式）")
    parser.add_argument("--output-dir", type=str, default="./data/self_improvement",
                        help="输出目录")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    print(f"=== AI 狼人杀自进化训练 ===")
    print(f"方法: {args.method}")
    print(f"迭代: {args.iterations}")
    print(f"每轮对局: {args.games}")
    print(f"LLM模式: {'是' if args.use_llm else '否（纯启发式）'}")
    print()

    trainer = SelfImprovementTrainer(
        use_llm=args.use_llm,
        games_per_iteration=args.games,
        method=args.method,
        output_dir=args.output_dir,
    )

    result = await trainer.train(iterations=args.iterations)

    # 输出最终结果
    final = result["convergence_data"][-1]
    print(f"\n训练完成！")
    print(f"最终最佳胜率: {final['best_score']:.3f}")

    # 输出收敛趋势
    scores = [d["best_score"] for d in result["convergence_data"]]
    if len(scores) >= 2:
        trend = "↑" if scores[-1] > scores[0] else "↓" if scores[-1] < scores[0] else "→"
        print(f"收敛趋势: {scores[0]:.3f} {trend} {scores[-1]:.3f}")


if __name__ == "__main__":
    asyncio.run(run())