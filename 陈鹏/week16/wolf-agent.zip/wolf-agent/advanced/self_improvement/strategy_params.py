"""策略参数 — Agent 可调策略的可参数化表示"""

import random
import copy
from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class StrategyParams:
    """每个 Agent 维护一组可调参数，用于自进化训练"""

    # 怀疑阈值：低于此值的玩家不被怀疑为狼人 (0.0 ~ 1.0)
    suspicion_threshold: float = 0.5

    # 从众倾向：投票时跟随多数人的概率 (0.0 ~ 1.0)
    herd_tendency: float = 0.3

    # 狼人侵略性：狼人主动击杀神职的倾向 (0.0 ~ 1.0)
    wolf_aggression: float = 0.6

    # 神职声明倾向：好人跳神职的概率 (0.0 ~ 1.0)
    god_claim_tendency: float = 0.4

    # 发言详细度：发言内容的信息量 (0.0 ~ 1.0)
    speech_detail_level: float = 0.7

    # 记忆权重：历史经验对当前决策的影响 (0.0 ~ 1.0)
    memory_weight: float = 0.3

    def mutate(self, mutation_rate: float = 0.1, mutation_range: float = 0.2) -> "StrategyParams":
        """对参数进行随机变异，返回新的 StrategyParams"""
        new_params = copy.deepcopy(self)
        for attr in [
            "suspicion_threshold", "herd_tendency", "wolf_aggression",
            "god_claim_tendency", "speech_detail_level", "memory_weight",
        ]:
            if random.random() < mutation_rate:
                current = getattr(new_params, attr)
                delta = random.uniform(-mutation_range, mutation_range)
                new_val = max(0.0, min(1.0, current + delta))
                setattr(new_params, attr, new_val)
        return new_params

    def crossover(self, other: "StrategyParams") -> "StrategyParams":
        """与另一个 StrategyParams 交叉，返回混合后代"""
        child = StrategyParams()
        for attr in [
            "suspicion_threshold", "herd_tendency", "wolf_aggression",
            "god_claim_tendency", "speech_detail_level", "memory_weight",
        ]:
            if random.random() < 0.5:
                setattr(child, attr, getattr(self, attr))
            else:
                setattr(child, attr, getattr(other, attr))
        return child

    def to_dict(self) -> Dict[str, Any]:
        return {
            "suspicion_threshold": self.suspicion_threshold,
            "herd_tendency": self.herd_tendency,
            "wolf_aggression": self.wolf_aggression,
            "god_claim_tendency": self.god_claim_tendency,
            "speech_detail_level": self.speech_detail_level,
            "memory_weight": self.memory_weight,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "StrategyParams":
        return cls(**{
            k: v for k, v in d.items()
            if k in cls.__dataclass_fields__
        })

    @classmethod
    def random_params(cls) -> "StrategyParams":
        """生成随机策略参数"""
        return cls(
            suspicion_threshold=random.uniform(0.2, 0.8),
            herd_tendency=random.uniform(0.1, 0.6),
            wolf_aggression=random.uniform(0.3, 0.9),
            god_claim_tendency=random.uniform(0.2, 0.7),
            speech_detail_level=random.uniform(0.4, 0.9),
            memory_weight=random.uniform(0.1, 0.5),
        )