"""对局分析器 — 分析单局胜负、评分关键决策"""

import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


class GameAnalyzer:
    """分析游戏结果，评估关键决策质量"""

    def analyze_game(self, game_result: Dict[str, Any]) -> Dict[str, Any]:
        """分析单局游戏结果"""
        winner = game_result.get("winner", "unknown")
        rounds = game_result.get("rounds", 0)
        game_id = game_result.get("game_id", "")

        # 基本评分
        score = self._compute_game_score(winner, rounds)

        return {
            "game_id": game_id,
            "winner": winner,
            "rounds": rounds,
            "score": score,
            "analysis": {
                "winner_side": winner,
                "game_length": "short" if rounds <= 3 else "medium" if rounds <= 6 else "long",
            },
        }

    def _compute_game_score(self, winner: str, rounds: int) -> float:
        """根据胜负和回合数计算得分（0~1）"""
        base = 1.0 if winner == "good" else 0.3
        # 回合数越少（好人快速胜利），得分越高
        length_bonus = max(0, (8 - rounds) * 0.05) if winner == "good" else 0
        return min(1.0, base + length_bonus)

    def score_decision(
        self,
        role: str,
        action_type: str,
        action_detail: Dict[str, Any],
        game_result: Dict[str, Any],
    ) -> float:
        """评分单个决策（0~1）

        Args:
            role: 决策者角色
            action_type: 决策类型 (kill/check/vote/heal/poison)
            action_detail: 决策详情
            game_result: 最终游戏结果
        """
        winner = game_result.get("winner", "unknown")
        is_good_role = role in ("seer", "witch", "hunter", "villager")

        # 如果本方获胜，决策基础分更高
        if (is_good_role and winner == "good") or (not is_good_role and winner == "evil"):
            base_score = 0.7
        else:
            base_score = 0.3

        # 根据决策类型调整
        type_bonus = {
            "kill": 0.1,  # 狼人击杀
            "check": 0.05,  # 预言家查验
            "vote": 0.08,  # 投票
            "heal": 0.05,  # 女巫救人
            "poison": 0.1,  # 女巫毒人
        }
        return min(1.0, base_score + type_bonus.get(action_type, 0))

    def batch_analyze(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """批量分析多局游戏"""
        analyses = [self.analyze_game(r) for r in results]
        scores = [a["score"] for a in analyses]

        good_wins = sum(1 for a in analyses if a["winner"] == "good")
        total = len(analyses)

        # 决策评分统计
        decision_scores = []
        for result in results:
            actions = result.get("actions", [])
            for action in actions:
                ds = self.score_decision(
                    role=action.get("role", ""),
                    action_type=action.get("type", ""),
                    action_detail=action,
                    game_result=result,
                )
                decision_scores.append(ds)

        avg_decision_score = sum(decision_scores) / len(decision_scores) if decision_scores else 0

        return {
            "total_games": total,
            "good_win_rate": good_wins / total if total > 0 else 0,
            "avg_score": sum(scores) / len(scores) if scores else 0,
            "avg_decision_score": round(avg_decision_score, 3),
            "score_distribution": {
                "high": sum(1 for s in scores if s >= 0.7),
                "medium": sum(1 for s in scores if 0.4 <= s < 0.7),
                "low": sum(1 for s in scores if s < 0.4),
            },
        }