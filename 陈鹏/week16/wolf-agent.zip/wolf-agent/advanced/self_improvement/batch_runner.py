"""批量对局运行器 — 支持快速启发式模式和 LLM 模式"""

import asyncio
import random
import time
import logging
from typing import List, Dict, Any, Optional

from strategy_params import StrategyParams

logger = logging.getLogger(__name__)


class BatchRunner:
    """运行多局游戏，收集胜负统计"""

    def __init__(self, use_llm: bool = False, role_config: str = "standard_6"):
        self.use_llm = use_llm
        self.role_config = role_config

    async def run_single_game(
        self,
        good_params: Optional[StrategyParams] = None,
        evil_params: Optional[StrategyParams] = None,
    ) -> Dict[str, Any]:
        """运行单局游戏，返回结果"""
        if self.use_llm:
            return await self._run_with_llm(good_params, evil_params)
        else:
            return self._run_heuristic(good_params, evil_params)

    async def _run_with_llm(
        self,
        good_params: Optional[StrategyParams],
        evil_params: Optional[StrategyParams],
    ) -> Dict[str, Any]:
        """使用 LLM 运行一局完整游戏"""
        import os
        import sys
        # 确保 wolf-agent 项目根目录在 sys.path 中
        project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if project_root not in sys.path:
            sys.path.insert(0, project_root)
        from backend.engine.game_engine import GameEngine

        engine = GameEngine(
            role_config=self.role_config,
            strategy_params=good_params,
        )
        winner = await engine.run()
        return {
            "winner": winner.value,
            "game_id": engine.game.game_id,
            "rounds": engine.game.round_num,
            "events": len(engine.game.events),
        }

    def _run_heuristic(
        self,
        good_params: Optional[StrategyParams],
        evil_params: Optional[StrategyParams],
    ) -> Dict[str, Any]:
        """纯启发式快速模拟一局游戏（不调用 LLM）"""
        good_params = good_params or StrategyParams()
        evil_params = evil_params or StrategyParams()

        # 简化模拟：根据参数计算胜率倾向
        # 好人优势：高怀疑阈值 + 低从众 + 适度的神职声明
        good_strength = (
            good_params.suspicion_threshold * 0.3 +
            (1 - good_params.herd_tendency) * 0.3 +
            good_params.god_claim_tendency * 0.2 +
            good_params.speech_detail_level * 0.2
        )
        # 狼人优势：高侵略性 + 低神职声明（好人不跳身份）+ 高记忆权重
        evil_strength = (
            evil_params.wolf_aggression * 0.4 +
            (1 - good_params.god_claim_tendency) * 0.3 +
            evil_params.memory_weight * 0.3
        )

        # 加入随机性
        good_roll = random.random() * 0.3 + good_strength * 0.7
        evil_roll = random.random() * 0.3 + evil_strength * 0.7

        winner = "good" if good_roll > evil_roll else "evil"
        rounds = random.randint(2, 8)

        return {
            "winner": winner,
            "game_id": f"heuristic_{int(time.time()*1000)}",
            "rounds": rounds,
            "good_strength": round(good_strength, 3),
            "evil_strength": round(evil_strength, 3),
        }

    async def run_batch(
        self,
        n_games: int = 100,
        good_params: Optional[StrategyParams] = None,
        evil_params: Optional[StrategyParams] = None,
    ) -> List[Dict[str, Any]]:
        """运行多局游戏"""
        results = []
        for i in range(n_games):
            result = await self.run_single_game(good_params, evil_params)
            results.append(result)
            if (i + 1) % 20 == 0:
                logger.info(f"已完成 {i+1}/{n_games} 局")
        return results

    @staticmethod
    def compute_stats(results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """计算统计信息"""
        if not results:
            return {}
        good_wins = sum(1 for r in results if r["winner"] == "good")
        evil_wins = sum(1 for r in results if r["winner"] == "evil")
        total = len(results)
        avg_rounds = sum(r.get("rounds", 0) for r in results) / total
        return {
            "total_games": total,
            "good_wins": good_wins,
            "evil_wins": evil_wins,
            "good_win_rate": good_wins / total,
            "evil_win_rate": evil_wins / total,
            "avg_rounds": round(avg_rounds, 2),
        }