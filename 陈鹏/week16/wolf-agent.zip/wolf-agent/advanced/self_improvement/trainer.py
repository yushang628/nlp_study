"""自进化训练器 — 主训练循环 + 收敛曲线绘制"""

import asyncio
import json
import logging
import os
from typing import List, Dict, Any, Optional

from strategy_params import StrategyParams
from batch_runner import BatchRunner
from analyzer import GameAnalyzer
from optimizer import StrategyOptimizer

logger = logging.getLogger(__name__)


class SelfImprovementTrainer:
    """主训练循环：对局 → 分析 → 优化 → 再对局"""

    def __init__(
        self,
        use_llm: bool = False,
        games_per_iteration: int = 100,
        method: str = "evolutionary",
        output_dir: str = "./data/self_improvement",
    ):
        self.use_llm = use_llm
        self.games_per_iteration = games_per_iteration
        self.method = method
        self.output_dir = output_dir

        self.runner = BatchRunner(use_llm=use_llm)
        self.analyzer = GameAnalyzer()
        self.optimizer = StrategyOptimizer(
            self.runner, self.analyzer, games_per_eval=games_per_iteration
        )
        self.convergence_data: List[Dict[str, Any]] = []

    async def train(
        self,
        iterations: int = 10,
        population_size: int = 12,
        generations: int = 5,
    ) -> Dict[str, Any]:
        """运行完整训练循环"""
        logger.info(f"开始自进化训练: method={self.method}, iterations={iterations}")

        for i in range(iterations):
            logger.info(f"=== 训练迭代 {i+1}/{iterations} ===")

            if self.method == "evolutionary":
                result = await self.optimizer.evolutionary_search(
                    population_size=population_size,
                    generations=generations,
                )
                self.convergence_data.append({
                    "iteration": i,
                    "best_score": result["best_score"],
                    "generation_scores": result["generation_scores"],
                })
            elif self.method == "random":
                result = await self.optimizer.random_search(n_trials=20)
                self.convergence_data.append({
                    "iteration": i,
                    "best_score": result["best_score"],
                })
            elif self.method == "reinforce":
                result = await self.optimizer.reinforce_optimize(n_iterations=20)
                self.convergence_data.append({
                    "iteration": i,
                    "best_score": result["best_score"],
                    "iteration_scores": result.get("iteration_scores", []),
                })
            else:
                # grid search 作为一个参数的简单搜索
                result = await self.optimizer.grid_search(
                    "suspicion_threshold",
                    [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8],
                )
                self.convergence_data.append({
                    "iteration": i,
                    "best_score": result["best_score"],
                })

            logger.info(f"迭代 {i+1} 最佳胜率: {result.get('best_score', 0):.3f}")

        # 保存收敛数据
        self._save_results()

        # 绘制收敛曲线
        self.plot_convergence()

        return {
            "convergence_data": self.convergence_data,
            "optimizer_history": self.optimizer.history,
        }

    def _save_results(self):
        """保存训练结果到 JSON"""
        os.makedirs(self.output_dir, exist_ok=True)
        filepath = os.path.join(self.output_dir, "training_results.json")
        data = {
            "method": self.method,
            "use_llm": self.use_llm,
            "games_per_iteration": self.games_per_iteration,
            "convergence_data": self.convergence_data,
            "optimizer_history": self.optimizer.history,
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info(f"训练结果已保存: {filepath}")

    def plot_convergence(self, filepath: Optional[str] = None):
        """绘制胜率收敛曲线"""
        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except ImportError:
            logger.warning("matplotlib 未安装，无法绘制收敛曲线")
            return

        if not self.convergence_data:
            logger.warning("没有收敛数据")
            return

        os.makedirs(self.output_dir, exist_ok=True)
        if filepath is None:
            filepath = os.path.join(self.output_dir, "convergence_curve.png")

        # 提取数据
        iterations = [d["iteration"] for d in self.convergence_data]
        best_scores = [d["best_score"] for d in self.convergence_data]

        fig, ax = plt.subplots(figsize=(10, 6))
        ax.plot(iterations, best_scores, "b-o", linewidth=2, label="Best Win Rate")
        ax.set_xlabel("Training Iteration")
        ax.set_ylabel("Good Camp Win Rate")
        ax.set_title(f"Self-Improvement Convergence ({self.method})")
        ax.legend()
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 1)

        plt.tight_layout()
        plt.savefig(filepath, dpi=150)
        plt.close()
        logger.info(f"收敛曲线已保存: {filepath}")


async def main():
    """CLI 入口函数"""
    import argparse
    parser = argparse.ArgumentParser(description="AI 狼人杀 自进化训练")
    parser.add_argument("--iterations", type=int, default=10, help="训练迭代次数")
    parser.add_argument("--games", type=int, default=100, help="每次迭代的对局数")
    parser.add_argument("--method", type=str, default="evolutionary",
                        choices=["evolutionary", "random", "reinforce", "grid"],
                        help="优化方法")
    parser.add_argument("--use-llm", action="store_true", help="使用 LLM 运行对局")
    parser.add_argument("--output-dir", type=str, default="./data/self_improvement",
                        help="输出目录")

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    trainer = SelfImprovementTrainer(
        use_llm=args.use_llm,
        games_per_iteration=args.games,
        method=args.method,
        output_dir=args.output_dir,
    )

    result = await trainer.train(iterations=args.iterations)
    print(f"\n训练完成！最终胜率: {result['convergence_data'][-1]['best_score']:.3f}")


if __name__ == "__main__":
    asyncio.run(main())