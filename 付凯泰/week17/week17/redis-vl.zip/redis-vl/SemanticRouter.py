import json
import uuid
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

import redis

from base.redis_client import RedisClient
from base.vectorizer import BaseVectorizer, HFTextVectorizer
from base.utils import make_key, vector_to_bytes


@dataclass
class Route:
    name: str
    references: List[str]
    metadata: Dict[str, Any] = field(default_factory=dict)
    distance_threshold: float = 0.3


@dataclass
class RouteMatch:
    name: str
    distance: float
    metadata: Dict[str, Any] = field(default_factory=dict)


class SemanticRouter:
    def __init__(
        self,
        name: str,
        routes: Optional[List[Route]] = None,
        vectorizer: Optional[BaseVectorizer] = None,
        redis_url: str = "redis://localhost:6379",
        top_k: int = 10,
        **redis_kwargs,
    ):
        self.name = name
        self.top_k = top_k
        self.vectorizer = vectorizer or HFTextVectorizer()
        self.redis = RedisClient(redis_url, **redis_kwargs)
        self._prefix = make_key("sem_router", name)
        self._index_name = make_key("sem_router", name, "idx")
        self._create_index()
        if routes:
            for route in routes:
                self.add_route(route)

    def _create_index(self):
        if self.redis.index_exists(self._index_name):
            return
        try:
            self.redis.create_vector_index(
                index_name=self._index_name,
                prefix=f"{self._prefix}:",
                vector_field="ref_vector",
                dims=self.vectorizer.dimensions,
                extra_fields=[
                    "route_name TEXT",
                    "reference TEXT",
                    "distance_threshold NUMERIC",
                    "metadata TEXT",
                ],
            )
        except redis.ResponseError:
            pass  # race: another instance already created it

    def add_route(self, route: Route):
        for i, ref in enumerate(route.references):
            key = make_key(self._prefix, route.name, str(i))
            embedding = self.vectorizer.embed(ref)
            self.redis.hset(key, {
                "route_name": route.name,
                "reference": ref,
                "ref_vector": vector_to_bytes(embedding),
                "distance_threshold": str(route.distance_threshold),
                "metadata": json.dumps(route.metadata),
            })

    def __call__(self, query: str) -> Optional[RouteMatch]:
        if not self.redis.index_exists(self._index_name):
            return None
        query_vec = self.vectorizer.embed(query)
        query_bytes = vector_to_bytes(query_vec)
        try:
            results = self.redis.execute(
                "FT.SEARCH", self._index_name,
                f"*=>[KNN {self.top_k} @ref_vector $vec AS score]",
                "PARAMS", "2", "vec", query_bytes,
                "RETURN", "4", "score", "route_name", "distance_threshold", "metadata",
                "SORTBY", "score", "ASC",
                "DIALECT", "2",
            )
        except Exception:
            return None
        return self._best_route(results)

    def _best_route(self, results) -> Optional[RouteMatch]:
        if not results or results[0] == 0:
            return None
        best: Optional[RouteMatch] = None
        for i in range(1, len(results), 2):
            fields = results[i + 1]
            record = {}
            for j in range(0, len(fields), 2):
                k = fields[j].decode() if isinstance(fields[j], bytes) else fields[j]
                v = fields[j + 1]
                if isinstance(v, bytes):
                    v = v.decode()
                record[k] = v
            score = float(record.get("score", 1.0))
            threshold = float(record.get("distance_threshold", 0.3))
            if score <= threshold:
                if best is None or score < best.distance:
                    best = RouteMatch(
                        name=record.get("route_name", ""),
                        distance=score,
                        metadata=json.loads(record.get("metadata", "{}")),
                    )
        return best

    def list_routes(self) -> List[Route]:
        if not self.redis.index_exists(self._index_name):
            return []
        try:
            results = self.redis.execute(
                "FT.SEARCH", self._index_name, "*",
                "RETURN", "3", "route_name", "reference", "distance_threshold",
                "LIMIT", "0", "10000",
                "DIALECT", "2",
            )
        except Exception:
            return []
        route_map: Dict[str, Route] = {}
        if not results or results[0] == 0:
            return []
        for i in range(1, len(results), 2):
            fields = results[i + 1]
            record = {}
            for j in range(0, len(fields), 2):
                k = fields[j].decode() if isinstance(fields[j], bytes) else fields[j]
                v = fields[j + 1]
                if isinstance(v, bytes):
                    v = v.decode()
                record[k] = v
            name = record.get("route_name", "")
            ref = record.get("reference", "")
            threshold = float(record.get("distance_threshold", 0.3))
            if name not in route_map:
                route_map[name] = Route(name=name, references=[], distance_threshold=threshold)
            route_map[name].references.append(ref)
        return list(route_map.values())

    def delete_route(self, route_name: str):
        for key in self.redis.scan_iter(match=f"{self._prefix}:{route_name}:*"):
            self.redis.delete(key)

    def clear(self):
        self.redis.drop_index(self._index_name)
        for key in self.redis.scan_iter(match=f"{self._prefix}:*"):
            self.redis.delete(key)

    def __len__(self) -> int:
        try:
            result = self.redis.execute("FT.SEARCH", self._index_name, "*", "LIMIT", "0", "0")
            return result[0]
        except Exception:
            return 0
