"""
端到端集成测试 — 使用内存模拟 Redis 后端 (MockRedisClient)。
覆盖所有四个组件：EmbeddingsCache, SemanticCache, SemanticMessageHistory, SemanticRouter。
"""
import math
import sys
import os
import re
import struct
import json
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# =============================================================================
# Mock Redis Client — in-memory implementation of RediSearch + Hash
# =============================================================================

def _cosine_sim(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb + 1e-10)


def _cosine_dist(a: List[float], b: List[float]) -> float:
    return 1.0 - _cosine_sim(a, b)


def _d(v):
    return v.decode() if isinstance(v, bytes) else v


def _e(v):
    return v.encode() if isinstance(v, str) else v


def _vb(v):
    if isinstance(v, bytes):
        return v
    if isinstance(v, float):
        return str(v).encode()
    return str(v).encode()


def _b2v(blob: bytes) -> List[float]:
    return list(struct.unpack(f"{len(blob) // 4}f", blob))


def _parse_tag_filter(query: str) -> Optional[Tuple[str, str]]:
    """Parse @role:{value} → ('role', 'value')"""
    m = re.search(r'@(\w+):\{(\w+)\}', query)
    if m:
        return (m.group(1), m.group(2))
    return None


def _apply_tag_filter(records: List[Tuple[str, float]], tag_field: str, tag_value: str,
                      hashes: dict) -> List[Tuple[str, float]]:
    return [(k, s) for k, s in records
            if hashes.get(k, {}).get(_e(tag_field), b"").decode(errors='replace') == tag_value]


class MockRedisClient:
    """Simulates Redis + RediSearch using in-memory dicts."""

    def __init__(self, redis_url="redis://localhost:6379", **kwargs):
        self._hashes: Dict[str, Dict[bytes, bytes]] = {}
        self._indexes: Dict[str, dict] = {}

    def module_list(self):
        return [{"name": b"search"}]

    def execute_command(self, command, *args):
        cmd = command.upper() if isinstance(command, str) else command
        handlers = {
            "FT.CREATE": self._ft_create,
            "FT.INFO": self._ft_info,
            "FT._LIST": self._ft_list,
            "FT.SEARCH": self._ft_search,
            "FT.DROPINDEX": self._ft_drop,
            "HSET": self._hset,
            "HGETALL": self._hgetall,
            "HDEL": self._hdel,
            "DEL": self._del,
            "EXPIRE": self._expire,
            "EXISTS": self._exists,
            "SCAN": self._scan,
        }
        handler = handlers.get(cmd)
        if handler:
            return handler(*args)
        raise ValueError(f"Unknown command: {cmd} {args}")

    def execute(self, command, *args):
        return self.execute_command(command, *args)

    # ---- Hash ops ----
    def _hset(self, name, mapping=None):
        n = _d(name)
        if n not in self._hashes:
            self._hashes[n] = {}
        if mapping:
            for k, v in mapping.items():
                self._hashes[n][_e(k if isinstance(k, str) else k)] = _vb(v)
        return 1

    def _hgetall(self, name):
        return self._hashes.get(_d(name), {}).copy()

    def _hdel(self, name, *keys):
        h = self._hashes.get(_d(name))
        if not h:
            return 0
        count = 0
        for k in keys:
            k = _e(k) if isinstance(k, str) else k
            if k in h:
                del h[k]
                count += 1
        return count

    def _del(self, *names):
        count = 0
        for name in names:
            n = _d(name)
            if n in self._hashes:
                del self._hashes[n]
                count += 1
        return count

    def _expire(self, name, ttl):
        return True

    def _exists(self, name):
        return 1 if _d(name) in self._hashes else 0

    def _scan(self, cursor=0, match=None, count=10):
        all_keys = list(self._hashes.keys())
        pattern = (match or "").replace("*", "")
        matched = [k for k in all_keys if pattern in k]
        return [0, matched]

    def scan_iter(self, match=None, count=1000):
        _, keys = self._scan(match=match, count=count)
        return keys

    # ---- Index ops ----
    def _ft_create(self, *args):
        idx_name = _d(args[0])
        self._indexes[idx_name] = {"prefix": "", "fields": {}, "tag_fields": set()}
        for i, a in enumerate(args):
            s = _d(a).upper() if isinstance(a, (str, bytes)) else ""
            if s == "PREFIX" and i + 2 < len(args):
                self._indexes[idx_name]["prefix"] = _d(args[i + 2])
            if s == "VECTOR" and i > 0:
                fname = _d(args[i - 1])
                self._indexes[idx_name]["fields"][fname] = {"type": "vector"}
            if s == "TAG" and i > 0:
                fname = _d(args[i - 1])
                self._indexes[idx_name]["tag_fields"].add(fname)
        return "OK"

    def _ft_info(self, idx_name):
        idx = self._indexes.get(_d(idx_name))
        if not idx:
            from redis import ResponseError
            raise ResponseError("Unknown Index name")
        prefix = idx.get("prefix", "")
        count = len([k for k in self._hashes if k.startswith(prefix)])
        return ["num_docs", count]

    def _ft_list(self):
        return [_e(n) for n in self._indexes]

    def _ft_drop(self, idx_name):
        self._indexes.pop(_d(idx_name), None)
        return "OK"

    def _ft_search(self, *args):
        idx_name = _d(args[0])
        raw_query = _d(args[1])
        idx = self._indexes.get(idx_name)
        if not idx:
            from redis import ResponseError
            raise ResponseError(f"Index {idx_name} not found")
        prefix = idx.get("prefix", "")
        parsed = self._parse_ft_args(args[2:])
        return_fields = parsed.get("return", [])
        limit_offset = int(parsed.get("limit_offset", 0))
        limit_count = int(parsed.get("limit_count", 10))
        sortby_field = parsed.get("sortby")
        sortby_dir = parsed.get("sortby_dir", "ASC")

        all_keys = [k for k in self._hashes if k.startswith(prefix)]

        # Parse TAG filter from raw_query e.g. @role:{user}
        tag_filter = _parse_tag_filter(raw_query)

        knn_params = self._parse_knn(raw_query)
        scored: List[Tuple[str, float]] = []
        if knn_params:
            vec_field = knn_params["field"]
            k = knn_params["k"]
            query_vec_blob = parsed.get("params", {}).get("vec", b"")
            query_vec = _b2v(query_vec_blob) if query_vec_blob else []
            for key in all_keys:
                h = self._hashes.get(key, {})
                vec_blob = h.get(_e(vec_field), b"")
                if vec_blob and query_vec:
                    vec = _b2v(vec_blob)
                    dist = _cosine_dist(query_vec, vec)
                    scored.append((key, dist))
            scored.sort(key=lambda x: x[1])
            # Apply TAG filter after KNN scoring
            if tag_filter:
                tag_f, tag_v = tag_filter
                scored = [(k, s) for k, s in scored
                          if self._hashes.get(k, {}).get(_e(tag_f), b"").decode(errors='replace') == tag_v]
            scored = scored[:k]
        else:
            scored = [(k, 0.0) for k in all_keys]
            # Apply TAG filter
            if tag_filter:
                tag_f, tag_v = tag_filter
                scored = [(k, s) for k, s in scored
                          if self._hashes.get(k, {}).get(_e(tag_f), b"").decode(errors='replace') == tag_v]
            if sortby_field and sortby_field != "score" and scored:
                def _sk(item):
                    val = self._hashes[item[0]].get(_e(sortby_field), b"0")
                    return float(val.decode(errors='replace'))
                scored.sort(key=_sk, reverse=(sortby_dir.upper() == "DESC"))

        # Apply LIMIT
        limit_end = limit_offset + limit_count
        scored = scored[limit_offset:limit_end]

        result = [len(scored)]
        for key, dist in scored:
            h = self._hashes.get(key, {})
            fields_list = []
            if knn_params:
                score_alias = knn_params.get("as", "score")
                fields_list.append(_e(score_alias))
                fields_list.append(_e(f"{dist:.6f}"))
            for rf in return_fields:
                if knn_params and rf == knn_params.get("as", "score"):
                    continue
                val = h.get(_e(rf))
                if val is not None:
                    fields_list.append(_e(rf))
                    fields_list.append(val)
            result.append(_e(key))
            result.append(fields_list)
        return result

    def _parse_ft_args(self, args):
        parsed: dict = {"return": [], "params": {}}
        i = 0
        while i < len(args):
            s = _d(args[i]).upper() if i < len(args) else ""
            if s == "RETURN":
                count = int(args[i + 1])
                parsed["return"] = [_d(args[i + 2 + j]) for j in range(count)]
                i += 2 + count
            elif s == "SORTBY":
                parsed["sortby"] = _d(args[i + 1])
                if i + 2 < len(args) and _d(args[i + 2]).upper() in ("ASC", "DESC"):
                    parsed["sortby_dir"] = _d(args[i + 2]).upper()
                    i += 3
                else:
                    i += 2
            elif s == "LIMIT":
                parsed["limit_offset"] = int(args[i + 1])
                parsed["limit_count"] = int(args[i + 2])
                i += 3
            elif s == "PARAMS":
                count = int(args[i + 1])
                for j in range(count // 2):
                    k = _d(args[i + 2 + j * 2])
                    parsed["params"][k] = args[i + 2 + j * 2 + 1]
                i += 2 + count
            elif s == "DIALECT":
                i += 2
            else:
                i += 1
        return parsed

    def _parse_knn(self, query):
        if "KNN" not in query:
            return None
        m = re.search(r"KNN\s+(\d+)\s+@(\w+)", query)
        if not m:
            return None
        result = {"k": int(m.group(1)), "field": m.group(2)}
        as_m = re.search(r"AS\s+(\w+)", query)
        if as_m:
            result["as"] = as_m.group(1)
        return result

    # ---- Public API matching RedisClient ----
    def hset(self, name, mapping=None):
        return self._hset(name, mapping=mapping)

    def hgetall(self, name):
        return self._hgetall(name)

    def hdel(self, name, *keys):
        return self._hdel(name, *keys)

    def delete(self, *names):
        return self._del(*names)

    def expire(self, name, ttl):
        return self._expire(name, ttl)

    def exists(self, name):
        return bool(self._exists(name))

    def index_exists(self, idx):
        return idx in self._indexes

    def create_vector_index(self, index_name, prefix, vector_field, dims,
                            algorithm="FLAT", distance_metric="COSINE", extra_fields=None):
        schema_parts = []
        if extra_fields:
            for fd in extra_fields:
                schema_parts.extend(fd.split())
        schema_parts.extend([
            vector_field, "VECTOR", algorithm, "6",
            "TYPE", "FLOAT32", "DIM", str(dims), "DISTANCE_METRIC", distance_metric,
        ])
        self._ft_create(
            index_name, "ON", "HASH", "PREFIX", "1", prefix,
            "SCHEMA", *schema_parts,
        )

    def drop_index(self, idx):
        return self._ft_drop(idx)

    def ft_list(self):
        return self._ft_list()

    def close(self):
        pass

    def _check_redisearch(self):
        pass


# =============================================================================
# Patch RedisClient BEFORE component imports
# =============================================================================
import base.redis_client
base.redis_client.RedisClient = MockRedisClient

from base.vectorizer import BaseVectorizer
from EmbeddingsCache import EmbeddingsCache
from SemanticCache import SemanticCache
from SemanticMessageHistory import SemanticMessageHistory, Message
from SemanticRouter import SemanticRouter, Route, RouteMatch


# =============================================================================
# Content-aware vectorizer for deterministic, semantically meaningful vectors
# =============================================================================

class ContentVectorizer(BaseVectorizer):
    """
    4-dim vectorizer using word categories:
      [geography, weather, greeting, farewell]
    producing deterministic cosine-distances that match semantic similarity.
    """
    _dims = 4

    def embed(self, text: str, **kwargs) -> List[float]:
        words = text.lower().split()
        geo = weather = greet = farewell = 0.0
        for w in words:
            if w in ("france", "paris", "capital", "germany", "berlin", "country", "cities", "french"):
                geo += 1.0
            if w in ("weather", "sunny", "rain", "raining", "temperature", "degrees", "forecast", "climate"):
                weather += 1.0
            if w in ("hello", "hi", "hey", "how", "are", "you", "good", "morning", "afternoon", "evening"):
                greet += 1.0
            if w in ("bye", "goodbye", "see", "farewell", "later", "cya"):
                farewell += 1.0
        features = [geo, weather, greet, farewell]
        norm = math.sqrt(sum(x * x for x in features)) or 1.0
        return [x / norm for x in features]

    @property
    def dimensions(self) -> int:
        return self._dims


# =============================================================================
# Test runner
# =============================================================================

@dataclass
class Tally:
    total: int = 0
    passed: int = 0

    def check(self, cond: bool, msg: str = ""):
        self.total += 1
        if cond:
            self.passed += 1
            print("  ✓")
        else:
            print(f"  ✗ {msg}")


tally = Tally()


def test_embeddings_cache():
    print("\n=== EmbeddingsCache ===")
    c = EmbeddingsCache(name="test_emb", redis_url="redis://mock", ttl=None)

    c.store("hello", [0.1, 0.2, 0.3, 0.4], {"source": "test"})
    r = c.check("hello")
    tally.check(r is not None, "check returned None")
    tally.check(r.text == "hello", f"text: {r.text}")
    tally.check(r.embedding == [0.1, 0.2, 0.3, 0.4], f"emb: {r.embedding}")
    tally.check(r.metadata.get("source") == "test", f"meta: {r.metadata}")

    tally.check(c.check("miss") is None, "miss should be None")

    c.store("hello", [0.9, 0.8, 0.7, 0.6])
    tally.check(c.check("hello").embedding == [0.9, 0.8, 0.7, 0.6],
                f"overwrite: {c.check('hello').embedding}")

    c.clear()
    tally.check(c.check("hello") is None, "not empty after clear")
    tally.check(len(c) == 0, f"len after clear: {len(c)}")


def test_semantic_cache():
    print("\n=== SemanticCache ===")
    vec = ContentVectorizer()
    c = SemanticCache(name="test_sc", vectorizer=vec, redis_url="redis://mock",
                      ttl=None, distance_threshold=0.3)

    c.store("What is the capital of France?", "Paris", llm_model="gpt-4")
    c.store("What is the capital of Germany?", "Berlin", llm_model="gpt-4")
    c.store("How is the weather today?", "Sunny and warm")
    c.store("Say goodbye my friend", "Goodbye!")
    print("  stored 4 entries")

    r = c.check("What is the capital of France?")
    tally.check(r == "Paris", f"exact match: {r}")

    r2 = c.check("What is the capital city of France?")
    tally.check(r2 == "Paris", f"semantic: {r2}")

    r3 = c.check("Weather forecast")
    tally.check(r3 == "Sunny and warm", f"weather match: {r3}")

    r4 = c.check("Quantum physics quantum mechanics")
    tally.check(r4 is None, f"no-match should be None, got: {r4}")

    c.clear()
    tally.check(c.check("What is the capital of France?") is None, "not empty after clear")
    tally.check(len(c) == 0, f"len after clear: {len(c)}")


def test_semantic_message_history():
    print("\n=== SemanticMessageHistory ===")
    vec = ContentVectorizer()
    h = SemanticMessageHistory(name="test_mh", vectorizer=vec, redis_url="redis://mock",
                               ttl=None, distance_threshold=0.3)

    h.add_message("user", "Hello, how are you?")
    h.add_message("assistant", "I'm doing great, thanks!")
    h.add_message("user", "What is the weather like today?")
    h.add_message("assistant", "It's sunny and 25 degrees.")
    h.add_message("user", "Tell me about Paris")
    h.add_message("assistant", "Paris is the capital of France.")
    print("  added 6 messages")

    recent = h.get_recent(top_k=2)
    tally.check(len(recent) == 2, f"recent: expected 2, got {len(recent)}")
    tally.check("Paris" in recent[0].content, f"recent[0]: {recent[0].content}")

    user_msgs = h.get_recent(top_k=10, role="user")
    tally.check(len(user_msgs) == 3, f"user msgs: expected 3, got {len(user_msgs)}")
    tally.check(all(m.role == "user" for m in user_msgs), "not all user role")

    # Recent assistant messages
    asst_msgs = h.get_recent(top_k=10, role="assistant")
    tally.check(len(asst_msgs) == 3, f"asst msgs: expected 3, got {len(asst_msgs)}")
    tally.check(all(m.role == "assistant" for m in asst_msgs), "not all assistant role")

    relevant = h.get_relevant("weather forecast", top_k=2)
    tally.check(len(relevant) >= 1, f"relevant: got {len(relevant)}")
    tally.check("weather" in relevant[0].content.lower() or "sunny" in relevant[0].content.lower(),
                f"irrelevant: {relevant[0].content}")

    # get_relevant with TAG filter
    relevant_user = h.get_relevant("weather", top_k=5, role="user")
    tally.check(len(relevant_user) >= 1, f"relevant_user empty, got {len(relevant_user)}")
    tally.check(all(m.role == "user" for m in relevant_user), "not all user in filtered")

    h.clear()
    tally.check(len(h) == 0, f"len after clear: {len(h)}")


def test_semantic_router():
    print("\n=== SemanticRouter ===")
    vec = ContentVectorizer()
    routes = [
        Route(name="greeting", references=["hello", "hi", "good morning"],
              metadata={"type": "greeting"}, distance_threshold=0.3),
        Route(name="weather", references=["weather report", "rain", "temperature"],
              metadata={"type": "weather"}, distance_threshold=0.3),
        Route(name="farewell", references=["bye", "goodbye", "see you later"],
              metadata={"type": "farewell"}, distance_threshold=0.3),
    ]
    router = SemanticRouter(name="test_router", routes=routes, vectorizer=vec, redis_url="redis://mock")
    print("  registered 3 routes")

    match = router("hey")
    tally.check(match is not None, "greeting match is None")
    if match:
        tally.check(match.name == "greeting", f"expected greeting, got {match.name}")
        tally.check(match.distance <= 0.3, f"distance too high: {match.distance}")
        tally.check(match.metadata.get("type") == "greeting", f"metadata: {match.metadata}")

    match2 = router("what's the temperature like?")
    tally.check(match2 is not None, "weather match is None")
    if match2:
        tally.check(match2.name == "weather", f"expected weather, got {match2.name}")

    match3 = router("see you")
    tally.check(match3 is not None, "farewell match is None")
    if match3:
        tally.check(match3.name == "farewell", f"expected farewell, got {match3.name}")

    match4 = router("quantum physics mechanics")
    tally.check(match4 is None, f"no-match should be None, got {match4}")

    route_list = router.list_routes()
    tally.check(len(route_list) == 3, f"expected 3 routes, got {len(route_list)}")
    names = {r.name for r in route_list}
    tally.check(names == {"greeting", "weather", "farewell"}, f"names: {names}")

    router.delete_route("farewell")
    route_list2 = router.list_routes()
    tally.check(len(route_list2) == 2, f"expected 2 routes, got {len(route_list2)}")
    tally.check("farewell" not in {r.name for r in route_list2}, "farewell still present")

    router.clear()
    tally.check(len(router) == 0, f"len after clear: {len(router)}")


# =============================================================================
# Main
# =============================================================================

if __name__ == "__main__":
    print("=" * 50)
    print("Redis-VL Integration Tests  (Mock Backend)")
    print("=" * 50)

    test_map = [
        ("EmbeddingsCache", test_embeddings_cache),
        ("SemanticCache", test_semantic_cache),
        ("SemanticMessageHistory", test_semantic_message_history),
        ("SemanticRouter", test_semantic_router),
    ]
    for name, fn in test_map:
        try:
            fn()
        except Exception as e:
            import traceback
            print(f"  !! {name} crashed: {e}")
            traceback.print_exc()

    print(f"\n{'='*50}")
    failed = tally.total - tally.passed
    print(f"Results: {tally.passed}/{tally.total} passed, {failed} failed")
    print(f"{'='*50}")
