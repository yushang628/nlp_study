import hashlib
import struct
import time
from typing import List


def md5_hash(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def timestamp() -> float:
    return time.time()


def vector_to_bytes(vector: List[float]) -> bytes:
    return struct.pack(f"{len(vector)}f", *vector)


def bytes_to_vector(blob: bytes) -> List[float]:
    return list(struct.unpack(f"{len(blob) // 4}f", blob))


def make_key(*parts: str) -> str:
    return ":".join(parts)
