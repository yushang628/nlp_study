import redis


class RedisModuleError(Exception):
    pass


class RedisClient:
    def __init__(self, redis_url: str = "redis://localhost:6379", **kwargs):
        self.client = redis.Redis.from_url(redis_url, decode_responses=False, **kwargs)
        self._check_redisearch()

    def _check_redisearch(self):
        try:
            modules = self.client.module_list()
        except redis.ConnectionError as e:
            raise RedisModuleError(f"Cannot connect to Redis: {e}") from e
        if not any(m.get(b"name") == b"search" for m in modules):
            raise RedisModuleError(
                "RediSearch module not loaded. Use redis-stack or "
                "redis-stack-server, or load the module manually."
            )

    def execute(self, command: str, *args):
        return self.client.execute_command(command, *args)

    def hset(self, name: str, mapping: dict):
        return self.client.hset(name, mapping=mapping)

    def hgetall(self, name: str) -> dict:
        return self.client.hgetall(name)

    def hdel(self, name: str, *keys):
        return self.client.hdel(name, *keys)

    def delete(self, *names):
        return self.client.delete(*names)

    def expire(self, name: str, ttl: int):
        return self.client.expire(name, ttl)

    def exists(self, name: str) -> bool:
        return self.client.exists(name) > 0

    def scan_iter(self, match: str = None, count: int = 1000):
        return self.client.scan_iter(match=match, count=count)

    def ft_info(self, index_name: str) -> dict:
        raw = self.client.execute_command("FT.INFO", index_name)
        info = {}
        for i in range(0, len(raw), 2):
            k = raw[i]
            if isinstance(k, bytes):
                k = k.decode()
            info[k] = raw[i + 1]
        return info

    def ft_list(self) -> list:
        raw = self.client.execute_command("FT._LIST")
        return [r.decode() for r in raw]

    def index_exists(self, index_name: str) -> bool:
        return index_name in self.ft_list()

    def create_vector_index(
        self,
        index_name: str,
        prefix: str,
        vector_field: str,
        dims: int,
        algorithm: str = "FLAT",
        distance_metric: str = "COSINE",
        extra_fields: list = None,
    ):
        schema_parts = []
        if extra_fields:
            for field_def in extra_fields:
                schema_parts.append(field_def)
        schema_parts.append(
            f"{vector_field} VECTOR {algorithm} 6 "
            f"TYPE FLOAT32 DIM {dims} DISTANCE_METRIC {distance_metric}"
        )
        schema = " ".join(schema_parts)
        self.client.execute_command(
            "FT.CREATE", index_name,
            "ON", "HASH",
            "PREFIX", "1", prefix,
            "SCHEMA", *schema.split(),
        )

    def drop_index(self, index_name: str):
        try:
            self.client.execute_command("FT.DROPINDEX", index_name)
        except redis.ResponseError:
            pass

    def close(self):
        self.client.close()
