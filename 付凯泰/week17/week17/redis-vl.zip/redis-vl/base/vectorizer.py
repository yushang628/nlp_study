from abc import ABC, abstractmethod


class BaseVectorizer(ABC):
    @abstractmethod
    def embed(self, text: str, **kwargs) -> list:
        pass

    @property
    @abstractmethod
    def dimensions(self) -> int:
        pass


class HFTextVectorizer(BaseVectorizer):
    def __init__(self, model: str = "sentence-transformers/all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self._model = SentenceTransformer(model)
        self._dims = self._model.get_sentence_embedding_dimension()

    def embed(self, text: str, **kwargs) -> list:
        return self._model.encode(text, **kwargs).tolist()

    @property
    def dimensions(self) -> int:
        return self._dims
