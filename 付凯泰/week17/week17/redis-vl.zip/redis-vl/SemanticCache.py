import json
import uuid
from typing import Any, Dict, List, Optional

import redis

from base.redis_client import RedisClient
from base.vectorizer import BaseVectorizer, HFTextVectorizer
from base.utils import make_key, vector_to_bytes, timestamp


class SemanticCache:
    def __init__(
        self,
        name: str,
        vectorizer: Optional[BaseVectorizer] = None,
        redis_url: str = "redis://localhost:6379",
        ttl: Optional[int] = None,
        distance_threshold: float = 0.1,
        top_k: int = 1,
        **redis_kwargs,
    ):
        self.name = name
        self.ttl = ttl
        self.distance_threshold = distance_threshold
        self.top_k = top_k
        self.vectorizer = vectorizer or HFTextVectorizer()
        self.redis = RedisClient(redis_url, **redis_kwargs)
        self._prefix = make_key("sem_cache", name)
        self._index_name = make_key("sem_cache", name, "idx")
        self._create_index()

    def _create_index(self):
        if self.redis.index_exists(self._index_name):
            return
        try:
            self.redis.create_vector_index(
                index_name=self._index_name,
                prefix=f"{self._prefix}:",
                vector_field="prompt_vector",
                dims=self.vectorizer.dimensions,
                extra_fields=[
                    "prompt TEXT",
                    "response TEXT",
                    "llm_model TEXT",
                    "timestamp NUMERIC",
                    "metadata TEXT",
                ],
            )
        except redis.ResponseError:
            pass  # race: another instance already created it

    def store(
        self,
        prompt: str,
        response: str,
        metadata: Optional[Dict[str, Any]] = None,
        llm_model: str = "",
    ):
        key = make_key(self._prefix, uuid.uuid4().hex)
        embedding = self.vectorizer.embed(prompt)
        self.redis.hset(key, {
            "prompt": prompt,
            "response": response,
            "prompt_vector": vector_to_bytes(embedding),
            "llm_model": llm_model,
            "timestamp": str(timestamp()),
            "metadata": json.dumps(metadata or {}),
        })
        if self.ttl:
            self.redis.expire(key, self.ttl)

    def check(self, prompt: str) -> Optional[str]:
        if not self.redis.index_exists(self._index_name):
            return None
        query_vec = self.vectorizer.embed(prompt)
        query_bytes = vector_to_bytes(query_vec)
        try:
            results = self.redis.execute(
                "FT.SEARCH", self._index_name,
                f"*=>[KNN {self.top_k} @prompt_vector $vec AS score]",
                "PARAMS", "2", "vec", query_bytes,
                "RETURN", "3", "score", "response", "prompt",
                "SORTBY", "score", "ASC",
                "DIALECT", "2",
            )
        except Exception:
            return None
        return self._best_match(results)

    def _best_match(self, results) -> Optional[str]:
        if not results or results[0] == 0:
            return None
        for i in range(1, len(results), 2):
            fields = results[i + 1]
            record = {}
            for j in range(0, len(fields), 2):
                k = fields[j].decode() if isinstance(fields[j], bytes) else fields[j]
                v = fields[j + 1]
                if isinstance(v, bytes):
                    v = v.decode()
                record[k] = v
            score = float(record.get("score", 1.0))
            if score <= self.distance_threshold:
                return record.get("response")
        return None

    def clear(self):
        self.redis.drop_index(self._index_name)
        for key in self.redis.scan_iter(match=f"{self._prefix}:*"):
            self.redis.delete(key)

    def __len__(self) -> int:
        try:
            result = self.redis.execute("FT.SEARCH", self._index_name, "*", "LIMIT", "0", "0")
            return result[0]
        except Exception:
            return 0
