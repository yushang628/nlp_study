# Redis-VL

基于 Redis Stack (RediSearch) 实现的 redis-vl-python 四核心组件。从零构建，不依赖 `redisvl` 库。

## 组件

| 组件 | 说明 |
|------|------|
| `EmbeddingsCache` | 文本→向量 KV 缓存，避免重复调用 embedding API |
| `SemanticCache` | LLM 响应缓存，基于语义相似度（余弦距离）判断命中 |
| `SemanticMessageHistory` | 对话历史存储，支持时间序和语义两种检索 |
| `SemanticRouter` | 语义路由，基于 KNN 替代传统分类模型做意图识别 |

## 快速开始

```bash
pip install redis sentence-transformers numpy

# 启动 Redis Stack（需 Docker）
docker run -d --name redis-stack -p 6379:6379 redis/redis-stack:latest
```

```python
from SemanticCache import SemanticCache

cache = SemanticCache(name="llmcache", redis_url="redis://localhost:6379")
cache.store("法国首都是哪里？", "巴黎")
print(cache.check("法国首都是什么？"))  # → "巴黎"（语义命中）
```

```python
from SemanticRouter import SemanticRouter, Route
from base.vectorizer import HFTextVectorizer

router = SemanticRouter(
    name="router",
    routes=[
        Route(name="weather", references=["天气", "下雨", "温度"], distance_threshold=0.3),
        Route(name="greeting", references=["你好", "早上好"], distance_threshold=0.3),
    ],
    vectorizer=HFTextVectorizer(model="xxx"),
    redis_url="redis://localhost:6379",
)
match = router("今天天气怎么样？")
print(match.name)  # → "weather"
```

## 运行测试

```bash
# Mock 模式（无需 Redis）
python3 test_integration.py

# 真实 Redis 模式
sed -i 's|redis_url="redis://mock"|redis_url="redis://localhost:6379"|g' test_integration.py
python3 test_integration.py
```

详见 [TESTING.md](TESTING.md)。

## 依赖

- Python 3.10+
- [Redis Stack](https://redis.io/docs/latest/operate/oss_and_stack/install/install-stack/)（含 RediSearch 模块）
- `pip install redis sentence-transformers numpy`

## 项目结构

```
redis-vl/
├── base/
│   ├── redis_client.py      # Redis 连接 + RediSearch 索引管理
│   ├── vectorizer.py        # Vectorizer 抽象 + HuggingFace 实现
│   └── utils.py             # hash、时间戳、向量编解码
├── EmbeddingsCache.py
├── SemanticCache.py
├── SemanticMessageHistory.py
├── SemanticRouter.py
├── test_integration.py
├── CLAUDE.md                # Claude Code 架构指引
└── TESTING.md               # 测试文档
```
