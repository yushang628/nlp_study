# CLAUDE.md

基于 Redis Stack (RediSearch) 实现 redis-vl-python 四核心组件。从零构建，不依赖 `redisvl` 库。

## 项目结构

```
redis-vl/
├── base/
│   ├── redis_client.py      # Redis 连接 + RediSearch 索引管理
│   ├── vectorizer.py        # Vectorizer 抽象 + HFTextVectorizer
│   └── utils.py             # md5_hash, timestamp, vector_to_bytes, make_key
├── EmbeddingsCache.py        # 文本→向量 KV 缓存（精确匹配，无向量索引）
├── SemanticCache.py          # LLM 响应缓存（余弦距离 KNN）
├── SemanticMessageHistory.py # 对话历史（时间序 + 语义检索）
├── SemanticRouter.py         # 语义路由（多类别 KNN 分类器）
├── test_integration.py
├── requirements.txt
├── CLAUDE.md
├── TESTING.md
└── readme.md
```

## 架构分层

```
┌─ EmbeddingsCache ─ SemanticCache ─ SemanticMessageHistory ─ SemanticRouter ─┐
│                          Extension Layer                                     │
├───────────────────────────── Core Layer ────────────────────────────────────┤
│  RedisClient | BaseVectorizer | utils (hash/encode/decode)                  │
├───────────────────────── Redis Stack (RediSearch) ─────────────────────────┤
│  FT.CREATE / FT.SEARCH / FT.DROPINDEX / HSET / SCAN                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 模块 API

### EmbeddingsCache

```python
cache = EmbeddingsCache(name, redis_url, ttl=None)
cache.store(text, embedding, metadata=None)           # → None
cache.check(text)                                     # → EmbeddingRecord | None
cache.clear()
len(cache)  # SCAN 计数，大数据集慢
```

**Redis**: `emb_cache:{name}:{md5(text)}` → Hash(text, embedding JSON, metadata JSON, timestamp)

没有向量索引，key 是用 text 的 MD5 hash 做的精确查找。

### SemanticCache

```python
cache = SemanticCache(name, vectorizer=None, redis_url="...",
                      ttl=None, distance_threshold=0.1, top_k=1)
cache.store(prompt, response, metadata=None, llm_model="")
cache.check(prompt)                                   # → str | None
cache.clear()
len(cache)
```

**Redis**:
- Prefix: `sem_cache:{name}:` / Key: `{uuid}` / Index: `sem_cache:{name}:idx`
- Fields: prompt TEXT, response TEXT, prompt_vector VECTOR(FLAT/COSINE/dims), llm_model TEXT, timestamp NUMERIC, metadata TEXT

**check 流程**: embed query → `FT.SEARCH idx "*=>[KNN top_k @prompt_vector $vec AS score]" RETURN 3 score response prompt SORTBY score ASC` → 取第一个 score < distance_threshold 的 response。

### SemanticMessageHistory

```python
history = SemanticMessageHistory(name, vectorizer=None, redis_url="...",
                                 ttl=None, distance_threshold=0.7, top_k=10)
history.add_message(role, content, metadata=None)
history.add_messages([{role, content, metadata}, ...])
history.get_recent(top_k=10, role=None)               # → List[Message]
history.get_relevant(query, top_k=5, role=None)       # → List[Message] (filtered by score ≤ distance_threshold)
history.clear()
len(history)
```

**Redis**: role TAG, content TEXT, timestamp NUMERIC, metadata TEXT
- `get_recent(role="user")` → `FT.SEARCH idx "@role:{user}" SORTBY timestamp DESC LIMIT 0 top_k`
- `get_relevant(role="user")` → `FT.SEARCH idx "(@role:{user})=>[KNN top_k @content_vector $vec AS score]"`

role 验证: `("user", "assistant", "llm", "system", "tool")`，不在此集合中 fallback 到 `"user"`。

### SemanticRouter

```python
router = SemanticRouter(name, routes=None, vectorizer=None, redis_url="...", top_k=10)
router(query)                                         # → RouteMatch | None
router.add_route(route)
router.list_routes()                                  # → List[Route]
router.delete_route(route_name)
router.clear()
len(router)
```

**Route**: name, references, metadata, distance_threshold
**RouteMatch**: name, distance, metadata

**Redis**: route_name TEXT, reference TEXT, distance_threshold NUMERIC, metadata TEXT
- Key 模式: `sem_router:{name}:{route_name}:{ref_index}`
- `__call__` 在 Redis 侧取 KNN top_k，在 Python 侧按各自的 distance_threshold 筛选，返回距离最小的匹配。

## Redis Schema 汇总

| 组件 | 索引名 | Key 模式 | 向量字段 |
|------|--------|---------|---------|
| EmbeddingsCache | — | `emb_cache:{n}:{md5}` | — |
| SemanticCache | `sem_cache:{n}:idx` | `sem_cache:{n}:{uuid}` | prompt_vector |
| SemanticMessageHistory | `msg_history:{n}:idx` | `msg_history:{n}:{uuid}` | content_vector |
| SemanticRouter | `sem_router:{n}:idx` | `sem_router:{n}:{route}:{i}` | ref_vector |

## 关键技术决策

| 决策 | 选择 | 原因 |
|------|------|------|
| 距离度量 | COSINE | 语义搜索标准 |
| 向量字段类型 | FLOAT32 | RediSearch 原生 |
| 索引算法 | FLAT | 小型缓存足够；大数据集改 HNSW |
| 存储后端 | Redis Hash | 简单字段查询高效 |
| role 字段类型 | TAG | 支持 `@role:{user}` 精确过滤 |

## 异常处理策略

- `RedisClient.__init__` 检查 RediSearch 模块，未加载抛 `RedisModuleError`
- `_create_index()` 用 `try/except redis.ResponseError` 防护竞态条件
- FT.SEARCH 异常统一吞掉，返回 None / []（缓存组件容错优先）
- `drop_index()` 内部 try/except，幂等
- `clear()` 先删索引再删 keys，即使索引删除失败 keys 也会被清理

## 边界情况

- 索引不存在时 `check()` / `get_recent()` / `__call__()` 返回 None / [] 而非崩溃
- 空数据集时 `__len__()` 返回 0
- role 不在白名单时 fallback 到 `"user"`
- `delete_route()` 只删除 hash key，RediSearch 自动从索引移除

## 测试

```bash
python3 test_integration.py
```

MockRedisClient 模拟 RediSearch 行为，无需真实 Redis。详见 TESTING.md。

## 开发命令

```bash
pip install redis sentence-transformers numpy
docker run -d --name redis-stack -p 6379:6379 redis/redis-stack:latest
redis-cli MODULE LIST | grep search
python3 test_integration.py
```
