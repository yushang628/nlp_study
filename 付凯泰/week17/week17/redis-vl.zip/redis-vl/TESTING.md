# 测试文档

## 运行方式

```bash
# 安装依赖
pip install redis sentence-transformers numpy

# Mock 模式（无需 Redis，默认）
python3 test_integration.py

# 切换为真实 Redis
sed -i 's|redis_url="redis://mock"|redis_url="redis://localhost:6379"|g' test_integration.py
python3 test_integration.py

# 运行单个组件
python3 -c "
from test_integration import *
test_semantic_cache()
print(f'Passed: {tally.passed}/{tally.total}')
"
```

## 测试架构

```
test_integration.py
├── MockRedisClient           # 内存模拟 RediSearch（FT.CREATE / FT.SEARCH / FT.DROPINDEX 等）
├── ContentVectorizer         # 4 维关键词分类向量，余弦距离反映主题相似度
├── Test Cases
│   ├── EmbeddingsCache       (8 断言)
│   ├── SemanticCache         (6 断言)
│   ├── SemanticMessageHistory (11 断言)
│   └── SemanticRouter        (14 断言)
└── Tally                     # 断言计数器
```

业务代码无需修改即可在 MockRedisClient 上运行。Mock 精确模拟了所有组件用到的 RediSearch 命令。

## 覆盖矩阵

### EmbeddingsCache (8)

| 场景 | 验证 |
|------|------|
| store + check | record 非 None，text/embedding/metadata 一致 |
| miss | 不存在返回 None |
| 覆盖写 | 新 embedding 生效 |
| clear + __len__ | 清空后 check 返回 None，length 为 0 |

### SemanticCache (6)

| 场景 | 验证 |
|------|------|
| 精确匹配 | 返回正确 response |
| 语义近匹配 | 同义 query 命中同一条 |
| 另一语义近匹配 | 跨主题（weather）能命中对应 entry |
| 无关 query | 超出 distance_threshold 返回 None |
| clear + __len__ | 清空后 check 返回 None，length 为 0 |

### SemanticMessageHistory (11)

| 场景 | 验证 |
|------|------|
| get_recent(top_k=2) | 返回 2 条，内容正确（按 timestamp DESC） |
| get_recent(role="user") | 只返回 user 消息（3 条） |
| get_recent(role="assistant") | 只返回 assistant 消息（3 条） |
| get_relevant("weather") | 语义搜索命中 weather/温度相关内容 |
| get_relevant + role='user' | 语义 + TAG 过滤，结果 role 全部为 user |
| clear + __len__ | 清空后长度为 0 |

### SemanticRouter (14)

| 场景 | 验证 |
|------|------|
| "hey" → greeting | 非 None，name=greeting，distance ≤ 0.3，metadata.type=greeting |
| "temperature" → weather | 非 None，name=weather |
| "see you" → farewell | 非 None，name=farewell |
| "quantum physics" → None | 无匹配 |
| list_routes | 返回 3 条，names 集合正确 |
| delete_route("farewell") | 剩 2 条，farewell 不出现 |
| clear + __len__ | 清空后长度为 0 |

## 测试数据设计

`ContentVectorizer` 使用 4 维关键词分类，向量归一化到单位长度：

| 维度 | 分类 | 触发词 |
|------|------|--------|
| dim[0] | geography | france, paris, capital, germany, berlin, country |
| dim[1] | weather | weather, sunny, rain, raining, temperature, degrees |
| dim[2] | greeting | hello, hi, hey, how, are, you, good, morning |
| dim[3] | farewell | bye, goodbye, see, farewell, later |

## MockRedisClient 支持的命令

| 命令 | 模拟程度 |
|------|---------|
| `FT.CREATE` | 前缀 + 向量字段 + TAG 字段 |
| `FT.SEARCH` | KNN/余弦距离/TAG过滤/SORTBY/LIMIT/RETURN |
| `FT.INFO` | num_docs |
| `FT._LIST` | 已注册索引列表 |
| `FT.DROPINDEX` | 删除索引 |
| HSET / HGETALL / HDEL / DEL / EXPIRE / EXISTS / SCAN | 完整 |
