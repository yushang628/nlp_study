import json
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

from base.redis_client import RedisClient
from base.utils import md5_hash, timestamp, make_key


@dataclass
class EmbeddingRecord:
    text: str
    embedding: List[float]
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = 0.0


class EmbeddingsCache:
    def __init__(
        self,
        name: str,
        redis_url: str = "redis://localhost:6379",
        ttl: Optional[int] = None,
        **redis_kwargs,
    ):
        self.name = name
        self.ttl = ttl
        self.redis = RedisClient(redis_url, **redis_kwargs)
        self._prefix = f"emb_cache:{name}"

    def _key(self, text: str) -> str:
        return make_key(self._prefix, md5_hash(text))

    def store(
        self,
        text: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
    ):
        key = self._key(text)
        self.redis.hset(key, {
            "text": text,
            "embedding": json.dumps(embedding),
            "metadata": json.dumps(metadata or {}),
            "timestamp": str(timestamp()),
        })
        if self.ttl:
            self.redis.expire(key, self.ttl)

    def check(self, text: str) -> Optional[EmbeddingRecord]:
        key = self._key(text)
        data = self.redis.hgetall(key)
        if not data:
            return None
        decode = lambda b: b.decode() if isinstance(b, bytes) else b
        return EmbeddingRecord(
            text=decode(data[b"text"]),
            embedding=json.loads(decode(data[b"embedding"])),
            metadata=json.loads(decode(data.get(b"metadata", b"{}"))),
            timestamp=float(decode(data[b"timestamp"])),
        )

    def clear(self):
        for key in self.redis.scan_iter(match=f"{self._prefix}:*"):
            self.redis.delete(key)

    def __len__(self) -> int:
        count = 0
        for _ in self.redis.scan_iter(match=f"{self._prefix}:*"):
            count += 1
        return count
