import json
import uuid
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

import redis

from base.redis_client import RedisClient
from base.vectorizer import BaseVectorizer, HFTextVectorizer
from base.utils import make_key, vector_to_bytes, timestamp


@dataclass
class Message:
    role: str
    content: str
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = 0.0
    score: Optional[float] = None


class SemanticMessageHistory:
    def __init__(
        self,
        name: str,
        vectorizer: Optional[BaseVectorizer] = None,
        redis_url: str = "redis://localhost:6379",
        ttl: Optional[int] = None,
        distance_threshold: float = 0.7,
        top_k: int = 10,
        **redis_kwargs,
    ):
        self.name = name
        self.ttl = ttl
        self.distance_threshold = distance_threshold
        self.top_k = top_k
        self.vectorizer = vectorizer or HFTextVectorizer()
        self.redis = RedisClient(redis_url, **redis_kwargs)
        self._prefix = make_key("msg_history", name)
        self._index_name = make_key("msg_history", name, "idx")
        self._create_index()

    def _create_index(self):
        if self.redis.index_exists(self._index_name):
            return
        try:
            self.redis.create_vector_index(
                index_name=self._index_name,
                prefix=f"{self._prefix}:",
                vector_field="content_vector",
                dims=self.vectorizer.dimensions,
                extra_fields=[
                    "role TAG",
                    "content TEXT",
                    "timestamp NUMERIC",
                    "metadata TEXT",
                ],
            )
        except redis.ResponseError:
            pass  # race: another instance already created it

    def add_message(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        if role not in ("user", "assistant", "llm", "system", "tool"):
            role = "user"
        key = make_key(self._prefix, uuid.uuid4().hex)
        embedding = self.vectorizer.embed(content)
        self.redis.hset(key, {
            "role": role,
            "content": content,
            "content_vector": vector_to_bytes(embedding),
            "timestamp": str(timestamp()),
            "metadata": json.dumps(metadata or {}),
        })
        if self.ttl:
            self.redis.expire(key, self.ttl)

    def add_messages(self, messages: List[Dict[str, Any]]):
        for msg in messages:
            self.add_message(
                role=msg.get("role", "user"),
                content=msg.get("content", ""),
                metadata=msg.get("metadata"),
            )

    def get_recent(
        self,
        top_k: int = 10,
        role: Optional[str] = None,
    ) -> List[Message]:
        if not self.redis.index_exists(self._index_name):
            return []
        query = "*"
        if role:
            query = f"@role:{{{role}}}"
        try:
            results = self.redis.execute(
                "FT.SEARCH", self._index_name, query,
                "SORTBY", "timestamp", "DESC",
                "RETURN", "4", "role", "content", "timestamp", "metadata",
                "LIMIT", "0", str(top_k),
                "DIALECT", "2",
            )
        except Exception:
            return []
        return self._parse_messages(results)

    def get_relevant(
        self,
        query: str,
        top_k: int = 5,
        role: Optional[str] = None,
    ) -> List[Message]:
        if not self.redis.index_exists(self._index_name):
            return []
        query_vec = self.vectorizer.embed(query)
        query_bytes = vector_to_bytes(query_vec)
        filter_clause = "*"
        if role:
            filter_clause = f"(@role:{{{role}}})"
        try:
            results = self.redis.execute(
                "FT.SEARCH", self._index_name,
                f"{filter_clause}=>[KNN {top_k} @content_vector $vec AS score]",
                "PARAMS", "2", "vec", query_bytes,
                "RETURN", "5", "score", "role", "content", "timestamp", "metadata",
                "SORTBY", "score", "ASC",
                "LIMIT", "0", str(top_k),
                "DIALECT", "2",
            )
        except Exception:
            return []
        messages = self._parse_messages(results, has_score=True)
        return [m for m in messages if m.score is not None and m.score <= self.distance_threshold]

    def _parse_messages(self, results, has_score=False) -> List[Message]:
        messages = []
        if not results or results[0] == 0:
            return messages
        for i in range(1, len(results), 2):
            fields = results[i + 1]
            record = {}
            for j in range(0, len(fields), 2):
                k = fields[j].decode() if isinstance(fields[j], bytes) else fields[j]
                v = fields[j + 1]
                if isinstance(v, bytes):
                    v = v.decode()
                record[k] = v
            messages.append(Message(
                role=record.get("role", "user"),
                content=record.get("content", ""),
                metadata=json.loads(record.get("metadata", "{}")),
                timestamp=float(record.get("timestamp", 0)),
                score=float(record["score"]) if has_score and "score" in record else None,
            ))
        return messages

    def clear(self):
        self.redis.drop_index(self._index_name)
        for key in self.redis.scan_iter(match=f"{self._prefix}:*"):
            self.redis.delete(key)

    def __len__(self) -> int:
        try:
            result = self.redis.execute("FT.SEARCH", self._index_name, "*", "LIMIT", "0", "0")
            return result[0]
        except Exception:
            return 0
