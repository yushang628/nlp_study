# 🐺 狼人杀多Agent博弈系统

基于多Agent协作框架的狼人杀游戏系统，支持AI自主对战、评测复盘和前端观战。

## 📋 功能特性

### 核心功能
- **多Agent协作/对抗**：每个Agent根据角色拥有独立目标和策略
- **信息隔离**：严格的私有信息管理，确保角色间信息不泄露
- **完整对局引擎**：支持夜间行动（狼人杀人、预言家查验、女巫用药）和白天行动（演讲、投票）
- **结构化日志**：全程可观测的游戏记录
- **前端观战UI**：支持纯AI对战，实时博弈可视化

### 进阶功能：评测+复盘体系
- **多维评测指标**：玩家表现、策略有效性、发言分析、投票准确率
- **复盘归因**：关键决策识别、胜负因素分析、改进建议
- **Leaderboard**：支持不同版本/模型Agent同台竞技

### 个性化发言
- 每个角色拥有独特的发言模板
- 支持4种决策风格：谨慎型、大胆型、平衡型、随机型
- 发言内容根据游戏状态动态生成

## 🏗️ 项目结构

```
AI作业/
├── agent/                  # Agent模块
│   ├── base.py            # 基础Agent类
│   ├── player_agent.py    # 玩家Agent（支持4种决策风格）
│   └── summary_agent.py   # 总结Agent
├── api/                   # API接口
│   ├── models.py          # Pydantic模型
│   └── server.py          # FastAPI服务器
├── config/                # 配置文件
│   └── system_config.json # 系统配置
├── engine/                # 游戏引擎
│   ├── game_engine.py     # 核心游戏逻辑
│   ├── phase.py           # 阶段定义
│   ├── player.py          # 玩家类
│   └── state.py           # 状态管理
├── roles/                 # 角色定义
│   ├── base.py            # 基础角色类
│   ├── werewolf.py        # 狼人
│   ├── seer.py            # 预言家
│   ├── witch.py           # 女巫
│   ├── hunter.py          # 猎人
│   └── villager.py        # 村民
├── review/                # 评测复盘
│   ├── evaluator.py       # 游戏评测器
│   ├── leaderboard.py     # 排行榜
│   └── replay_analyzer.py  # 复盘分析
├── frontend/              # 前端观战UI
│   └── index.html         # 观战界面
├── logs/                  # 游戏日志
├── memory/                # 经验存储
│   ├── experiences/        # 角色经验
│   └── leaderboard.json   # 排行榜数据
├── tests/                 # 测试用例
├── main_demo.py           # 演示入口
└── requirements.txt       # 依赖清单
```

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 运行演示

#### 命令行演示
```bash
# 标准6人局
python main_demo.py --config standard_6

# 标准9人局
python main_demo.py --config big_9

# 自定义风格
python main_demo.py --config standard_6 --styles '{"0":"bold","1":"cautious","2":"bold","3":"cautious","4":"bold","5":"random"}'
```

#### API服务器 + 前端观战
```bash
# 启动API服务器
uvicorn api.server:app --host 0.0.0.0 --port 8000

# 启动前端（需要另外的终端）
cd frontend && python -m http.server 8080

# 访问观战界面
http://localhost:8080
```

### 3. 使用API

```bash
# 创建游戏
curl -X POST http://localhost:8000/api/create -H "Content-Type: application/json" -d '{"config": "standard_6"}'

# 单步执行
curl -X POST http://localhost:8000/api/step -H "Content-Type: application/json" -d '{"game_id": "your_game_id"}'

# 获取游戏状态
curl http://localhost:8000/api/status/your_game_id

# 获取排行榜
curl http://localhost:8000/leaderboard
```

## 🎮 游戏配置

### 标准6人局
- 2狼人 + 1预言家 + 1女巫 + 1猎人 + 1村民

### 标准9人局
- 3狼人 + 1预言家 + 1女巫 + 1猎人 + 3村民

### 自定义配置
```python
from engine.game_engine import GameEngine, get_role_config

role_assignment = get_role_config('standard_6')
player_names = ['玩家1', '玩家2', '玩家3', '玩家4', '玩家5', '玩家6']

styles = {
    0: 'bold',      # 大胆型
    1: 'cautious',  # 谨慎型
    2: 'balanced',  # 平衡型
    3: 'random',    # 随机型
}
```

## 🎭 角色说明

| 角色 | 阵营 | 能力 |
|------|------|------|
| 狼人 | 邪恶 | 夜间击杀一名玩家 |
| 预言家 | 善良 | 每晚查验一名玩家身份 |
| 女巫 | 善良 | 拥有解药和毒药各一瓶 |
| 猎人 | 善良 | 死亡时可开枪带走一人 |
| 村民 | 善良 | 无特殊能力，通过发言找狼 |

## 🎯 决策风格

| 风格 | 描述 | 特点 |
|------|------|------|
| 谨慎型 | 宁可放过可疑玩家，也不轻易误杀好人 | 保守分析，少说少错 |
| 大胆型 | 敢于冒险，快速做出判断 | 激进指控，主动带队 |
| 平衡型 | 综合考虑各种因素 | 客观分析，理性投票 |
| 随机型 | 不要过度分析，依靠直觉 | 随机发言，看心情 |

## 📊 评测体系

### 评测指标
- **结果评测**：胜负判定、存活轮次、贡献度
- **过程评测**：发言质量、投票准确率、策略有效性
- **角色表现**：预言家查验准确率、女巫用药时机、狼人存活能力

### 查看复盘报告
```python
from review.replay_analyzer import ReplayAnalyzer

analyzer = ReplayAnalyzer()
analyzer.load_game('game_20260528_203433')
print(analyzer.generate_report())
```

### 查看排行榜
```python
from review.leaderboard import Leaderboard

lb = Leaderboard()
print(lb.generate_report())
```

## 🔧 配置说明

### 系统配置 (config/system_config.json)
```json
{
  "default_model": "gpt-3.5-turbo",
  "api_key": "your-api-key",
  "log_level": "INFO",
  "max_turns": 50,
  "enable_memory": true
}
```

### 游戏配置
可在 `main_demo.py` 中修改 `GAME_CONFIGS` 字典来自定义游戏配置。

## 📝 日志说明

### 游戏记录
- 位置：`logs/game_<timestamp>.json`
- 内容：完整游戏对话、死亡记录、角色分配

### 运行日志
- 位置：`logs/game_<timestamp>_run_log.json`
- 内容：阶段耗时、决策过程、系统日志

### 经验数据
- 位置：`memory/experiences/<role>.json`
- 内容：各角色的历史经验和学习数据

## 🛠️ 开发指南

### 添加新角色
1. 在 `roles/` 目录创建新的角色文件
2. 继承 `BaseRole` 类
3. 实现 `role_type`、`camp` 和能力方法
4. 在 `player_agent.py` 中添加发言模板

### 添加新评测指标
1. 在 `review/evaluator.py` 中添加评测方法
2. 更新 `generate_metrics()` 方法
3. 在 `review/replay_analyzer.py` 中添加分析逻辑

### API扩展
1. 在 `api/models.py` 中定义新的数据模型
2. 在 `api/server.py` 中添加新的路由
3. 更新前端UI以支持新功能

## 🐛 常见问题

### Q: 如何修改AI模型？
A: 在 `config/system_config.json` 中修改 `default_model` 字段。

### Q: 如何增加发言多样性？
A: 在 `agent/player_agent.py` 的 `SPEECH_TEMPLATES` 字典中添加更多发言模板。

### Q: 如何查看特定游戏的详细信息？
A: 在 `logs/` 目录中找到对应的JSON文件，或使用 `ReplayAnalyzer` 类进行分析。

### Q: 如何让AI使用真实的大模型？
A: 修改 `agent/player_agent.py` 中的 `_get_llm_response` 方法，集成实际的API调用。

## 📄 许可证

MIT License

## 🙏 致谢

参考项目：[evo-werewolf-agent](https://github.com/your-repo)

---

**版本**: 1.0.0  
**更新时间**: 2026-05-28
