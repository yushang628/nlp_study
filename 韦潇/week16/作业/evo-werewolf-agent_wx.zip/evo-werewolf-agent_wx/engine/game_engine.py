import asyncio
from typing import List, Dict, Any, Optional

from engine.state import GameState
from engine.phase import GamePhase, TurnOrder
from engine.player import Player
from roles.base import RoleType
from roles.werewolf import Werewolf
from roles.seer import Seer
from roles.witch import Witch
from roles.hunter import Hunter
from roles.villager import Villager
from agent.player_agent import PlayerAgent, create_player_agent, create_judge_agent
from agent.summary_agent import SummaryAgent
from memory.experience import save_experience


class GameEngine:
    def __init__(self, player_names: List[str], logger=None):
        self.player_names = player_names
        self.game_state = GameState()
        self.judge_agent = create_judge_agent()
        self.player_agents: Dict[int, PlayerAgent] = {}
        self._is_running = False
        self._controller = None
        self.logger = logger
        self.death_records: List[Dict[str, Any]] = []
        self._night_death_causes: Dict[int, str] = {}
        self._step_index = 0
        self.game_id = None
        self._summaries_done = False
        self._summary_agent = SummaryAgent()
        self.summaries: List[Dict] = []

    def _log(self, level: str, msg: str):
        if self.logger:
            if level == "log_action":
                self.logger.log_action_event(msg)
            elif level == "log_speech":
                self.logger.log_speech_event(msg)
            elif level == "log_vote":
                self.logger.log_vote_event(msg)
            elif level == "log_death":
                self.logger.log_death_event(msg)
            elif level == "log_night_action":
                self.logger.log_night_action_event(msg)
            elif level == "log_event":
                self.logger.log_event(msg)
            else:
                getattr(self.logger, level.lower())(msg)

    async def initialize(self, role_assignment: Dict[int, str], player_styles: Dict[int, str] = None):
        if player_styles is None:
            player_styles = {}

        for player_id, name in enumerate(self.player_names):
            role_type = role_assignment.get(player_id, "villager")
            role = self._create_role(role_type, player_id)
            player = Player(player_id=player_id, role=role, name=name)

            style = player_styles.get(player_id, "balanced")
            private_context = player.role.get_private_context()
            agent = create_player_agent(
                player_id=player_id,
                role_name=role.name,
                private_context=private_context,
                camp=role.camp.value,
                decision_style=style,
                role_type=role.role_type.value,
            )
            player.agent = agent
            self.player_agents[player_id] = agent

            self.game_state.players.append(player)

        self.game_state.set_speaker_order([p.player_id for p in self.game_state.players])
        print(f"游戏初始化完成，{len(self.game_state.players)} 名玩家已就位。")

    def _create_role(self, role_type: str, player_id: int):
        role_map = {
            "werewolf": Werewolf,
            "seer": Seer,
            "witch": Witch,
            "hunter": Hunter,
            "villager": Villager,
        }
        role_class = role_map.get(role_type, Villager)
        return role_class(player_id=player_id)

    async def start(self, controller=None):
        self._is_running = True
        self._controller = controller
        print("=" * 50)
        print("狼人杀游戏开始！")
        print("=" * 50)

        while self._is_running and not self.game_state.is_game_over():
            if self._controller:
                action = await self._controller.wait_if_needed(
                    self.game_state.day_number, "day_start"
                )
                if action == "stop":
                    self._is_running = False
                    break
                elif action == "skip_to_end":
                    break

            await self._night_phase()

            if self.game_state.is_game_over():
                break

            await self._day_phase()
            self.game_state.day_number += 1

        await self._end_game()

    async def step(self) -> Dict[str, Any]:
        if not self.game_state.players:
            raise RuntimeError("Game not initialized. Call initialize() first.")

        if self._step_index == -1 or (self.game_state.is_game_over() and self._step_index not in (-1, 7, 8)):
            winner = self.game_state.get_winner()
            if self.game_state.is_game_over() and self._step_index not in (-1, 7, 8) and not self._summaries_done:
                self._step_index = 8
            return {
                "phase": "game_over",
                "day_number": self.game_state.day_number,
                "step_data": {},
                "players": [p.to_dict() for p in self.game_state.players],
                "dialogues": [],
                "deaths": list(self.death_records),
                "is_game_over": True,
                "winner": winner,
            }

        dialog_len_before = len(self.game_state.dialogues)
        death_len_before = len(self.death_records)
        step_data: Dict[str, Any] = {}
        phase_name = ""

        if self._step_index == 0:
            self.game_state.clear_night_deaths()
            self._night_death_causes.clear()
            self.game_state.phase = GamePhase.NIGHT_WOLF
            phase_name = "night_wolf"
            print(f"\n{'='*30} 第 {self.game_state.day_number} 夜 {'='*30}")
            self._log("info", f"=== 第 {self.game_state.day_number} 夜 ===")
            await self._wolf_kill()
            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            wolf_votes = [
                {"player_id": d["player_id"], "target": d.get("target"), "reasoning": d.get("reasoning")}
                for d in new_dialogues if d.get("action") == "night_kill"
            ]
            step_data = {
                "wolf_votes": wolf_votes,
                "final_target": self.game_state.night_deaths[-1] if self.game_state.night_deaths else None,
            }

        elif self._step_index == 1:
            self.game_state.phase = GamePhase.NIGHT_SEER
            phase_name = "night_seer"
            await self._seer_check()
            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            seer_data = {}
            for d in new_dialogues:
                if d.get("action") == "seer_check":
                    seer_data = {
                        "seer_id": d["player_id"],
                        "target": d.get("target"),
                        "result": d.get("result"),
                        "reasoning": d.get("reasoning"),
                    }
            step_data = seer_data

        elif self._step_index == 2:
            self.game_state.phase = GamePhase.NIGHT_WITCH
            phase_name = "night_witch"
            await self._witch_action()
            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            witch_data = {}
            for d in new_dialogues:
                if d.get("action") in ("heal", "poison"):
                    witch_data = {
                        "action": d["action"],
                        "target": d.get("target"),
                    }
            step_data = witch_data

        elif self._step_index == 3:
            phase_name = "night_result"
            await self._announce_night_deaths()
            await self._handle_hunter_death(list(self.game_state.night_deaths))
            new_deaths = self.death_records[death_len_before:]
            step_data = {
                "night_deaths": list(self.game_state.night_deaths),
                "deaths": new_deaths,
            }

        elif self._step_index == 4:
            self.game_state.phase = GamePhase.DAY_START
            phase_name = "day_start"
            print(f"\n{'='*30} 第 {self.game_state.day_number} 天 {'='*30}")
            self._log("info", f"=== 第 {self.game_state.day_number} 天 ===")
            await self._announce_day_start()
            step_data = {}

        elif self._step_index == 5:
            self.game_state.phase = GamePhase.SPEECH
            phase_name = "speech"
            await self._public_speeches()
            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            speeches = [
                {"player_id": d["player_id"], "player_name": d.get("player_name"), "content": d.get("content")}
                for d in new_dialogues if d.get("action") == "speech"
            ]
            step_data = {"speeches": speeches}

        elif self._step_index == 6:
            self.game_state.phase = GamePhase.VOTE
            phase_name = "vote"
            await self._vote()
            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            votes = {}
            for d in new_dialogues:
                if d.get("action") == "vote":
                    votes[d["player_id"]] = d.get("target")
            new_deaths = self.death_records[death_len_before:]
            eliminated = None
            for death in new_deaths:
                if death.get("cause") in ("vote", "shoot"):
                    eliminated = death["player_id"]
            step_data = {"votes": votes, "eliminated": eliminated}

        elif self._step_index == 7:
            phase_name = "day_end"
            game_over = self.game_state.is_game_over()
            winner = self.game_state.get_winner()
            if game_over:
                self._is_running = False
                self._step_index = 8
            else:
                self.game_state.day_number += 1
                self._step_index = 0

            new_dialogues = self.game_state.dialogues[dialog_len_before:]
            new_deaths = self.death_records[death_len_before:]
            step_data = {
                "game_over": game_over,
                "winner": winner,
                "next_day": self.game_state.day_number if not game_over else None,
            }
            return {
                "phase": phase_name,
                "day_number": self.game_state.day_number,
                "step_data": step_data,
                "players": [p.to_dict() for p in self.game_state.players],
                "dialogues": new_dialogues,
                "deaths": new_deaths,
                "is_game_over": game_over,
                "winner": winner,
            }

        elif self._step_index == 8:
            phase_name = "summary"
            await self._run_summaries()
            self._step_index = -1
            self._summaries_done = True
            winner = self.game_state.get_winner()
            step_data = {"summaries_complete": True, "summaries": list(self.summaries)}
            return {
                "phase": phase_name,
                "day_number": self.game_state.day_number,
                "step_data": step_data,
                "players": [p.to_dict() for p in self.game_state.players],
                "dialogues": [],
                "deaths": list(self.death_records),
                "is_game_over": True,
                "winner": winner,
            }

        new_dialogues = self.game_state.dialogues[dialog_len_before:]
        new_deaths = self.death_records[death_len_before:]
        self._step_index += 1

        return {
            "phase": phase_name,
            "day_number": self.game_state.day_number,
            "step_data": step_data,
            "players": [p.to_dict() for p in self.game_state.players],
            "dialogues": new_dialogues,
            "deaths": new_deaths,
            "is_game_over": False,
            "winner": None,
        }

    async def _night_phase(self):
        day = self.game_state.day_number
        print(f"\n{'='*30} 第 {day} 夜 {'='*30}")
        self._log("info", f"=== 第 {day} 夜 ===")

        self.game_state.clear_night_deaths()
        self._night_death_causes.clear()

        night_order = TurnOrder.get_night_order()

        for phase in night_order:
            if self.game_state.is_game_over():
                break

            self.game_state.phase = phase
            print(f"\n[{phase.value}]")
            self._log("debug", f"阶段: {phase.value}")

            if phase == GamePhase.NIGHT_WOLF:
                await self._wolf_kill()
            elif phase == GamePhase.NIGHT_SEER:
                await self._seer_check()
            elif phase == GamePhase.NIGHT_WITCH:
                await self._witch_action()

        await self._announce_night_deaths()
        await self._handle_hunter_death(self.game_state.night_deaths)

    async def _wolf_kill(self):
        alive_wolves = [
            p for p in self.game_state.players
            if p.role_type == RoleType.WEREWOLF and p.is_alive
        ]

        if not alive_wolves:
            return

        kill_targets = []
        for wolf in alive_wolves:
            if wolf.agent:
                game_state = self.game_state.get_player_private_context(wolf.player_id)
                decision = await wolf.agent.decide_night_action(game_state)
                target = decision.get("target")
                reasoning = decision.get("reasoning", "")
                if target is not None and target != wolf.player_id:
                    kill_targets.append(target)
                elif target is not None:
                    self._log("log_event", f"狼人{wolf.player_id} 试图自杀，被忽略")
                print(f"狼人 {wolf.player_id} 决策：击杀玩家 {target}")
                self._log("log_action", f"狼人{wolf.player_id} 决策: 击杀玩家{target}")
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "狼人杀人",
                    "player_id": wolf.player_id,
                    "player_name": wolf.name,
                    "role": wolf.role.name,
                    "action": "night_kill",
                    "target": target,
                    "reasoning": reasoning,
                })

        if kill_targets:
            target = self._count_vote(kill_targets)
            self.game_state.add_night_death(target)
            self._night_death_causes[target] = "night_kill"
            print(f"狼人今晚击杀：玩家 {target}")
            self._log("log_action", f"狼人击杀目标: 玩家{target}")

    async def _seer_check(self):
        alive_seers = [
            p for p in self.game_state.players
            if p.role_type == RoleType.SEER and p.is_alive
        ]

        for seer in alive_seers:
            if seer.agent:
                game_state = self.game_state.get_player_private_context(seer.player_id)
                decision = await seer.agent.decide_night_action(game_state)
                target = decision.get("target")
                reasoning = decision.get("reasoning", "")
                if target is not None:
                    player = self.game_state.get_player(target)
                    if player:
                        result = "wolf" if player.role_type == RoleType.WEREWOLF else "good"
                        print(f"预言家 {seer.player_id} 查验玩家 {target}：{result}")
                        seer.role._check_result = {"target": target, "result": result}
                        self._log("log_night_action", f"预言家{seer.player_id} 查验玩家{target}: {result}")
                        self.game_state.dialogues.append({
                            "day": self.game_state.day_number,
                            "phase": "预言家查验",
                            "player_id": seer.player_id,
                            "player_name": seer.name,
                            "role": seer.role.name,
                            "action": "seer_check",
                            "target": target,
                            "result": result,
                            "reasoning": reasoning,
                        })

    async def _witch_action(self):
        alive_witches = [
            p for p in self.game_state.players
            if p.role_type == RoleType.WITCH and p.is_alive
        ]

        tonight_death = self.game_state.night_deaths[-1] if self.game_state.night_deaths else None

        for witch in alive_witches:
            if witch.agent and (witch.role.has_heal or witch.role.has_poison):
                game_state = self.game_state.get_player_private_context(witch.player_id)
                game_state["tonight_death"] = tonight_death
                decision = await witch.agent.decide_night_action(game_state)

                action = decision.get("action", "")
                target = decision.get("target")

                used_heal = "heal" in action and tonight_death is not None and witch.role.has_heal
                used_poison = "poison" in action and target is not None and witch.role.has_poison and target != witch.player_id

                if used_heal:
                    witch.role.use_heal()
                    if tonight_death in self.game_state.night_deaths:
                        self.game_state.night_deaths.remove(tonight_death)
                    print(f"女巫 {witch.player_id} 使用救人药，救活了玩家 {tonight_death}")
                    self._log("log_night_action", f"女巫{witch.player_id} 使用救人药")
                elif used_poison:
                    witch.role.use_poison()
                    self.game_state.add_night_death(target)
                    self._night_death_causes[target] = "poison"
                    print(f"女巫 {witch.player_id} 使用毒药，毒死了玩家 {target}")
                    self._log("log_night_action", f"女巫{witch.player_id} 使用毒药，目标: {target}")

                if used_heal or used_poison:
                    self.game_state.dialogues.append({
                        "day": self.game_state.day_number,
                        "phase": "女巫用药",
                        "player_id": witch.player_id,
                        "player_name": witch.name,
                        "role": witch.role.name,
                        "action": "heal" if used_heal else "poison",
                        "target": tonight_death if used_heal else (target if used_poison else None),
                    })
                elif "poison" in action and target == witch.player_id:
                    self._log("log_event", f"女巫{witch.player_id} 试图毒自己，被忽略")

    async def _handle_hunter_death(self, killed_player_ids: List[int]):
        for player_id in killed_player_ids:
            player = self.game_state.get_player(player_id)
            if player and player.role_type == RoleType.HUNTER and player.role.can_shoot:
                alive_players = self.game_state.get_alive_players()
                if alive_players:
                    target = alive_players[0].player_id
                    player.role.lock_shoot()
                    target_player = self.game_state.get_player(target)
                    if target_player:
                        target_player.role.is_alive = False
                        print(f"猎人 {player_id} 开枪带走了玩家 {target}")
                        self._log("log_death", f"猎人{player_id} 开枪带走玩家{target}")
                        self.death_records.append({
                            "player_id": target,
                            "player_name": target_player.name,
                            "role": target_player.role.name,
                            "cause": "shoot",
                            "day": self.game_state.day_number,
                        })
                        self.game_state.dialogues.append({
                            "day": self.game_state.day_number,
                            "phase": "猎人开枪",
                            "player_id": player_id,
                            "player_name": player.name,
                            "role": player.role.name,
                            "action": "hunter_shot",
                            "target": target,
                            "reasoning": f"猎人{player_id}开枪带走玩家{target}",
                        })

    async def _announce_night_deaths(self):
        if self.game_state.night_deaths:
            for player_id in self.game_state.night_deaths:
                player = self.game_state.get_player(player_id)
                if player:
                    cause = self._night_death_causes.get(player_id, "night_kill")
                    player.kill(cause, self.game_state.to_dict())
                    print(f"玩家 {player_id} ({player.role.name}) 死亡")
                    self._log("log_death", f"玩家{player_id}({player.role.name}) 死亡")
                    self.death_records.append({
                        "player_id": player_id,
                        "player_name": player.name,
                        "role": player.role.name,
                        "cause": cause,
                        "day": self.game_state.day_number,
                    })
        else:
            print("今晚无人死亡")
            self._log("log_event", "今晚无人死亡")

    async def _day_phase(self):
        print(f"\n{'='*30} 第 {self.game_state.day_number} 天 {'='*30}")
        self._log("info", f"=== 第 {self.game_state.day_number} 天 ===")

        self.game_state.phase = GamePhase.DAY_START
        await self._announce_day_start()

        self.game_state.phase = GamePhase.SPEECH
        await self._public_speeches()

        self.game_state.phase = GamePhase.VOTE
        await self._vote()

    async def _announce_day_start(self):
        if self.game_state.night_deaths:
            death_names = [f"玩家{p}" for p in self.game_state.night_deaths]
            print(f"昨晚死亡：{', '.join(death_names)}")
        else:
            print("昨晚是平安夜，无人死亡")

    async def _public_speeches(self):
        alive_players = self.game_state.get_alive_players()
        print(f"\n公开演讲开始，共 {len(alive_players)} 名存活玩家")
        self._log("log_event", f"公开演讲开始，{len(alive_players)} 名存活玩家")

        for player in alive_players:
            if player.agent:
                game_state = self.game_state.get_player_private_context(player.player_id)
                decision = await player.agent.decide_speech(game_state)
                content = decision.get("content", "")
                print(f"\n{player.name} 发言：")
                print(content)
                self._log("log_speech", f"{player.name}: {content[:100]}...")
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "公开演讲",
                    "player_id": player.player_id,
                    "player_name": player.name,
                    "role": player.role.name,
                    "action": "speech",
                    "content": content,
                })

    async def _vote(self):
        alive_players = self.game_state.get_alive_players()
        votes = {}
        self._log("log_event", "投票阶段开始")

        for player in alive_players:
            if player.agent:
                game_state = self.game_state.get_player_private_context(player.player_id)
                decision = await player.agent.decide_vote(game_state)
                target = decision.get("target")
                if target is not None and self.game_state.get_player(target) and self.game_state.get_player(target).is_alive:
                    votes[player.player_id] = target
                    self.game_state.add_vote(player.player_id, target)
                    self._log("log_vote", f"玩家{player.player_id} 投票给 玩家{target}")
                    self.game_state.dialogues.append({
                        "day": self.game_state.day_number,
                        "phase": "投票",
                        "player_id": player.player_id,
                        "player_name": player.name,
                        "role": player.role.name,
                        "action": "vote",
                        "target": target,
                    })
                elif target is not None:
                    self._log("log_event", f"玩家{player.player_id} 投票给已出局玩家{target}，投票无效")

        vote_count = {}
        for target in votes.values():
            vote_count[target] = vote_count.get(target, 0) + 1

        if vote_count:
            max_votes = max(vote_count.values())
            eliminated = [p for p, c in vote_count.items() if c == max_votes]

            if len(eliminated) == 1:
                player = self.game_state.get_player(eliminated[0])
                print(f"\n玩家 {eliminated[0]} ({player.name}) 被投票出局")
                player.kill("vote", self.game_state.to_dict())
                self._log("log_death", f"玩家{eliminated[0]}({player.name}) 被投票出局")
                self.death_records.append({
                    "player_id": eliminated[0],
                    "player_name": player.name,
                    "role": player.role.name,
                    "cause": "vote",
                    "day": self.game_state.day_number,
                })
                await self._handle_hunter_death([eliminated[0]])
            else:
                print(f"\n平票，进入PK：{eliminated}")
                self._log("log_event", f"平票，进入PK：{eliminated}")

        self.game_state.reset_vote_record()

    async def _end_game(self):
        winner = self.game_state.get_winner()
        print(f"\n{'='*50}")
        print("游戏结束！")
        print(f"胜利方：{'善良阵营' if winner == 'good' else '邪恶阵营'}")
        print(f"{'='*50}")

        self._is_running = False

        if not self._summaries_done:
            await self._run_summaries()
            self._summaries_done = True

    async def _run_summaries(self):
        winner = self.game_state.get_winner()
        print(f"\n{'='*30} 玩家总结 {'='*30}")
        self._log("info", "=== 开始生成玩家总结 ===")

        for player in self.game_state.players:
            if not player.agent:
                continue

            player_context = self.game_state.get_player_private_context(player.player_id)
            dialogues = player_context.get("dialogues", [])

            history_lines = []
            for d in dialogues:
                phase = d.get("phase", "")
                action = d.get("action", "")
                content = d.get("content", "")
                target = d.get("target")

                if action == "night_kill":
                    history_lines.append(f"[夜晚] 你投票击杀玩家{target}（{d.get('reasoning', '')}）")
                elif action == "seer_check":
                    result = "狼人" if d.get("result") == "wolf" else "好人"
                    history_lines.append(f"[夜晚] 你查验玩家{target}，结果：{result}")
                elif action == "heal":
                    history_lines.append(f"[夜晚] 你使用解药救活了玩家{target}")
                elif action == "poison":
                    history_lines.append(f"[夜晚] 你使用毒药毒杀了玩家{target}")
                elif action == "speech":
                    history_lines.append(f"[白天] 你发言：{content[:100]}")
                elif action == "vote":
                    history_lines.append(f"[白天] 你投票给玩家{target}")
                elif action == "hunter_shot":
                    history_lines.append(f"[夜晚] 你开枪带走了玩家{target}")

            for death in self.death_records:
                if death["player_id"] == player.player_id:
                    cause_map = {"night_kill": "被狼人杀害", "poison": "被毒杀", "vote": "被投票出局", "shoot": "被枪杀"}
                    history_lines.append(f"[死亡] 你在第{death['day']}天{cause_map.get(death['cause'], death['cause'])}")

            personal_history = "\n".join(history_lines) if history_lines else "无记录"

            summary_data = await self._summary_agent.generate_summary(
                player_name=player.name,
                role_name=player.role.name,
                camp=player.camp.value,
                winner=winner,
                personal_history=personal_history,
            )

            role_type = player.role.role_type.value
            experience = {
                "game_id": self.game_id,
                "player_id": player.player_id,
                "player_name": player.name,
                "camp": player.camp.value,
                "winner": winner,
                "is_winner": player.camp.value == winner,
                **summary_data,
            }
            save_experience(role_type, experience)

            self.summaries.append({
                "player_id": player.player_id,
                "player_name": player.name,
                "role": player.role.name,
                "camp": player.camp.value,
                "role_type": role_type,
                "is_winner": player.camp.value == winner,
                **summary_data,
            })

            print(f"  {player.name}({player.role.name}) 总结已保存")
            self._log("info", f"玩家{player.name} 的总结经验已保存")

        print(f"{'='*30} 总结完成 {'='*30}")
        self._log("info", "=== 所有玩家总结完成 ===")

    def _count_vote(self, targets: List[int]) -> int:
        from collections import Counter
        count = Counter(targets)
        return count.most_common(1)[0][0]

    def stop(self):
        self._is_running = False


async def create_game(player_names: List[str], role_assignment: Dict[int, str]) -> GameEngine:
    engine = GameEngine(player_names)
    await engine.initialize(role_assignment)
    return engine


ROLE_CONFIGS = {
    "standard_6": {
        "name": "标准6人局",
        "description": "2狼、1预言家、1女巫、1猎人、1村民",
        "roles": {
            0: "werewolf",
            1: "werewolf",
            2: "seer",
            3: "witch",
            4: "hunter",
            5: "villager",
        }
    },
    "simple_4": {
        "name": "简易4人局",
        "description": "1狼、1预言家、1女巫、1村民",
        "roles": {
            0: "werewolf",
            1: "seer",
            2: "witch",
            3: "villager",
        }
    },
    "big_9": {
        "name": "标准9人局",
        "description": "3狼、1预言家、1女巫、1猎人、2村民、1白痴",
        "roles": {
            0: "werewolf",
            1: "werewolf",
            2: "werewolf",
            3: "seer",
            4: "witch",
            5: "hunter",
            6: "villager",
            7: "villager",
            8: "villager",
        }
    },
}


def get_role_config(config_name: str) -> Dict[int, str]:
    if config_name in ROLE_CONFIGS:
        return ROLE_CONFIGS[config_name]["roles"].copy()
    else:
        raise ValueError(f"Unknown config: {config_name}. Available: {list(ROLE_CONFIGS.keys())}")


def shuffle_roles(role_assignment: Dict[int, str]) -> Dict[int, str]:
    import random
    roles = list(role_assignment.values())
    random.shuffle(roles)
    return {i: r for i, r in enumerate(roles)}


def create_random_roles(num_players: int, wolf_ratio: float = 0.3) -> Dict[int, str]:
    import random

    num_wolves = max(1, int(num_players * wolf_ratio))
    num_gods = max(1, num_players // 6)
    num_villagers = num_players - num_wolves - num_gods

    roles = (
        ["werewolf"] * num_wolves +
        ["seer", "witch", "hunter"][:num_gods] +
        ["villager"] * num_villagers
    )

    if "werewolf" not in roles:
        roles[0] = "werewolf"
    if not any(r in roles for r in ["seer", "witch", "hunter"]):
        roles[1] = "seer"

    random.shuffle(roles)
    return {i: r for i, r in enumerate(roles)}


async def run_game(player_names: List[str] = None, config_name: str = "standard_6", shuffle: bool = True):
    if player_names is None:
        config = ROLE_CONFIGS.get(config_name, ROLE_CONFIGS["standard_6"])
        player_names = [f"玩家{i+1}" for i in range(len(config["roles"]))]

    role_assignment = get_role_config(config_name)

    if shuffle:
        role_assignment = shuffle_roles(role_assignment)

    print(f"使用配置：{ROLE_CONFIGS[config_name]['name']}")
    print(f"角色分配：{role_assignment}")

    game = await create_game(player_names, role_assignment)
    await game.start()


if __name__ == "__main__":
    asyncio.run(run_game())