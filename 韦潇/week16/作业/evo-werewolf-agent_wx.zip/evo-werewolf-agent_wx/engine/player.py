from typing import Optional, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Player:
    def __init__(self, player_id: int, role: BaseRole, name: str):
        self.player_id = player_id
        self.role = role
        self.name = name
        self.agent = None
        self._is_alive = True

    @property
    def is_alive(self) -> bool:
        return self._is_alive and self.role.is_alive

    @is_alive.setter
    def is_alive(self, value: bool):
        self._is_alive = value
        self.role.is_alive = value

    @property
    def role_type(self) -> RoleType:
        return self.role.role_type

    @property
    def camp(self) -> Camp:
        return self.role.camp

    @property
    def is_sheriff(self) -> bool:
        return self.role.is_sheriff

    def kill(self, cause: str, game_state: Dict[str, Any]):
        self._is_alive = False
        self.role.on_death(cause, game_state)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "player_id": self.player_id,
            "name": self.name,
            "role": self.role.name,
            "role_type": self.role.role_type.value,
            "camp": self.role.camp.value,
            "is_alive": self.is_alive,
            "is_sheriff": self.is_sheriff,
        }

    def __repr__(self) -> str:
        return f"Player(id={self.player_id}, name={self.name}, role={self.role.name}, alive={self.is_alive})"