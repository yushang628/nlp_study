import json
import os
from typing import Dict, Any, List


def save_experience(role_type: str, experience: Dict[str, Any]):
    os.makedirs("memory/experiences", exist_ok=True)
    file_path = os.path.join("memory/experiences", f"{role_type}.json")
    
    experiences = []
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            experiences = json.load(f)
    
    experiences.append(experience)
    
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(experiences, f, ensure_ascii=False, indent=2)


def load_experiences(role_type: str) -> List[Dict[str, Any]]:
    file_path = os.path.join("memory/experiences", f"{role_type}.json")
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def get_experience_prompt(role_type: str) -> str:
    experiences = load_experiences(role_type)
    if not experiences:
        return ""
    
    recent_experiences = experiences[-5:]
    lessons = []
    
    for exp in recent_experiences:
        if exp.get("is_winner"):
            lessons.append(f"- 胜利经验: {exp.get('strategies', '')}")
        else:
            lessons.append(f"- 失败教训: {exp.get('mistakes', '')}")
    
    if lessons:
        return f"\n\n## 过往经验参考\n{'\n'.join(lessons)}"
    return ""