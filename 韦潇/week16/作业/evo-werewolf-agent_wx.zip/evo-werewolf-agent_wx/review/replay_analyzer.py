from typing import Dict, Any, List
import json
import os


class ReplayAnalyzer:
    def __init__(self):
        self.game_data = {}

    def load_game(self, game_id: str, log_dir: str = "logs") -> bool:
        file_path = os.path.join(log_dir, f"{game_id}.json")
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                self.game_data = json.load(f)
            return True
        return False

    def analyze_game(self) -> Dict[str, Any]:
        if not self.game_data:
            return {}

        analysis = {
            "game_id": self.game_data.get("game_id"),
            "winner": self.game_data.get("winner"),
            "config": self.game_data.get("config_name"),
            "replay_summary": self._generate_summary(),
            "turn_by_turn": self._generate_turn_by_turn(),
            "player_analysis": self._analyze_players(),
            "key_decisions": self._identify_key_decisions(),
            "winning_factors": self._analyze_winning_factors(),
            "suggestions": self._generate_suggestions(),
        }
        return analysis

    def _generate_summary(self) -> str:
        winner = self.game_data.get("winner")
        deaths = self.game_data.get("deaths", [])
        dialogues = self.game_data.get("dialogues", [])
        
        lines = []
        lines.append(f"游戏结果: {'善良阵营胜利' if winner == 'good' else '邪恶阵营胜利'}")
        lines.append(f"死亡人数: {len(deaths)}")
        lines.append(f"总对话数: {len(dialogues)}")
        
        return "\n".join(lines)

    def _generate_turn_by_turn(self) -> List[Dict[str, Any]]:
        dialogues = self.game_data.get("dialogues", [])
        turns = []
        
        current_day = None
        current_turn = {}
        
        for d in dialogues:
            day = d.get("day")
            phase = d.get("phase")
            
            if day != current_day:
                if current_turn:
                    turns.append(current_turn)
                current_day = day
                current_turn = {"day": day, "events": []}
            
            current_turn["events"].append({
                "phase": phase,
                "player": d.get("player_name"),
                "action": d.get("action"),
                "target": d.get("target"),
                "content": d.get("content"),
            })
        
        if current_turn:
            turns.append(current_turn)
        
        return turns

    def _analyze_players(self) -> Dict[str, Any]:
        players = self.game_data.get("players", [])
        dialogues = self.game_data.get("dialogues", [])
        deaths = self.game_data.get("deaths", [])
        winner = self.game_data.get("winner")
        
        analysis = {}
        for player in players:
            pid = player.get("player_id")
            name = player.get("name")
            role = player.get("role")
            camp = player.get("camp")
            
            player_dialogues = [d for d in dialogues if d.get("player_id") == pid]
            speech_count = len([d for d in player_dialogues if d.get("action") == "speech"])
            vote_count = len([d for d in player_dialogues if d.get("action") == "vote"])
            
            death = next((d for d in deaths if d.get("player_id") == pid), None)
            
            analysis[name] = {
                "role": role,
                "camp": camp,
                "is_winner": camp == winner,
                "speeches": speech_count,
                "votes": vote_count,
                "survived": not death,
                "death_day": death.get("day") if death else None,
                "death_cause": death.get("cause") if death else None,
            }
        
        return analysis

    def _identify_key_decisions(self) -> List[Dict[str, Any]]:
        dialogues = self.game_data.get("dialogues", [])
        deaths = self.game_data.get("deaths", [])
        players = self.game_data.get("players", [])
        
        wolf_ids = {p["player_id"] for p in players if p.get("role_type") == "werewolf"}
        god_ids = {p["player_id"] for p in players if p.get("role_type") in ["seer", "witch", "hunter"]}
        
        key_decisions = []
        
        for death in deaths:
            pid = death.get("player_id")
            cause = death.get("cause")
            day = death.get("day")
            
            if pid in wolf_ids:
                key_decisions.append({
                    "day": day,
                    "type": "wolf_eliminated",
                    "description": f"狼人被投票出局",
                    "significance": "高 - 直接削弱狼队力量",
                })
            elif pid in god_ids:
                key_decisions.append({
                    "day": day,
                    "type": "god_eliminated",
                    "description": f"神职被淘汰",
                    "significance": "高 - 削弱好人阵营能力",
                })
        
        witch_actions = [d for d in dialogues if d.get("action") in ("heal", "poison")]
        for action in witch_actions:
            key_decisions.append({
                "day": action.get("day"),
                "type": "witch_action",
                "description": f"女巫使用{action.get('action')}",
                "significance": "中 - 可能改变游戏走向",
            })
        
        return key_decisions

    def _analyze_winning_factors(self) -> List[str]:
        winner = self.game_data.get("winner")
        dialogues = self.game_data.get("dialogues", [])
        deaths = self.game_data.get("deaths", [])
        players = self.game_data.get("players", [])
        
        factors = []
        
        wolf_ids = {p["player_id"] for p in players if p.get("role_type") == "werewolf"}
        god_ids = {p["player_id"] for p in players if p.get("role_type") in ["seer", "witch", "hunter"]}
        
        wolf_deaths = [d for d in deaths if d.get("player_id") in wolf_ids]
        god_deaths = [d for d in deaths if d.get("player_id") in god_ids]
        
        if winner == "good":
            if len(wolf_deaths) == len(wolf_ids):
                factors.append("成功找出并淘汰了所有狼人")
            
            seer_checks = [d for d in dialogues if d.get("action") == "seer_check"]
            if seer_checks:
                factors.append("预言家成功查验并揭露了狼人身份")
            
            poison_actions = [d for d in dialogues if d.get("action") == "poison"]
            if any(p.get("target") in wolf_ids for p in poison_actions):
                factors.append("女巫使用毒药成功毒杀狼人")
        else:
            if len(god_deaths) >= len(god_ids) // 2:
                factors.append("狼人成功击杀多名神职")
            
            votes = [d for d in dialogues if d.get("action") == "vote"]
            wolf_votes = [v for v in votes if v.get("player_id") in wolf_ids]
            if wolf_votes:
                factors.append("狼人成功误导好人阵营投票")
        
        return factors

    def _generate_suggestions(self) -> List[str]:
        winner = self.game_data.get("winner")
        dialogues = self.game_data.get("dialogues", [])
        
        suggestions = []
        
        speeches = [d for d in dialogues if d.get("action") == "speech"]
        if len(speeches) < 3 * len(self.game_data.get("players", [])):
            suggestions.append("建议增加发言次数，提供更多信息供队友分析")
        
        votes = [d for d in dialogues if d.get("action") == "vote"]
        if len(votes) < len(self.game_data.get("players", [])):
            suggestions.append("建议提高投票参与率，确保每次投票都参与")
        
        if winner == "evil":
            suggestions.append("好人阵营需要更好地协作，识别狼人策略")
        else:
            suggestions.append("狼人需要改进伪装策略，避免被预言家查验")
        
        return suggestions

    def save_analysis(self, output_dir: str = "logs"):
        analysis = self.analyze_game()
        if analysis:
            file_path = os.path.join(output_dir, f"analysis_{analysis['game_id']}.json")
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(analysis, f, ensure_ascii=False, indent=2)

    def generate_report(self) -> str:
        analysis = self.analyze_game()
        if not analysis:
            return "无法生成报告：没有游戏数据"
        
        lines = ["=" * 60, "狼人杀游戏复盘报告", "=" * 60]
        
        lines.append(f"\n一、游戏概览")
        lines.append(f"游戏ID: {analysis['game_id']}")
        lines.append(f"配置: {analysis['config']}")
        lines.append(f"结果: {'善良阵营胜利' if analysis['winner'] == 'good' else '邪恶阵营胜利'}")
        
        lines.append(f"\n二、胜负关键因素")
        for i, factor in enumerate(analysis['winning_factors'], 1):
            lines.append(f"  {i}. {factor}")
        
        lines.append(f"\n三、关键决策")
        for decision in analysis['key_decisions']:
            lines.append(f"  [第{decision['day']}天] {decision['description']} ({decision['significance']})")
        
        lines.append(f"\n四、玩家表现")
        for name, data in analysis['player_analysis'].items():
            status = "存活" if data['survived'] else f"第{data['death_day']}天{data['death_cause']}"
            lines.append(f"  {name}({data['role']}): {status} | 发言{data['speeches']}次 | 投票{data['votes']}次")
        
        lines.append(f"\n五、改进建议")
        for i, suggestion in enumerate(analysis['suggestions'], 1):
            lines.append(f"  {i}. {suggestion}")
        
        return "\n".join(lines)