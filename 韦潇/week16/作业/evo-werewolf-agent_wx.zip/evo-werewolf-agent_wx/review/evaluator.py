from typing import Dict, Any, List, Optional
import json
import os
from datetime import datetime


class GameEvaluator:
    def __init__(self):
        self.metrics = {}

    def evaluate_game(self, game_data: Dict[str, Any]) -> Dict[str, Any]:
        results = {
            "game_id": game_data.get("game_id"),
            "winner": game_data.get("winner"),
            "duration": self._calculate_duration(game_data),
            "turns": self._count_turns(game_data),
            "player_performance": self._evaluate_players(game_data),
            "strategy_effectiveness": self._evaluate_strategy(game_data),
            "speech_analysis": self._analyze_speeches(game_data),
            "vote_accuracy": self._calculate_vote_accuracy(game_data),
            "key_moments": self._identify_key_moments(game_data),
        }
        return results

    def _calculate_duration(self, game_data: Dict[str, Any]) -> int:
        start = game_data.get("start_time")
        end = game_data.get("end_time")
        if start and end:
            try:
                start_dt = datetime.fromisoformat(start)
                end_dt = datetime.fromisoformat(end)
                return int((end_dt - start_dt).total_seconds())
            except:
                return 0
        return 0

    def _count_turns(self, game_data: Dict[str, Any]) -> int:
        dialogues = game_data.get("dialogues", [])
        days = set()
        for d in dialogues:
            day = d.get("day")
            if day:
                days.add(day)
        return len(days)

    def _evaluate_players(self, game_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        players = game_data.get("players", [])
        dialogues = game_data.get("dialogues", [])
        deaths = game_data.get("deaths", [])
        winner = game_data.get("winner")
        
        results = []
        for player in players:
            pid = player.get("player_id")
            role = player.get("role")
            camp = player.get("camp")
            is_winner = camp == winner
            
            player_dialogues = [d for d in dialogues if d.get("player_id") == pid]
            speeches = [d for d in player_dialogues if d.get("action") == "speech"]
            votes = [d for d in player_dialogues if d.get("action") == "vote"]
            
            death = next((d for d in deaths if d.get("player_id") == pid), None)
            
            results.append({
                "player_id": pid,
                "name": player.get("name"),
                "role": role,
                "camp": camp,
                "is_winner": is_winner,
                "speech_count": len(speeches),
                "vote_count": len(votes),
                "survived": not death,
                "death_day": death.get("day") if death else None,
                "death_cause": death.get("cause") if death else None,
            })
        return results

    def _evaluate_strategy(self, game_data: Dict[str, Any]) -> Dict[str, Any]:
        dialogues = game_data.get("dialogues", [])
        winner = game_data.get("winner")
        
        wolf_actions = [d for d in dialogues if d.get("action") == "night_kill"]
        seer_checks = [d for d in dialogues if d.get("action") == "seer_check"]
        witch_actions = [d for d in dialogues if d.get("action") in ("heal", "poison")]
        votes = [d for d in dialogues if d.get("action") == "vote"]
        
        return {
            "wolf_kills": len(wolf_actions),
            "seer_checks": len(seer_checks),
            "witch_actions": len(witch_actions),
            "total_votes": len(votes),
            "winning_camp": winner,
        }

    def _analyze_speeches(self, game_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        dialogues = game_data.get("dialogues", [])
        speeches = [d for d in dialogues if d.get("action") == "speech"]
        
        results = []
        for speech in speeches:
            content = speech.get("content", "")
            results.append({
                "player_id": speech.get("player_id"),
                "player_name": speech.get("player_name"),
                "day": speech.get("day"),
                "length": len(content),
                "has_accusation": any(word in content for word in ["狼", "怀疑", "投", "查杀"]),
                "has_defense": any(word in content for word in ["好人", "清白", "不是狼", "平民"]),
                "has_analysis": any(word in content for word in ["分析", "逻辑", "推理", "判断"]),
            })
        return results

    def _calculate_vote_accuracy(self, game_data: Dict[str, Any]) -> Dict[str, Any]:
        dialogues = game_data.get("dialogues", [])
        players = game_data.get("players", [])
        
        wolf_ids = {p["player_id"] for p in players if p.get("role_type") == "werewolf"}
        votes = [d for d in dialogues if d.get("action") == "vote"]
        
        good_voters = [v for v in votes if v.get("player_id") not in wolf_ids]
        evil_voters = [v for v in votes if v.get("player_id") in wolf_ids]
        
        good_voted_wolf = sum(1 for v in good_voters if v.get("target") in wolf_ids)
        evil_voted_good = sum(1 for v in evil_voters if v.get("target") not in wolf_ids)
        
        return {
            "total_votes": len(votes),
            "good_vote_accuracy": good_voted_wolf / len(good_voters) if good_voters else 0,
            "evil_vote_accuracy": evil_voted_good / len(evil_voters) if evil_voters else 0,
        }

    def _identify_key_moments(self, game_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        dialogues = game_data.get("dialogues", [])
        deaths = game_data.get("deaths", [])
        players = game_data.get("players", [])
        
        wolf_ids = {p["player_id"] for p in players if p.get("role_type") == "werewolf"}
        god_ids = {p["player_id"] for p in players if p.get("role_type") in ["seer", "witch", "hunter"]}
        
        key_moments = []
        
        for death in deaths:
            pid = death.get("player_id")
            cause = death.get("cause")
            day = death.get("day")
            
            if pid in wolf_ids:
                key_moments.append({
                    "day": day,
                    "type": "wolf_eliminated",
                    "description": f"狼人被淘汰",
                    "impact": "high",
                })
            elif pid in god_ids:
                key_moments.append({
                    "day": day,
                    "type": "god_eliminated",
                    "description": f"神职被淘汰",
                    "impact": "high",
                })
        
        return key_moments

    def save_evaluation(self, evaluation: Dict[str, Any], output_dir: str = "logs"):
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"evaluation_{evaluation['game_id']}.json")
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(evaluation, f, ensure_ascii=False, indent=2)


class PlayerRating:
    def __init__(self):
        self.ratings = {}

    def update_rating(self, player_id: int, role: str, performance: Dict[str, Any]):
        if player_id not in self.ratings:
            self.ratings[player_id] = {
                "total_games": 0,
                "wins": 0,
                "roles_played": {},
                "average_score": 0,
            }
        
        self.ratings[player_id]["total_games"] += 1
        if performance.get("is_winner"):
            self.ratings[player_id]["wins"] += 1
        
        if role not in self.ratings[player_id]["roles_played"]:
            self.ratings[player_id]["roles_played"][role] = {"games": 0, "wins": 0}
        self.ratings[player_id]["roles_played"][role]["games"] += 1
        if performance.get("is_winner"):
            self.ratings[player_id]["roles_played"][role]["wins"] += 1

    def get_player_rating(self, player_id: int) -> Optional[Dict[str, Any]]:
        return self.ratings.get(player_id)

    def save_ratings(self, file_path: str = "memory/player_ratings.json"):
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(self.ratings, f, ensure_ascii=False, indent=2)