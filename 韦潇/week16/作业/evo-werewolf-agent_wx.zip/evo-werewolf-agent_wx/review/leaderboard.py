from typing import Dict, Any, List
import json
import os


class LeaderboardEntry:
    def __init__(self, name: str, wins: int, games: int, roles: Dict[str, Dict[str, int]]):
        self.name = name
        self.wins = wins
        self.games = games
        self.roles = roles
    
    @property
    def win_rate(self) -> float:
        return self.wins / self.games if self.games > 0 else 0.0


class Leaderboard:
    def __init__(self):
        self.entries: Dict[str, LeaderboardEntry] = {}
        self.load()

    def add_game_result(self, players: List[Dict[str, Any]], winner: str):
        for player in players:
            name = player.get("name", f"Player_{player.get('player_id')}")
            role = player.get("role")
            camp = player.get("camp")
            is_winner = camp == winner
            
            if name not in self.entries:
                self.entries[name] = LeaderboardEntry(name, 0, 0, {})
            
            entry = self.entries[name]
            entry.games += 1
            if is_winner:
                entry.wins += 1
            
            if role not in entry.roles:
                entry.roles[role] = {"wins": 0, "games": 0}
            entry.roles[role]["games"] += 1
            if is_winner:
                entry.roles[role]["wins"] += 1
        
        self.save()

    def get_ranking(self) -> List[LeaderboardEntry]:
        return sorted(self.entries.values(), key=lambda x: (-x.win_rate, -x.wins))

    def get_top_n(self, n: int = 10) -> List[LeaderboardEntry]:
        return self.get_ranking()[:n]

    def get_player_stats(self, name: str) -> Dict[str, Any]:
        entry = self.entries.get(name)
        if not entry:
            return {}
        
        role_stats = {}
        for role, stats in entry.roles.items():
            role_stats[role] = {
                "games": stats["games"],
                "wins": stats["wins"],
                "win_rate": stats["wins"] / stats["games"] if stats["games"] > 0 else 0.0,
            }
        
        return {
            "name": entry.name,
            "total_games": entry.games,
            "total_wins": entry.wins,
            "overall_win_rate": entry.win_rate,
            "role_stats": role_stats,
        }

    def get_role_leaderboard(self, role: str) -> List[Dict[str, Any]]:
        results = []
        for entry in self.entries.values():
            if role in entry.roles:
                stats = entry.roles[role]
                results.append({
                    "name": entry.name,
                    "games": stats["games"],
                    "wins": stats["wins"],
                    "win_rate": stats["wins"] / stats["games"],
                })
        return sorted(results, key=lambda x: (-x["win_rate"], -x["wins"]))

    def get_global_stats(self) -> Dict[str, Any]:
        total_games = sum(e.games for e in self.entries.values())
        total_wins = sum(e.wins for e in self.entries.values())
        
        role_distribution = {}
        for entry in self.entries.values():
            for role, stats in entry.roles.items():
                if role not in role_distribution:
                    role_distribution[role] = {"games": 0, "wins": 0}
                role_distribution[role]["games"] += stats["games"]
                role_distribution[role]["wins"] += stats["wins"]
        
        return {
            "total_players": len(self.entries),
            "total_games": total_games,
            "total_wins": total_wins,
            "role_distribution": role_distribution,
        }

    def save(self, file_path: str = "memory/leaderboard.json"):
        data = {
            name: {
                "wins": entry.wins,
                "games": entry.games,
                "roles": entry.roles,
            }
            for name, entry in self.entries.items()
        }
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load(self, file_path: str = "memory/leaderboard.json"):
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for name, entry_data in data.items():
                    self.entries[name] = LeaderboardEntry(
                        name=name,
                        wins=entry_data["wins"],
                        games=entry_data["games"],
                        roles=entry_data["roles"],
                    )

    def generate_report(self) -> str:
        ranking = self.get_ranking()
        global_stats = self.get_global_stats()
        
        lines = ["=" * 60, "狼人杀排行榜", "=" * 60]
        
        lines.append(f"\n一、全局统计")
        lines.append(f"总玩家数: {global_stats['total_players']}")
        lines.append(f"总局数: {global_stats['total_games']}")
        
        lines.append(f"\n二、玩家排名")
        lines.append(f"{'排名':^6} | {'玩家':^10} | {'胜场':^6} | {'总场':^6} | {'胜率':^8}")
        lines.append("-" * 50)
        
        for i, entry in enumerate(ranking[:10], 1):
            lines.append(f"{i:^6} | {entry.name:^10} | {entry.wins:^6} | {entry.games:^6} | {entry.win_rate:^8.1%}")
        
        lines.append(f"\n三、各角色胜率")
        for role, stats in global_stats["role_distribution"].items():
            rate = stats["wins"] / stats["games"] if stats["games"] > 0 else 0.0
            lines.append(f"  {role}: 胜率 {rate:.1%} ({stats['wins']}/{stats['games']})")
        
        return "\n".join(lines)