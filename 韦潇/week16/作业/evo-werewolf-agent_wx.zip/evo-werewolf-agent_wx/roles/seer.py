from typing import Optional, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Seer(BaseRole):
    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._check_result = None

    @property
    def role_type(self) -> RoleType:
        return RoleType.SEER

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    def is_night_actionable(self) -> bool:
        return self._is_alive

    def get_private_context(self) -> Dict[str, Any]:
        ctx = super().get_private_context()
        ctx["note"] = "You are the Seer. You can check one player each night to see if they are a wolf."
        ctx["check_result"] = self._check_result
        return ctx

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        players = game_state.get("players", [])
        alive_wolves = [p for p in players if p.get("role") == RoleType.WEREWOLF.value and p.get("is_alive")]
        return len(alive_wolves) == 0