from typing import Optional, List, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Hunter(BaseRole):
    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._can_shoot = True

    @property
    def role_type(self) -> RoleType:
        return RoleType.HUNTER

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    @property
    def can_shoot(self) -> bool:
        return self._can_shoot

    def lock_shoot(self):
        self._can_shoot = False

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        self._is_alive = False
        if cause == "poison":
            self._can_shoot = False
            return None
        if cause in ("night_kill", "vote") and self._can_shoot:
            return []
        return None

    def get_private_context(self) -> Dict[str, Any]:
        ctx = super().get_private_context()
        ctx.update({
            "can_shoot": self._can_shoot,
            "note": "You are the Hunter. When you die (unless poisoned), you can shoot one player."
        })
        return ctx

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        players = game_state.get("players", [])
        alive_wolves = [p for p in players if p.get("role") == RoleType.WEREWOLF.value and p.get("is_alive")]
        return len(alive_wolves) == 0