from typing import Optional, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Werewolf(BaseRole):
    @property
    def role_type(self) -> RoleType:
        return RoleType.WEREWOLF

    @property
    def camp(self) -> Camp:
        return Camp.EVIL

    def is_night_actionable(self) -> bool:
        return self._is_alive

    def get_private_context(self) -> Dict[str, Any]:
        ctx = super().get_private_context()
        ctx["knows_wolves"] = True
        ctx["note"] = "You are a Werewolf. You know your wolf teammates but not others' roles."
        return ctx

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        players = game_state.get("players", [])
        alive_gods = [p for p in players if p.get("is_god") and p.get("is_alive")]
        alive_villagers = [p for p in players if not p.get("is_god") and p.get("is_alive")]
        alive_wolves = [p for p in players if p.get("role") == RoleType.WEREWOLF.value and p.get("is_alive")]
        if not alive_wolves:
            return False
        return len(alive_gods) == 0 or len(alive_villagers) == 0