from typing import Optional, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Witch(BaseRole):
    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._has_heal = True
        self._has_poison = True
        self._used_heal = False
        self._used_poison = False

    @property
    def role_type(self) -> RoleType:
        return RoleType.WITCH

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    @property
    def has_heal(self) -> bool:
        return self._has_heal and not self._used_heal

    @property
    def has_poison(self) -> bool:
        return self._has_poison and not self._used_poison

    def is_night_actionable(self) -> bool:
        return self._is_alive and (self.has_heal or self.has_poison)

    def use_heal(self):
        self._used_heal = True

    def use_poison(self):
        self._used_poison = True

    def get_private_context(self) -> Dict[str, Any]:
        ctx = super().get_private_context()
        ctx.update({
            "has_heal": self.has_heal,
            "has_poison": self.has_poison,
            "note": "You are the Witch. You have one heal and one poison. Heal saves tonight's death. Poison kills any player."
        })
        return ctx

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        players = game_state.get("players", [])
        alive_wolves = [p for p in players if p.get("role") == RoleType.WEREWOLF.value and p.get("is_alive")]
        return len(alive_wolves) == 0