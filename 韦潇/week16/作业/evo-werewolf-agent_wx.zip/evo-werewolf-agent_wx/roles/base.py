from enum import Enum
from typing import Optional, List, Dict, Any


class RoleType(Enum):
    WEREWOLF = "werewolf"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    VILLAGER = "villager"


class Camp(Enum):
    GOOD = "good"
    EVIL = "evil"


class BaseRole:
    def __init__(self, player_id: int):
        self.player_id = player_id
        self._is_alive = True
        self._is_sheriff = False

    @property
    def role_type(self) -> RoleType:
        raise NotImplementedError

    @property
    def camp(self) -> Camp:
        raise NotImplementedError

    @property
    def name(self) -> str:
        return self.role_type.value.capitalize()

    @property
    def is_alive(self) -> bool:
        return self._is_alive

    @is_alive.setter
    def is_alive(self, value: bool):
        self._is_alive = value

    @property
    def is_sheriff(self) -> bool:
        return self._is_sheriff

    @is_sheriff.setter
    def is_sheriff(self, value: bool):
        self._is_sheriff = value

    def is_night_actionable(self) -> bool:
        return False

    def get_private_context(self) -> Dict[str, Any]:
        return {
            "role": self.name,
            "player_id": self.player_id,
            "camp": self.camp.value,
        }

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[List[int]]:
        self._is_alive = False
        return None

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        raise NotImplementedError

    def __repr__(self) -> str:
        status = "alive" if self._is_alive else "dead"
        sheriff = " (sheriff)" if self._is_sheriff else ""
        return f"{self.__class__.__name__}(player_id={self.player_id}, {status}{sheriff})"