import json
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class GameRecord(BaseModel):
    game_id: str
    start_time: str
    end_time: str = ""
    config_name: str = ""
    role_assignment: Dict[int, str] = Field(default_factory=dict)
    player_styles: Dict[int, str] = Field(default_factory=dict)
    winner: Optional[str] = None
    dialogues: List[Dict[str, Any]] = Field(default_factory=list)
    deaths: List[Dict[str, Any]] = Field(default_factory=list)

    def add_dialogue(self, dialogue: Dict[str, Any]):
        self.dialogues.append(dialogue)

    def add_dialogue_from_dict(self, dialogue: Dict[str, Any]):
        self.dialogues.append(dialogue)

    def add_death(self, player_id: int, player_name: str, role: str, cause: str, day: int):
        self.deaths.append({
            "player_id": player_id,
            "player_name": player_name,
            "role": role,
            "cause": cause,
            "day": day,
        })

    def summary(self) -> str:
        lines = [
            "=" * 50,
            "游戏记录摘要",
            "=" * 50,
            f"游戏ID: {self.game_id}",
            f"开始时间: {self.start_time}",
            f"结束时间: {self.end_time}",
            f"配置: {self.config_name}",
            f"胜利方: {'善良阵营' if self.winner == 'good' else '邪恶阵营' if self.winner else '未结束'}",
            "",
            "角色分配:",
        ]
        for pid, role in self.role_assignment.items():
            lines.append(f"  玩家{pid}: {role}")
        lines.append("")
        lines.append("死亡记录:")
        for death in self.deaths:
            lines.append(f"  第{death['day']}天: {death['player_name']}({death['role']}) - {death['cause']}")
        return "\n".join(lines)

    def save(self, output_dir: str = "logs"):
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, f"{self.game_id}.json")
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(self.model_dump(), f, ensure_ascii=False, indent=2)