import json
import os
from typing import Dict, Any


def load_system_config(config_path: str = "config/system_config.json") -> Dict[str, Any]:
    if os.path.exists(config_path):
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "default_model": "gpt-4",
        "api_key": "",
        "api_base": "",
        "max_tokens": 4096,
        "temperature": 0.7,
        "log_level": "INFO",
    }