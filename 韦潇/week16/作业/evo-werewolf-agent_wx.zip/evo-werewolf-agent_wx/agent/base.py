from typing import Dict, Any


class BaseAgent:
    def __init__(self):
        self.name = "BaseAgent"
    
    async def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        return {"action": "unknown", "reasoning": "No action implemented"}