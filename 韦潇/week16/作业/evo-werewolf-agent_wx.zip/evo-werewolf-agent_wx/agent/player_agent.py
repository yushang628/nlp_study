from typing import Dict, Any, List
import json
import re
import random


DECISION_STYLES = {
    "cautious": {
        "name": "谨慎型",
        "description": "宁可放过可疑玩家，也不轻易误杀好人",
        "speech_tendency": "保守分析，少说少错",
        "vote_tendency": "跟票，不首先提名",
        "night_tendency": "不轻易用药/查验",
    },
    "bold": {
        "name": "大胆型",
        "description": "敢于冒险，快速做出判断",
        "speech_tendency": "激进指控，主动带队",
        "vote_tendency": "果断投票，不怕误杀",
        "night_tendency": "冒险用药/深夜击杀",
    },
    "random": {
        "name": "随机型",
        "description": "不要过度分析，依靠直觉",
        "speech_tendency": "随机发言，看心情",
        "vote_tendency": "随机投票",
        "night_tendency": "随机目标",
    },
    "balanced": {
        "name": "平衡型",
        "description": "综合考虑各种因素",
        "speech_tendency": "客观分析",
        "vote_tendency": "理性分析后投票",
        "night_tendency": "合理使用能力",
    },
}


SPEECH_TEMPLATES = {
    "werewolf": {
        "cautious": [
            "我是一个普通村民，昨晚平安无事。目前局势还不明朗，建议大家先观察，不要盲目投票。",
            "昨夜死了人，但我没有任何信息。希望预言家能跳出来给点线索，我们好人要团结。",
            "我这边没有什么特别的信息，就一个平民。大家小心点，狼人肯定在我们中间。",
            "感觉今天气氛有点紧张啊，我先表个态，我是好人，希望大家不要乱投。",
        ],
        "bold": [
            "我怀疑玩家{target}！他刚才发言很奇怪，一直在转移话题，肯定有问题！",
            "昨晚死了{dead_count}个人，狼人刀很凶！我觉得玩家{target}嫌疑最大，先出他！",
            "预言家呢？再不出来就晚了！我怀疑这轮有狼在装好人，大家别被骗了！",
            "我是平民，但我敢肯定玩家{target}是狼，不信我们今天投他，看他出不出局！",
        ],
        "balanced": [
            "大家好，我是平民。昨晚死了人，说明狼人已经开始行动了。建议预言家尽快报查验，我们根据信息来投票。",
            "从目前的发言来看，我觉得玩家{target}的发言有点可疑，但还需要更多信息确认。",
            "我分析了一下局势，目前场上应该还有{wolf_count}只狼。大家要谨慎投票，别被狼带节奏。",
            "作为平民，我会根据预言家的查验结果来投票。希望神职都能好好发挥，我们好人一定能赢。",
        ],
        "random": [
            "今天天气不错啊，适合玩狼人杀。我是好人，你们看着办吧。",
            "我觉得吧，狼人可能长得比较帅/漂亮，大家注意观察一下。",
            "随便投一个吧，反正我是好人，投错了也没关系，下轮再投。",
            "月亮很圆，狼人应该会出来活动吧。我猜玩家{target}是狼！",
        ],
    },
    "seer": {
        "cautious": [
            "我是预言家。昨晚查验了玩家{target}，结果是好人。我会继续查验，希望大家保护我。",
            "预言家身份，昨晚查了玩家{target}，金水。今天先听大家发言，我们再决定投票。",
            "我是预言家，昨晚验了{target}是好人。目前局势还不明朗，大家别着急投票。",
        ],
        "bold": [
            "全场唯一真预言家！昨晚查验玩家{target}，查杀！今天全票出他！",
            "预言家在这里！昨晚验了玩家{target}是狼，铁狼无疑，赶紧投出去！",
            "我就是预言家，玩家{target}是查杀！谁跟我对跳谁就是狼，今天先出查杀！",
            "真预言家报到！昨晚查了玩家{target}是好人，今天重点关注玩家{suspicious}，他发言很怪！",
        ],
        "balanced": [
            "大家好，我是预言家。昨晚查验了玩家{target}，结果是{result}。我会把查验结果都告诉大家，帮助大家找出狼人。",
            "预言家身份确认。昨晚查了玩家{target}，{result}。接下来我会继续查验关键人物，希望大家配合。",
            "我是预言家，昨晚验了玩家{target}是{result}。今天我们先根据这个信息来分析，不要盲目跟风。",
        ],
        "random": [
            "我是预言家！昨晚查了...呃，忘了查谁了，反正有个人是狼！",
            "预言家在此！我昨晚看到月亮很圆，所以玩家{target}是好人！",
            "我是预言家，但我不告诉你们验了谁，你们自己猜吧！",
        ],
    },
    "witch": {
        "cautious": [
            "我是女巫，昨晚有人死了，但我选择不用药。希望大家理解，我要留着药救关键人物。",
            "女巫身份。昨晚没有用药，因为不确定情况。预言家可以跳出来，我会保护你。",
            "我是女巫，解药和毒药都还在。大家先发言，我根据情况决定用药。",
        ],
        "bold": [
            "女巫驾到！昨晚狼人刀了玩家{target}，我直接把他毒了！今天大家随便投，我有解药！",
            "我是女巫，昨晚救了人/没救人，今晚我要毒玩家{suspicious}，他肯定是狼！",
            "女巫在此！谁要是乱投我，小心我今晚毒你！建议大家听我的，先出玩家{target}！",
        ],
        "balanced": [
            "大家好，我是女巫。昨晚的情况我了解，我会根据局势决定是否用药。预言家请跳出来，我们配合。",
            "女巫身份。目前药都还在，我会谨慎使用。希望大家能提供更多信息，帮助我判断。",
            "我是女巫，昨晚没有使用任何药。今天我会根据大家的发言来决定晚上的行动。",
        ],
        "random": [
            "我是女巫，我有两瓶药，但我就是不用，哎，就是玩！",
            "女巫在此！昨晚我梦见玩家{target}是好人，所以我没用药！",
            "我是女巫，但我忘记我有什么药了，可能是可乐和薯片吧。",
        ],
    },
    "hunter": {
        "cautious": [
            "我是猎人，希望大家不要乱投我。如果我被投出去，我会带走我怀疑的人。",
            "猎人身份。目前我还不确定谁是狼，但如果有人敢投我，我一定带走他！",
            "我是猎人，我会根据局势来判断。预言家跳出来吧，我可以保护你。",
        ],
        "bold": [
            "老子是猎人！谁敢投我，我一枪崩了他！我怀疑玩家{target}是狼，先出他！",
            "猎人在此！玩家{target}你给我小心点，再乱说话我带走你！",
            "我是猎人，今天我就要投玩家{target}，他要是敢投我，咱们同归于尽！",
        ],
        "balanced": [
            "大家好，我是猎人。我会根据预言家的信息来投票。如果我被狼队针对，我会带走一个我怀疑的人。",
            "猎人身份确认。我会谨慎投票，希望大家也能理性分析，不要被狼人带节奏。",
            "我是猎人，目前还没有明确的怀疑对象。大家先发言，我会根据情况做出判断。",
        ],
        "random": [
            "我是猎人！我的枪已经上膛了，你们谁想试试？",
            "猎人在此！我觉得玩家{target}看起来像狼，要不今天投他？",
            "我是猎人，但我枪法不好，可能会打偏哦，哈哈哈！",
        ],
    },
    "villager": {
        "cautious": [
            "我就是个小村民，啥也不知道。希望预言家能给点信息，我跟着投。",
            "我是平民，昨晚啥也没干。大家别乱投我，我真的是好人。",
            "作为一个普通村民，我只能根据大家的发言来判断。希望神职能带领我们赢。",
            "我是村民，没有任何信息。预言家快出来吧，我们需要你的指引！",
        ],
        "bold": [
            "虽然我是村民，但我敢肯定玩家{target}是狼！他发言漏洞百出，大家快投他！",
            "我是平民，但我有很强的直觉！玩家{target}绝对是狼人，今天必须出他！",
            "别看我是村民，我分析能力很强！我怀疑玩家{target}和玩家{target2}是狼队友！",
        ],
        "balanced": [
            "大家好，我是平民。昨晚死了人，说明狼人很活跃。希望预言家能尽快给出查验结果。",
            "我是村民，我会根据预言家的查验和大家的发言来投票。目前我觉得玩家{target}有点可疑。",
            "作为平民，我会保持理性分析。从目前的局势来看，我们需要先找出明确的狼人。",
        ],
        "random": [
            "我是村民，我只想好好活下去，大家别投我就行。",
            "村民报到！我觉得狼人可能藏得很深，大家要小心哦！",
            "我是村民，我今天心情不错，就投玩家{target}吧，随便投投。",
        ],
    },
}


def get_role_key(role_name: str) -> str:
    role_map = {
        "Werewolf": "werewolf",
        "Seer": "seer",
        "Witch": "witch",
        "Hunter": "hunter",
        "Villager": "villager",
    }
    return role_map.get(role_name, "villager")


class PlayerAgent:
    def __init__(self, player_id: int, role_name: str, private_context: Dict[str, Any],
                 camp: str, decision_style: str = "balanced", role_type: str = ""):
        self.player_id = player_id
        self.role_name = role_name
        self.private_context = private_context
        self.camp = camp
        self.decision_style = decision_style
        self.role_type = role_type

    def _build_instructions(self) -> str:
        camp_desc = "善良阵营" if self.camp == "good" else "邪恶阵营"
        style_info = DECISION_STYLES.get(self.decision_style, DECISION_STYLES["balanced"])

        instructions = f"""你是一个狼人杀游戏中的玩家。
你的角色是：{self.role_name}
你的阵营是：{camp_desc}
你的玩家ID是：{self.player_id}

游戏规则：
1. 夜晚：狼人需要协调击杀目标，预言家查验玩家，女巫决定是否用药
2. 白天：公开辩论后投票选出嫌疑人处决
3. 胜利条件：
   - 善良阵营：消灭所有狼人
   - 邪恶阵营：消灭所有神职或所有村民

我的私有信息：
{self.private_context}

决策风格：
你的决策风格是：{style_info['name']}
特点：{style_info['description']}
- 发言倾向：{style_info['speech_tendency']}
- 投票倾向：{style_info['vote_tendency']}
- 夜间行动倾向：{style_info['night_tendency']}

请根据你的决策风格做出符合该风格的游戏决策。

输出要求：
你必须输出JSON格式的决策：
- 夜晚行动：{{"action": "night_action", "target": 玩家ID或null, "reasoning": "决策理由"}}
- 白天发言：{{"action": "speech", "content": "发言内容"}}
- 投票：{{"action": "vote", "target": 玩家ID或null}}

请根据当前游戏状态做出最优决策。
"""
        return instructions

    async def decide_night_action(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        style_info = DECISION_STYLES.get(self.decision_style, DECISION_STYLES["balanced"])
        
        prompt = f"""当前游戏状态：
{json.dumps(game_state, ensure_ascii=False, indent=2)}

你的角色是 {self.role_name}
请决定今晚的行动。

夜晚行动选项：
- 狼人：选择要击杀的目标玩家ID
- 预言家：选择要查验的目标玩家ID
- 女巫：选择是否用药（heal/poison）和目标
- 猎人：如果死亡，选择要开枪带走的目标玩家ID
- 村民：无夜间行动

{style_info['night_tendency']}

请以JSON格式输出你的决策：
"""
        return self._simulate_decision(prompt, game_state, "night")

    async def decide_speech(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        style_info = DECISION_STYLES.get(self.decision_style, DECISION_STYLES["balanced"])
        
        prompt = f"""当前游戏状态：
{json.dumps(game_state, ensure_ascii=False, indent=2)}

你的角色是 {self.role_name}
现在是公开辩论时间，请发表你的发言。

{style_info['speech_tendency']}

发言要点：
1. 根据已有信息分析谁可能是狼人
2. 说明你的推理过程
3. 质疑你认为可疑的玩家
4. 保护队友（如你是神职）

请以JSON格式输出你的发言：
{{"action": "speech", "content": "发言内容"}}
"""
        return self._simulate_decision(prompt, game_state, "speech")

    async def decide_vote(self, game_state: Dict[str, Any]) -> Dict[str, Any]:
        style_info = DECISION_STYLES.get(self.decision_style, DECISION_STYLES["balanced"])
        
        prompt = f"""当前游戏状态：
{json.dumps(game_state, ensure_ascii=False, indent=2)}

你的角色是 {self.role_name}
现在进入投票环节，请选择你要投票的目标。

{style_info['vote_tendency']}

规则：
- 你可以选择投某位玩家
- 也可以选择跳过（不投票）
- 票数最多的玩家将被处决

请以JSON格式输出你的投票：
{{"action": "vote", "target": 玩家ID或null}}
"""
        return self._simulate_decision(prompt, game_state, "vote")

    def _simulate_decision(self, prompt: str, game_state: Dict[str, Any], action_type: str) -> Dict[str, Any]:
        alive_players = game_state.get("alive_players", [])
        other_player_ids = []
        for p in alive_players:
            if isinstance(p, dict):
                pid = p.get("player_id")
                if pid is not None and pid != self.player_id:
                    other_player_ids.append(pid)
            elif isinstance(p, int) and p != self.player_id:
                other_player_ids.append(p)
        
        if action_type == "night":
            if self.role_name == "Werewolf" and other_player_ids:
                target = other_player_ids[0]
                return {
                    "action": "night_action",
                    "target": target,
                    "reasoning": f"作为狼人，选择击杀玩家{target}"
                }
            elif self.role_name == "Seer" and other_player_ids:
                target = other_player_ids[0]
                return {
                    "action": "night_action",
                    "target": target,
                    "reasoning": f"作为预言家，查验玩家{target}"
                }
            elif self.role_name == "Witch":
                return {
                    "action": "night_action",
                    "target": None,
                    "reasoning": "女巫暂不用药"
                }
            else:
                return {
                    "action": "night_action",
                    "target": None,
                    "reasoning": "无夜间行动"
                }
        
        elif action_type == "speech":
            role_key = get_role_key(self.role_name)
            style_templates = SPEECH_TEMPLATES.get(role_key, {}).get(self.decision_style, [])
            
            if style_templates:
                template = random.choice(style_templates)
                content = self._fill_template(template, game_state, other_player_ids)
            else:
                content = f"大家好，我是{self.role_name}。目前局势还不太明朗，希望大家都能坦诚发言，一起找出狼人。"
            
            return {
                "action": "speech",
                "content": content
            }
        
        elif action_type == "vote":
            if other_player_ids:
                return {
                    "action": "vote",
                    "target": other_player_ids[0] if other_player_ids else None
                }
            return {
                "action": "vote",
                "target": None
            }
        
        return {"action": "unknown"}
    
    def _fill_template(self, template: str, game_state: Dict[str, Any], other_player_ids: List[int]) -> str:
        dead_count = len(game_state.get("night_deaths", []))
        wolf_count = self._estimate_wolf_count(game_state)
        
        if other_player_ids:
            target = random.choice(other_player_ids)
            target2 = random.choice([p for p in other_player_ids if p != target]) if len(other_player_ids) > 1 else target
            suspicious = random.choice(other_player_ids)
        else:
            target = 1
            target2 = 2
            suspicious = 1
        
        check_result = self.private_context.get("check_result")
        result = "好人" if check_result and check_result.get("result") == "good" else "狼人"
        
        content = template.format(
            target=target,
            target2=target2,
            suspicious=suspicious,
            dead_count=dead_count,
            wolf_count=wolf_count,
            result=result,
            player_id=self.player_id,
        )
        return content
    
    def _estimate_wolf_count(self, game_state: Dict[str, Any]) -> int:
        total_players = len(game_state.get("players", []))
        alive_players = len(game_state.get("alive_players", []))
        return max(1, alive_players // 3)


class JudgeAgent:
    def __init__(self):
        self.name = "Judge"

    async def announce_death(self, deaths: List[int], cause: str, game_state: Dict[str, Any]) -> str:
        if not deaths:
            return "今晚无人死亡。"

        death_names = [f"玩家{p}" for p in deaths]
        cause_desc = {
            "night_kill": "昨夜",
            "vote": "投票",
            "shoot": "枪杀",
            "poison": "毒杀",
        }.get(cause, cause)

        return f"{cause_desc}，以下玩家死亡：{', '.join(death_names)}"

    async def announce_phase(self, phase: str, day_number: int) -> str:
        if "night" in phase:
            return f"第{day_number}夜开始，请各位保持安静。"
        else:
            return f"第{day_number}天，阳光照耀，请各位玩家开始发言。"


def create_player_agent(player_id: int, role_name: str, private_context: Dict[str, Any],
                       camp: str, decision_style: str = "balanced",
                       role_type: str = "") -> PlayerAgent:
    return PlayerAgent(player_id, role_name, private_context, camp, decision_style, role_type)


def create_judge_agent() -> JudgeAgent:
    return JudgeAgent()