from typing import Dict, Any, Optional


SUMMARY_PROMPT_TEMPLATE = """你刚刚完成了一局狼人杀游戏。请以第一人称视角，回顾你这局游戏的表现，进行深度总结。

## 你的身份
- 角色：{role_name}
- 阵营：{camp_name}
- 玩家名称：{player_name}

## 游戏结果
- 胜利方：{winner_name}
- 你的阵营：{is_winner_text}

## 你的游戏经历
以下是你在整局游戏中经历的所有事件：
{personal_history}

## 要求
请反思你的表现，并以 **JSON 格式** 输出以下内容：

```json
{{
    "summary": "整体表现总结（2-3句话，回顾自己本局的表现和关键决策）",
    "strategies": "你使用了哪些策略？哪些有效、哪些无效？",
    "mistakes": "犯了哪些错误？有哪些地方可以做得更好？",
    "lessons": "对未来的自己有什么具体建议？（1-2条，面向同角色的后续游戏）"
}}
```

只输出 JSON，不要包含其他内容。
"""


class SummaryAgent:
    def __init__(self):
        self.name = "SummaryAgent"

    async def generate_summary(
        self,
        player_name: str,
        role_name: str,
        camp: str,
        winner: Optional[str],
        personal_history: str,
    ) -> Dict[str, str]:
        camp_name = "善良阵营" if camp == "good" else "邪恶阵营"
        winner_name = "善良阵营（好人）" if winner == "good" else "邪恶阵营（狼人）" if winner == "evil" else (winner or "未知")
        is_winner_text = "胜利！" if camp == winner else "失败。"

        return {
            "summary": f"本局游戏我扮演{role_name}，{is_winner_text}整体表现中规中矩。",
            "strategies": "采用了基本策略，包括分析发言、投票决策等。",
            "mistakes": "在某些决策上可能过于保守/激进，导致错失良机。",
            "lessons": "下次需要更好地分析局势，把握关键投票机会。",
        }


__all__ = ["SummaryAgent"]