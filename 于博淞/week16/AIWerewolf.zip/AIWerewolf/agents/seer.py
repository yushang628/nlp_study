import random
import logging

from agents.base import BaseAgent
from game.state import GameState
from prompts.action_templates import build_event_log, seer_check_prompt

logger = logging.getLogger(__name__)


class SeerAgent(BaseAgent):
    """预言家：每晚查验一名玩家的真实阵营。"""

    async def night_action(self, state: GameState) -> dict:
        event_log = build_event_log(self.event_history)
        prompt = seer_check_prompt(state, self.player.id)

        raw = await self._call_llm(f"{event_log}\n\n{prompt}", temperature=0.5)
        data = self._extract_json(raw)

        # 不能查验自己
        valid_ids = {p.id for p in state.alive_players() if p.id != self.player.id}
        # 优先查未查验过的玩家
        unchecked = valid_ids - set(self.role_context.get("checks", {}).keys())
        candidates = unchecked if unchecked else valid_ids

        try:
            check_id = int(data.get("check", 0))
            if check_id in valid_ids:
                return {"check": check_id}
        except (ValueError, TypeError):
            pass

        check_id = random.choice(list(candidates))
        logger.warning("[%s] 预言家查验解析失败，随机查验 %d", self.player.name, check_id)
        return {"check": check_id}
