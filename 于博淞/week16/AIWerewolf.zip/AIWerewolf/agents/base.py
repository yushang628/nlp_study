"""
BaseAgent — 所有角色 Agent 的基类。

设计原则：
  - 每次行动 = 独立的 API 调用（system + 上下文 + 行动请求）
    避免长对话漂移，且方便 Stage 6 替换 system prompt。
  - 私有信息通过 receive_event() 注入，与公开信息共存于 event_history。
  - 所有 LLM 调用均为 async，支持夜间并发。
"""
from __future__ import annotations

import asyncio
import json
import random
import re
import logging
from typing import Any, Optional

from game.events import GameEvent
from game.roles import Role
from game.state import GameState, Player
from prompts.role_prompts import build_system_prompt
from prompts.action_templates import (
    build_event_log,
    speak_prompt,
    vote_prompt,
    last_words_prompt,
    hunter_shoot_prompt,
)
import config
from agents.llm_client import get_async_client

logger = logging.getLogger(__name__)


class BaseAgent:
    """所有角色 Agent 的抽象基类。"""

    def __init__(
        self,
        player: Player,
        strategy_override: str | None = None,   # Stage 6: 自进化注入策略
    ) -> None:
        self.player = player
        self.event_history: list[GameEvent] = []
        # 角色专属动态信息（由 Engine 在游戏开始时注入）
        # werewolf: {"allies": ["阿明", "阿丽"]}
        # seer:     {"checks": {"阿强": "狼人"}}
        # witch:    {"save_left": True, "poison_left": True}
        # guard:    {"last_protect": None}
        self.role_context: dict[str, Any] = {}
        self.strategy_override = strategy_override   # None = 使用默认策略
        self._client = get_async_client()

    # ── 事件接收 ─────────────────────────────────────────────────────────

    def receive_event(self, event: GameEvent) -> None:
        """Engine 按权限过滤后调用，将事件写入该 Agent 的私有历史。"""
        self.event_history.append(event)

    # ── System Prompt ─────────────────────────────────────────────────────

    def _system_prompt(self) -> str:
        return build_system_prompt(
            player_id=self.player.id,
            player_name=self.player.name,
            role=self.player.role,
            role_context=self.role_context,
            strategy_override=self.strategy_override,   # Stage 6
        )

    # ── LLM 核心调用 ──────────────────────────────────────────────────────

    async def _call_llm(self, user_content: str, temperature: Optional[float] = None) -> str:
        """单次 LLM 调用，返回模型输出文本。"""
        messages = [
            {"role": "system",  "content": self._system_prompt()},
            {"role": "user",    "content": user_content},
        ]
        t = temperature if temperature is not None else config.LLM_TEMPERATURE
        try:
            resp = await self._client.chat.completions.create(
                model=config.LLM_MODEL,
                messages=messages,
                temperature=t,
                max_tokens=config.LLM_MAX_TOKENS,
            )
            text = resp.choices[0].message.content or ""
            logger.debug("[%s] LLM raw: %s", self.player.name, text[:120])
            return text.strip()
        except Exception as exc:
            logger.error("[%s] LLM 调用失败: %s", self.player.name, exc)
            return ""

    # ── JSON 解析工具 ─────────────────────────────────────────────────────

    @staticmethod
    def _extract_json(text: str) -> dict:
        """从 LLM 响应中提取第一个合法 JSON 对象。"""
        # 先尝试整体解析
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        # 再用正则提取 {...}
        m = re.search(r"\{.*?\}", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
        return {}

    # ── 公共行动接口 ──────────────────────────────────────────────────────

    async def speak(self, state: GameState, hint: str = "") -> str:
        """
        白天发言。返回自然语言字符串。
        hint: 可选提示，如"你是第一个发言的玩家"。
        """
        event_log = build_event_log(self.event_history)
        prompt = speak_prompt(state, self.player.id, hint)
        user_content = f"{event_log}\n\n{prompt}"
        reply = await self._call_llm(user_content)
        return reply if reply else f"（{self.player.name} 沉默不语）"

    async def last_words(self, state: GameState, death_cause: str) -> str:
        """遗言。"""
        event_log = build_event_log(self.event_history)
        prompt = last_words_prompt(state, self.player.id, death_cause)
        user_content = f"{event_log}\n\n{prompt}"
        reply = await self._call_llm(user_content)
        return reply if reply else f"（{self.player.name} 无话可说）"

    async def vote(self, state: GameState) -> tuple[int, str]:
        """
        投票放逐。返回 (target_player_id, reason)。
        若解析失败则随机从存活玩家中选一人。
        """
        event_log = build_event_log(self.event_history)
        prompt = vote_prompt(state, self.player.id)
        user_content = f"{event_log}\n\n{prompt}"

        raw = await self._call_llm(user_content, temperature=0.5)
        data = self._extract_json(raw)

        alive_others = [p for p in state.alive_players() if p.id != self.player.id]
        valid_ids = {p.id for p in alive_others}

        try:
            vid = int(data.get("vote", 0))
            reason = str(data.get("reason", ""))
            if vid in valid_ids:
                return vid, reason
        except (ValueError, TypeError):
            pass

        # 降级：随机投票
        fallback = random.choice(alive_others)
        logger.warning("[%s] 投票解析失败，随机投 %s", self.player.name, fallback.name)
        return fallback.id, "（投票解析失败，随机选择）"

    async def hunter_shoot(self, state: GameState) -> tuple[int, str]:
        """猎人射击。返回 (target_id, reason)。"""
        event_log = build_event_log(self.event_history)
        prompt = hunter_shoot_prompt(state, self.player.id)
        user_content = f"{event_log}\n\n{prompt}"

        raw = await self._call_llm(user_content, temperature=0.5)
        data = self._extract_json(raw)

        alive_others = [p for p in state.alive_players() if p.id != self.player.id]
        valid_ids = {p.id for p in alive_others}

        try:
            sid = int(data.get("shoot", 0))
            reason = str(data.get("reason", ""))
            if sid in valid_ids:
                return sid, reason
        except (ValueError, TypeError):
            pass

        fallback = random.choice(alive_others)
        return fallback.id, "（射击解析失败，随机选择）"

    # ── 夜间行动（子类实现）───────────────────────────────────────────────

    async def night_action(self, state: GameState) -> dict:
        """
        夜间行动。子类根据角色实现具体逻辑。
        返回 dict 供 Engine 读取，格式因角色而异。
        默认实现：无夜间能力，直接返回空。
        """
        return {}

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} {self.player.id}号·{self.player.name}>"
