import random
import logging

from agents.base import BaseAgent
from game.roles import Role
from game.state import GameState
from prompts.action_templates import build_event_log, wolf_discuss_prompt

logger = logging.getLogger(__name__)


class WerewolfAgent(BaseAgent):
    """
    狼人：每晚与同伴（通过 WOLF 可见事件）协商后击杀一名好人。
    引擎依次调用各狼人，每次调用前已将前一匹狼的分析广播为 WOLF 事件，
    形成自然的顺序讨论。
    """

    async def night_action(self, state: GameState) -> dict:
        ally_names: list[str] = self.role_context.get("allies", [])
        event_log = build_event_log(self.event_history)
        prompt = wolf_discuss_prompt(state, self.player.id, ally_names)

        raw = await self._call_llm(f"{event_log}\n\n{prompt}", temperature=0.7)
        data = self._extract_json(raw)

        # 合法击杀目标：存活的非狼人玩家
        valid_ids = {
            p.id for p in state.alive_players()
            if p.role != Role.WEREWOLF
        }

        analysis = str(data.get("analysis", ""))
        try:
            kill_id = int(data.get("kill", 0))
            if kill_id in valid_ids:
                return {"kill": kill_id, "analysis": analysis}
        except (ValueError, TypeError):
            pass

        kill_id = random.choice(list(valid_ids))
        logger.warning("[%s] 狼人击杀解析失败，随机选择 %d", self.player.name, kill_id)
        return {"kill": kill_id, "analysis": analysis}
