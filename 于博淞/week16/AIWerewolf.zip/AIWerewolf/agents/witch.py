import logging

from agents.base import BaseAgent
from game.state import GameState
from prompts.action_templates import build_event_log, witch_action_prompt

logger = logging.getLogger(__name__)


class WitchAgent(BaseAgent):
    """女巫：持有解药×1、毒药×1，各限用一次。"""

    async def night_action(self, state: GameState) -> dict:
        save_left   = self.role_context.get("save_left",   True)
        poison_left = self.role_context.get("poison_left", True)
        kill_name   = self.role_context.get("kill_target_name")  # 由引擎注入

        event_log = build_event_log(self.event_history)
        prompt = witch_action_prompt(
            state, self.player.id, kill_name, save_left, poison_left
        )

        raw = await self._call_llm(f"{event_log}\n\n{prompt}", temperature=0.6)
        data = self._extract_json(raw)

        # 解析 save
        want_save = bool(data.get("save", False))
        save = want_save and save_left and kill_name is not None

        # 解析 poison
        poison_id = None
        if poison_left:
            try:
                raw_poison = data.get("poison")
                if raw_poison is not None and str(raw_poison).strip() not in ("null", "None", ""):
                    pid = int(raw_poison)
                    alive_ids = {p.id for p in state.alive_players()}
                    if pid in alive_ids and pid != self.player.id:
                        poison_id = pid
            except (ValueError, TypeError):
                pass

        return {"save": save, "poison": poison_id}
