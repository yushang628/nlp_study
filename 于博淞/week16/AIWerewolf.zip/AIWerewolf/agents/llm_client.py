"""
统一 LLM 客户端工厂。
使用 DashScope OpenAI 兼容接口，支持 async 并发（夜间多 Agent 并行）。
"""
from openai import AsyncOpenAI
import config


def get_async_client() -> AsyncOpenAI:
    if not config.DASHSCOPE_API_KEY:
        raise EnvironmentError(
            "未找到 DASHSCOPE_API_KEY，请在项目根目录创建 .env 文件并填写。"
        )
    return AsyncOpenAI(
        api_key=config.DASHSCOPE_API_KEY,
        base_url=config.LLM_BASE_URL,
    )
