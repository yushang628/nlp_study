from agents.base import BaseAgent
from game.state import GameState


class HunterAgent(BaseAgent):
    """猎人：无主动夜间能力；被杀/放逐时引擎调用 hunter_shoot()（已在 BaseAgent 实现）。"""

    async def night_action(self, state: GameState) -> dict:
        return {}  # 猎人无夜间主动行动
