from agents.base import BaseAgent
from game.state import GameState


class VillagerAgent(BaseAgent):
    """村民：无夜间能力，纯推理。"""

    async def night_action(self, state: GameState) -> dict:
        return {}  # 村民无夜间行动
