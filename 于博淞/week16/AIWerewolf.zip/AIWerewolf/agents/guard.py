import random
import logging

from agents.base import BaseAgent
from game.state import GameState
from prompts.action_templates import build_event_log, guard_protect_prompt

logger = logging.getLogger(__name__)


class GuardAgent(BaseAgent):
    """守卫：每晚保护一名玩家，不可连续守护同人。"""

    async def night_action(self, state: GameState) -> dict:
        last_protect = self.role_context.get("last_protect")
        event_log = build_event_log(self.event_history)
        prompt = guard_protect_prompt(state, self.player.id, last_protect)

        raw = await self._call_llm(f"{event_log}\n\n{prompt}", temperature=0.5)
        data = self._extract_json(raw)

        valid_ids = {
            p.id for p in state.alive_players()
            if p.id != last_protect   # 不可连续守护同人
        }

        try:
            protect_id = int(data.get("protect", 0))
            if protect_id in valid_ids:
                return {"protect": protect_id}
        except (ValueError, TypeError):
            pass

        # 降级：随机选
        protect_id = random.choice(list(valid_ids)) if valid_ids else self.player.id
        logger.warning("[%s] 守卫选择解析失败，随机保护 %d", self.player.name, protect_id)
        return {"protect": protect_id}
