"""
结构化游戏日志。
  - 流式写 JSONL（每行一条记录），供实时观测
  - 游戏结束后输出 replay.json，供 Stage 6 复盘分析
"""
from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any

from game.state import GameState


class GameLogger:
    def __init__(self, game_id: str, log_dir: str = "logs", replay_dir: str = "replays"):
        self.game_id = game_id
        self.records: list[dict] = []
        os.makedirs(log_dir, exist_ok=True)
        os.makedirs(replay_dir, exist_ok=True)
        self.log_path    = os.path.join(log_dir,    f"{game_id}.jsonl")
        self.replay_path = os.path.join(replay_dir, f"{game_id}.json")
        # 清空同名旧日志
        open(self.log_path, "w", encoding="utf-8").close()

    # ── 写入接口 ──────────────────────────────────────────────────────────

    def record(self, record_type: str, **kwargs: Any) -> None:
        entry: dict = {
            "type":      record_type,
            "ts":        datetime.now().isoformat(timespec="seconds"),
            **kwargs,
        }
        self.records.append(entry)
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # 快捷方法
    def event(self, round_: int, phase: str, content: str, **kw) -> None:
        self.record("event", round=round_, phase=phase, content=content, **kw)

    def decision(self, round_: int, phase: str, player: str,
                 action: str, content: str, reasoning: str = "", **kw) -> None:
        self.record("decision", round=round_, phase=phase, player=player,
                    action=action, content=content, reasoning=reasoning, **kw)

    def settlement(self, round_: int, summary: str, **kw) -> None:
        self.record("settlement", round=round_, summary=summary, **kw)

    # ── Replay ────────────────────────────────────────────────────────────

    def save_replay(self, state: GameState, elapsed: float) -> str:
        replay = {
            "game_id":            self.game_id,
            "winner":             state.winner.value if state.winner else None,
            "winner_reason":      state.winner_reason,
            "rounds":             state.round,
            "elapsed_seconds":    round(elapsed, 1),
            "players": [
                {
                    "id":      p.id,
                    "name":    p.name,
                    "role":    p.role.value,
                    "survived": p.is_alive,
                }
                for p in state.players
            ],
            "timeline": self.records,
        }
        with open(self.replay_path, "w", encoding="utf-8") as f:
            json.dump(replay, f, ensure_ascii=False, indent=2)
        return self.replay_path
