"""
Leaderboard — 追踪各版本策略的胜率，Rich 渲染对比表格。
"""
from __future__ import annotations

import json
import os

from rich import box
from rich.console import Console
from rich.table import Table

console = Console()


class Leaderboard:
    def __init__(self, stats_path: str = "strategies/stats.json") -> None:
        self.stats_path = stats_path
        self._stats: dict = self._load()

    # ── I/O ──────────────────────────────────────────────────────────────

    def _load(self) -> dict:
        if os.path.exists(self.stats_path):
            with open(self.stats_path, encoding="utf-8") as f:
                return json.load(f)
        return {}

    def _save(self) -> None:
        os.makedirs(os.path.dirname(self.stats_path), exist_ok=True)
        with open(self.stats_path, "w", encoding="utf-8") as f:
            json.dump(self._stats, f, ensure_ascii=False, indent=2)

    # ── 记录 ─────────────────────────────────────────────────────────────

    def record_game(self, version: int, winner: str, rounds: int) -> None:
        key = f"v{version}"
        if key not in self._stats:
            self._stats[key] = {
                "total_games":   0,
                "villager_wins": 0,
                "wolf_wins":     0,
                "total_rounds":  0,
            }
        s = self._stats[key]
        s["total_games"]   += 1
        s["villager_wins"] += (1 if winner == "villager" else 0)
        s["wolf_wins"]     += (1 if winner != "villager" else 0)
        s["total_rounds"]  += rounds
        self._save()

    # ── 查询 ─────────────────────────────────────────────────────────────

    def get_stats(self, version: int | None = None) -> dict:
        if version is not None:
            return self._stats.get(f"v{version}", {})
        return self._stats

    # ── 显示 ─────────────────────────────────────────────────────────────

    def print_table(self) -> None:
        if not self._stats:
            console.print("[dim]暂无对局记录。[/dim]")
            return

        t = Table(title="🏆 进化 Leaderboard", box=box.DOUBLE, show_lines=True,
                  highlight=True)
        t.add_column("版本",     justify="center", min_width=6)
        t.add_column("总局数",   justify="center", min_width=6)
        t.add_column("好人胜率", justify="center", min_width=8)
        t.add_column("狼人胜率", justify="center", min_width=8)
        t.add_column("均轮数",   justify="center", min_width=7)
        t.add_column("vs 基准",  justify="center", min_width=9)

        v0_stats   = self._stats.get("v0", {})
        base_vr    = (v0_stats.get("villager_wins", 0)
                      / max(v0_stats.get("total_games", 1), 1))

        best_vr   = max(
            (s.get("villager_wins", 0) / max(s.get("total_games", 1), 1))
            for s in self._stats.values()
        ) if self._stats else 0

        for key in sorted(self._stats.keys()):
            s  = self._stats[key]
            n  = max(s.get("total_games", 0), 1)
            vr = s.get("villager_wins", 0) / n
            wr = s.get("wolf_wins", 0) / n
            avg_r = s.get("total_rounds", 0) / n

            delta = vr - base_vr
            if key == "v0":
                delta_str = "[dim]─ 基准[/dim]"
            elif delta > 0.02:
                delta_str = f"[bold green]↑ +{delta:.1%}[/bold green]"
            elif delta < -0.02:
                delta_str = f"[red]↓ {delta:.1%}[/red]"
            else:
                delta_str = "[yellow]→ 持平[/yellow]"

            # 最优版本加星
            is_best = (vr == best_vr and key != "v0")
            vr_str = (f"[bold green]{vr:.1%} ★[/bold green]"
                      if is_best else
                      f"[green]{vr:.1%}[/green]" if vr >= 0.6
                      else f"[yellow]{vr:.1%}[/yellow]")

            t.add_row(key, str(s.get("total_games", 0)),
                      vr_str, f"[red]{wr:.1%}[/red]",
                      f"{avg_r:.1f}", delta_str)

        console.print(t)
