"""
复盘分析器 — 读取 replay.json，用 LLM 输出关键分析和策略改进建议。
"""
from __future__ import annotations

import json
import re

from pydantic import BaseModel

import config
from agents.llm_client import get_async_client


# ── 数据模型 ─────────────────────────────────────────────────────────────

class RoleFeedback(BaseModel):
    strength:   str = ""
    weakness:   str = ""
    suggestion: str = ""


class AnalysisResult(BaseModel):
    game_id:            str
    winner:             str   # "villager" | "werewolf"
    rounds:             int
    key_moment:         str = ""
    winner_strategy:    str = ""
    loser_mistakes:     str = ""
    role_feedback:      dict[str, RoleFeedback] = {}
    updated_strategies: dict[str, str] = {}       # role -> 新策略文本


# ── 分析器 ────────────────────────────────────────────────────────────────

class ReplayAnalyzer:
    def __init__(self) -> None:
        self._client = get_async_client()

    async def analyze(self, replay_path: str) -> AnalysisResult:
        with open(replay_path, encoding="utf-8") as f:
            replay = json.load(f)

        prompt = self._build_prompt(replay)
        try:
            resp = await self._client.chat.completions.create(
                model=config.LLM_MODEL,
                messages=[
                    {"role": "system",
                     "content": "你是狼人杀游戏资深教练，擅长复盘分析和策略迭代优化。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=2000,
            )
            raw = resp.choices[0].message.content or ""
            return self._parse(replay, raw)
        except Exception as exc:
            return AnalysisResult(
                game_id=replay.get("game_id", ""),
                winner=replay.get("winner", ""),
                rounds=replay.get("rounds", 0),
                key_moment=f"[分析失败: {exc}]",
            )

    # ── Prompt 构建 ───────────────────────────────────────────────────────

    def compact_timeline(self, timeline: list[dict]) -> str:
        lines: list[str] = []
        for e in timeline:
            t, r = e.get("type"), e.get("round", 0)
            ph = e.get("phase", "")
            if t == "event":
                lines.append(f"[第{r}轮·{ph}] {e.get('content','')}")
            elif t == "decision":
                player  = e.get("player", "")
                action  = e.get("action", "")
                content = e.get("content", "")[:60]
                reason  = e.get("reasoning", "")[:40]
                line    = f"[第{r}轮] {player} {action}: {content}"
                if reason:
                    line += f"  ← {reason}"
                lines.append(line)
            elif t == "settlement":
                lines.append(f"[第{r}轮·结算] {e.get('summary','')}")
        return "\n".join(lines)

    def _build_prompt(self, replay: dict) -> str:
        players_str = "\n".join(
            f"  {p['id']}号 {p['name']} — {p['role']} — "
            f"{'存活' if p['survived'] else '死亡'}"
            for p in replay.get("players", [])
        )
        winner_cn = "好人阵营" if replay.get("winner") == "villager" else "狼人阵营"
        timeline  = self.compact_timeline(replay.get("timeline", []))

        return f"""请对以下狼人杀对局进行复盘分析，并给出角色策略改进建议。

【对局信息】获胜方：{winner_cn}  轮数：{replay.get('rounds')} 轮
原因：{replay.get('winner_reason', '')}

【玩家阵容】
{players_str}

【对局时间线】
{timeline}

请以 JSON 格式输出分析报告（不要有任何多余文字）：
{{
  "key_moment":      "关键转折点（50字内）",
  "winner_strategy": "获胜方核心策略（50字内）",
  "loser_mistakes":  "失败方主要失误（50字内）",
  "role_feedback": {{
    "werewolf": {{"strength":"优点","weakness":"弱点","suggestion":"建议"}},
    "seer":     {{"strength":"优点","weakness":"弱点","suggestion":"建议"}},
    "witch":    {{"strength":"优点","weakness":"弱点","suggestion":"建议"}},
    "villager": {{"strength":"优点","weakness":"弱点","suggestion":"建议"}},
    "hunter":   {{"strength":"优点","weakness":"弱点","suggestion":"建议"}},
    "guard":    {{"strength":"优点","weakness":"弱点","suggestion":"建议"}}
  }},
  "updated_strategies": {{
    "werewolf": "优化后策略（100字内，直接替换进系统提示词）",
    "seer":     "优化后策略（100字内）",
    "witch":    "优化后策略（100字内）",
    "villager": "优化后策略（100字内）",
    "hunter":   "优化后策略（100字内）",
    "guard":    "优化后策略（100字内）"
  }}
}}"""

    # ── 解析 ─────────────────────────────────────────────────────────────

    def _parse(self, replay: dict, raw: str) -> AnalysisResult:
        try:
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            data: dict = json.loads(m.group() if m else raw)
        except Exception:
            data = {}

        role_feedback: dict[str, RoleFeedback] = {}
        for role, fb in data.get("role_feedback", {}).items():
            if isinstance(fb, dict):
                role_feedback[role] = RoleFeedback(
                    strength   = str(fb.get("strength", "")),
                    weakness   = str(fb.get("weakness", "")),
                    suggestion = str(fb.get("suggestion", "")),
                )

        updated: dict[str, str] = {
            role: str(text)
            for role, text in data.get("updated_strategies", {}).items()
            if text and len(str(text)) > 20
        }

        return AnalysisResult(
            game_id=replay.get("game_id", ""),
            winner=replay.get("winner", ""),
            rounds=replay.get("rounds", 0),
            key_moment=str(data.get("key_moment", "")),
            winner_strategy=str(data.get("winner_strategy", "")),
            loser_mistakes=str(data.get("loser_mistakes", "")),
            role_feedback=role_feedback,
            updated_strategies=updated,
        )
