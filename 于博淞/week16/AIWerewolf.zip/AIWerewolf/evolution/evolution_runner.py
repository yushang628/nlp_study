"""
EvolutionRunner — 自进化循环编排器

流程（每个周期）：
  ① 用当前策略 vN 运行 K 局对局
  ② ReplayAnalyzer 逐局复盘
  ③ LLM 聚合 K 局观察 → 合成优化策略
  ④ 保存为策略 v(N+1)
  ⑤ Leaderboard 更新展示
  ⑥ 进入下一周期
"""
from __future__ import annotations

import json
import re

from rich.console import Console
from rich.rule import Rule

import config
from agents.llm_client import get_async_client
from evolution.leaderboard import Leaderboard
from evolution.replay_analyzer import AnalysisResult, ReplayAnalyzer
from evolution.strategy_store import StrategyStore
from game.engine import GameEngine

console = Console()


class EvolutionRunner:
    def __init__(self, preset: str = "quick_6") -> None:
        self.preset     = preset
        self.store      = StrategyStore()
        self.analyzer   = ReplayAnalyzer()
        self.leaderboard = Leaderboard()
        self._client    = get_async_client()

    # ═════════════════════════════════════════════════════════════════════
    # 公开入口
    # ═════════════════════════════════════════════════════════════════════

    async def run_cycle(
        self,
        games_per_cycle: int = 3,
        cycles: int = 3,
    ) -> None:
        console.print(Rule(
            "[bold cyan]🔄  自进化循环启动[/bold cyan]", style="cyan"
        ))
        console.print(
            f"  preset=[cyan]{self.preset}[/cyan]  "
            f"cycles=[cyan]{cycles}[/cyan]  "
            f"games/cycle=[cyan]{games_per_cycle}[/cyan]"
        )

        for cycle in range(cycles):
            version = self.store.get_current_version()
            console.print(Rule(
                f"[bold yellow]  周期 {cycle+1}/{cycles} · 策略 v{version}  [/bold yellow]",
                style="yellow"
            ))

            # ① 运行对局
            replay_paths = await self._run_games(games_per_cycle, version)

            # ② 复盘分析
            analyses = await self._analyze_replays(replay_paths, version)

            # ③ 合成新策略
            console.print("\n  [green]⚡ 策略合成优化中...[/green]")
            new_strategies = await self._synthesize(analyses, version)

            # ④ 保存新版本
            new_version = version + 1
            path = self.store.save_version(new_strategies, new_version, replay_paths)
            console.print(f"  [bold green]✓ 策略 v{new_version} 已保存 → {path}[/bold green]")

            # ⑤ Leaderboard
            self.leaderboard.print_table()

        console.print(Rule("[bold cyan]🏁  进化循环完成[/bold cyan]", style="cyan"))

    # ═════════════════════════════════════════════════════════════════════
    # 步骤实现
    # ═════════════════════════════════════════════════════════════════════

    async def _run_games(
        self, count: int, version: int
    ) -> list[str]:
        strategies   = self.store.load_strategies(version)
        replay_paths = []
        for i in range(count):
            console.print(f"  [cyan]▶  对局 {i+1}/{count}  (策略 v{version})[/cyan]")
            engine = GameEngine(
                preset=self.preset,
                verbose=False,
                strategy_overrides=strategies,
            )
            await engine.run()
            path = engine.logger.replay_path
            replay_paths.append(path)

            # 记录到 Leaderboard
            winner = engine.state.winner.value if engine.state.winner else "unknown"
            self.leaderboard.record_game(
                version, winner, engine.state.round
            )
            console.print(
                f"    → {winner} 胜  {engine.state.round} 轮  {path}"
            )
        return replay_paths

    async def _analyze_replays(
        self, replay_paths: list[str], version: int
    ) -> list[AnalysisResult]:
        console.print(
            f"\n  [magenta]🔬 复盘分析 {len(replay_paths)} 场...[/magenta]"
        )
        analyses: list[AnalysisResult] = []
        for path in replay_paths:
            result = await self.analyzer.analyze(path)
            analyses.append(result)
            console.print(
                f"    [dim]{path[-25:]}[/dim]  "
                f"胜:{result.winner}  "
                f"关键: {result.key_moment[:35]}..."
            )
        return analyses

    async def _synthesize(
        self, analyses: list[AnalysisResult], current_version: int
    ) -> dict[str, str]:
        """
        将多场对局分析汇总，调用 LLM 生成新一版策略。
        若 LLM 失败，返回当前版本策略（不回退）。
        """
        current = self.store.load_strategies(current_version)

        # 构建跨局摘要
        summaries: list[str] = []
        for i, a in enumerate(analyses):
            winner_cn = "好人" if a.winner == "villager" else "狼人"
            fb_lines  = [
                f"  {role}: 优={fb.strength[:25]} 劣={fb.weakness[:25]}"
                for role, fb in a.role_feedback.items()
            ]
            summaries.append(
                f"对局{i+1}({winner_cn}胜,{a.rounds}轮): {a.key_moment}\n"
                f"  失败方失误: {a.loser_mistakes}\n"
                + "\n".join(fb_lines)
            )

        current_json = json.dumps(current, ensure_ascii=False, indent=2)
        summary_block = "\n\n".join(
            f"=== 对局{i+1} ===\n{s}" for i, s in enumerate(summaries)
        )

        prompt = f"""你是狼人杀策略迭代专家，请基于以下 {len(analyses)} 场对局观察，
对每个角色的策略进行优化迭代，使好人阵营整体胜率提升。

【{len(analyses)} 场对局摘要】
{summary_block}

【当前策略 (v{current_version})】
{current_json}

请输出 JSON（不要有多余文字）：
{{
  "analysis_summary": "跨局共性问题（80字内）",
  "updated_strategies": {{
    "werewolf": "优化后的狼人策略（100字内，保持实战性）",
    "seer":     "优化后的预言家策略（100字内）",
    "witch":    "优化后的女巫策略（100字内）",
    "villager": "优化后的村民策略（100字内）",
    "hunter":   "优化后的猎人策略（100字内）",
    "guard":    "优化后的守卫策略（100字内）"
  }}
}}"""

        try:
            resp = await self._client.chat.completions.create(
                model=config.LLM_MODEL,
                messages=[
                    {"role": "system", "content": "你是狼人杀策略优化专家。"},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.4,
                max_tokens=2000,
            )
            raw = resp.choices[0].message.content or ""
            m   = re.search(r"\{.*\}", raw, re.DOTALL)
            data: dict = json.loads(m.group() if m else raw)

            new_strats  = dict(current)
            updates     = data.get("updated_strategies", {})
            for role, text in updates.items():
                if text and len(str(text)) > 30:
                    new_strats[role] = str(text)
                    console.print(f"    [dim]↺ {role} 策略已更新[/dim]")

            summary = data.get("analysis_summary", "")
            if summary:
                console.print(f"  [dim]共性问题: {summary[:80]}[/dim]")

            return new_strats

        except Exception as exc:
            console.print(f"  [red]合成失败 ({exc})，保留当前策略。[/red]")
            return dict(current)
