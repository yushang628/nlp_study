"""
策略版本库 — 持久化存储各轮进化后的角色策略。

目录结构：
  strategies/
    v0.json   # 初始版本（从 role_prompts 提取默认策略）
    v1.json   # 第一轮进化后
    ...
    stats.json  # 由 Leaderboard 管理
"""
from __future__ import annotations

import json
import os
from datetime import datetime

from game.roles import Role
from prompts.role_prompts import _role_strategy


class StrategyStore:
    def __init__(self, store_dir: str = "strategies") -> None:
        self.store_dir = store_dir
        os.makedirs(store_dir, exist_ok=True)
        self._init_v0()

    # ── 初始化 ────────────────────────────────────────────────────────────

    def _init_v0(self) -> None:
        """若 v0 不存在，则从 role_prompts 提取默认策略写入。"""
        v0_path = os.path.join(self.store_dir, "v0.json")
        if not os.path.exists(v0_path):
            strategies = {role.value: _role_strategy(role) for role in Role}
            self.save_version(strategies, version=0, based_on=[])

    # ── 查询 ─────────────────────────────────────────────────────────────

    def get_current_version(self) -> int:
        versions = self._list_versions()
        return max(versions) if versions else 0

    def _list_versions(self) -> list[int]:
        vs: list[int] = []
        for fname in os.listdir(self.store_dir):
            if fname.startswith("v") and fname.endswith(".json") \
                    and fname != "stats.json":
                try:
                    vs.append(int(fname[1:-5]))
                except ValueError:
                    pass
        return vs

    def load_strategies(self, version: int | None = None) -> dict[str, str]:
        if version is None:
            version = self.get_current_version()
        path = os.path.join(self.store_dir, f"v{version}.json")
        if not os.path.exists(path):
            return {}
        with open(path, encoding="utf-8") as f:
            return json.load(f).get("strategies", {})

    def list_all(self) -> list[dict]:
        result = []
        for v in sorted(self._list_versions()):
            path = os.path.join(self.store_dir, f"v{v}.json")
            with open(path, encoding="utf-8") as f:
                result.append(json.load(f))
        return result

    # ── 保存 ─────────────────────────────────────────────────────────────

    def save_version(
        self,
        strategies: dict[str, str],
        version: int,
        based_on: list[str],
    ) -> str:
        data = {
            "version":           version,
            "created_at":        datetime.now().isoformat(timespec="seconds"),
            "based_on_replays":  based_on,
            "strategies":        strategies,
        }
        path = os.path.join(self.store_dir, f"v{version}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return path
