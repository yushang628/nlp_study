"""
自进化循环入口。

用法：
  py main_evolve.py                                   # 3周期×3局，quick_6
  py main_evolve.py --cycles 5 --games 2              # 5周期×2局
  py main_evolve.py --preset debug_4 --cycles 2       # 调试局
  py main_evolve.py --leaderboard                     # 仅查看 Leaderboard
  py main_evolve.py --strategies                      # 列出所有策略版本
"""
import asyncio
import os
import sys

os.environ.setdefault("PYTHONIOENCODING", "utf-8")


def parse_args() -> dict:
    args = sys.argv[1:]
    result = {
        "cycles":      3,
        "games":       3,
        "preset":      "quick_6",
        "leaderboard": False,
        "strategies":  False,
    }
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--leaderboard":
            result["leaderboard"] = True
        elif a == "--strategies":
            result["strategies"] = True
        elif a in ("--cycles", "--games") and i + 1 < len(args):
            result[a[2:]] = int(args[i + 1])
            i += 1
        elif a == "--preset" and i + 1 < len(args):
            result["preset"] = args[i + 1]
            i += 1
        i += 1
    return result


async def main() -> None:
    opts = parse_args()

    if opts["leaderboard"]:
        from evolution.leaderboard import Leaderboard
        Leaderboard().print_table()
        return

    if opts["strategies"]:
        from evolution.strategy_store import StrategyStore
        import json
        store = StrategyStore()
        for v in store.list_all():
            print(f"\n── v{v['version']}  {v['created_at']} ──")
            for role, text in v["strategies"].items():
                print(f"  [{role}] {text[:60]}...")
        return

    from evolution.evolution_runner import EvolutionRunner
    runner = EvolutionRunner(preset=opts["preset"])
    await runner.run_cycle(
        games_per_cycle=opts["games"],
        cycles=opts["cycles"],
    )


if __name__ == "__main__":
    asyncio.run(main())
