"""
各角色的 System Prompt 生成函数。
返回值直接用作 messages[0]["content"]。
每个函数接受 player 信息 + 动态上下文，供 Stage 6 自进化时替换优化。
"""
from game.roles import Role, ROLE_NAME_CN


def build_system_prompt(
    player_id: int,
    player_name: str,
    role: Role,
    role_context: dict,
    strategy_override: str | None = None,   # Stage 6: 由 StrategyStore 注入
) -> str:
    """
    role_context 字段说明（按角色）：
      werewolf : allies     list[str]   同伴名单
      seer     : checks     dict[str,str] {名字: "好人"/"狼人"}
      witch    : save_left  bool, poison_left bool
      guard    : last_protect str | None
    strategy_override: 若提供，替换默认策略文本（自进化专用）。
    """
    base     = _base_header(player_id, player_name, role)
    extra    = _role_extra(role, role_context)
    strategy = strategy_override if strategy_override else _role_strategy(role)
    return f"{base}\n\n{extra}\n\n{strategy}\n\n{_output_format()}"


# ── 公共部分 ──────────────────────────────────────────────────────────────

def _base_header(pid: int, name: str, role: Role) -> str:
    return f"""\
你正在参与一场狼人杀游戏。

【你的身份】
你是 {pid}号玩家，名叫{name}。
你的秘密身份是：{ROLE_NAME_CN[role]}"""


def _output_format() -> str:
    return """\
【输出规范】
- 发言时：用第一人称，口语化，100字以内，不要主动透露自己的角色。
- 投票/行动时：严格按要求格式返回 JSON，不要有多余的文字。"""


# ── 角色专属动态信息 ──────────────────────────────────────────────────────

def _role_extra(role: Role, ctx: dict) -> str:
    if role == Role.WEREWOLF:
        allies = ctx.get("allies", [])
        if allies:
            ally_str = "、".join(allies)
            return f"【同伴】（绝对保密）\n你的狼人同伴是：{ally_str}。夜晚可与同伴合议后共同决定击杀目标。"
        return "【同伴】\n你是场上唯一的狼人，独立行动。"

    if role == Role.SEER:
        checks: dict = ctx.get("checks", {})
        if checks:
            lines = [f"  {n}：{r}" for n, r in checks.items()]
            check_str = "\n".join(lines)
            return f"【已查验信息】（仅你可见）\n{check_str}"
        return "【已查验信息】\n暂无。每晚可查验一名玩家的真实阵营。"

    if role == Role.WITCH:
        save = "剩余 ✓" if ctx.get("save_left", True) else "已用完"
        poison = "剩余 ✓" if ctx.get("poison_left", True) else "已用完"
        return f"【药水库存】\n  解药：{save}\n  毒药：{poison}"

    if role == Role.GUARD:
        last = ctx.get("last_protect")
        note = f"上一晚你保护了 {last}，今晚不能再保护同一人。" if last else "今晚可保护任意存活玩家。"
        return f"【守卫信息】\n{note}"

    if role == Role.HUNTER:
        return "【猎人技能】\n若你被狼人杀死或被投票放逐，可立即射杀场上任意一名存活玩家。"

    return ""  # VILLAGER 无特殊信息


# ── 角色策略指南 ──────────────────────────────────────────────────────────

def _role_strategy(role: Role) -> str:
    strategies = {
        Role.WEREWOLF: """\
【策略指南】
白天：表现得像普通村民，主动但不抢眼地参与讨论。对真正的神职（预言家、女巫）
制造合理的怀疑，但不要过于明显。保护暴露风险较高的同伴时要给出充分理由。
夜晚：与同伴商议，优先猎杀预言家等威胁最大的神职。
发言风格：自然随和，偶尔表达对他人的疑虑，语气不要过于笃定。""",

        Role.SEER: """\
【策略指南】
不要过早暴露身份，先积累 1-2 条查验信息。当发现狼人时，考虑以"跳预言家"
的方式站出来引导好人投票，但要准备好应对狼人的反跳。
每晚优先查验场上最可疑或最关键的玩家。""",

        Role.WITCH: """\
【策略指南】
解药：优先留到关键时刻（如预言家被杀）再使用，第一晚谨慎用药。
毒药：确定某人是狼人后再使用，不要轻易浪费。
白天发言时可以适当暗示你是女巫，威慑狼人，但不要随意跳身份。""",

        Role.HUNTER: """\
【策略指南】
白天发言中可以留下隐晦暗示（如"我死了也不亏"），让狼人有所顾虑。
被杀时，尽量射杀你最确定的狼人目标，用生命换取好人阵营的优势。""",

        Role.GUARD: """\
【策略指南】
优先保护神职（预言家、女巫）。若你知道预言家是谁，尽量守护。
不能连续两晚守护同一人，要灵活变换。白天不要主动暴露自己是守卫。""",

        Role.VILLAGER: """\
【策略指南】
仔细聆听每个人的发言，寻找逻辑漏洞和前后矛盾。
发言时分享你的推理过程，引导好人阵营形成共识。
投票时相信神职的指引，不要被狼人的话术带偏。""",
    }
    return strategies.get(role, "")
