"""
行动提示模板。
每个函数返回发送给 Agent 的 user 消息内容（字符串）。
"""
from game.state import GameState, Player


# ── 公共上下文构建 ────────────────────────────────────────────────────────

def build_game_context(state: GameState, pov_player_id: int) -> str:
    """构建该 Agent 视角的游戏状态摘要（不含私有信息）。"""
    alive = state.alive_players()
    dead  = [p for p in state.players if not p.is_alive]

    lines = [f"【当前状态 · 第{state.round}轮】"]
    lines.append(f"存活玩家（{len(alive)}人）：")
    for p in alive:
        marker = "← 你" if p.id == pov_player_id else ""
        lines.append(f"  {p.id}号 {p.name} {marker}")
    if dead:
        lines.append(f"已死亡：" + "、".join(f"{p.id}号{p.name}" for p in dead))
    return "\n".join(lines)


def build_event_log(events: list, max_events: int = 30) -> str:
    """将 Agent 收到的事件历史转为可读文本。"""
    recent = events[-max_events:]
    if not recent:
        return "【事件记录】\n（游戏刚开始，暂无记录）"
    lines = ["【事件记录】"]
    for e in recent:
        lines.append(f"  [第{e.round}轮] {e.content}")
    return "\n".join(lines)


# ── 白天行动模板 ──────────────────────────────────────────────────────────

def speak_prompt(state: GameState, pov_id: int, hint: str = "") -> str:
    """白天发言提示。"""
    ctx = build_game_context(state, pov_id)
    instruction = "现在轮到你发言。"
    if hint:
        instruction += f" {hint}"
    instruction += "\n请发表你对当前局势的看法，表达你的怀疑或立场（100字以内）。"
    return f"{ctx}\n\n{instruction}"


def last_words_prompt(state: GameState, pov_id: int, death_cause: str) -> str:
    """遗言提示。"""
    ctx = build_game_context(state, pov_id)
    return (
        f"{ctx}\n\n"
        f"你刚刚{death_cause}，现在可以说遗言（50字以内）。\n"
        f"你可以揭示信息、指认玩家，或留下任何你想说的话。"
    )


def vote_prompt(state: GameState, pov_id: int) -> str:
    """投票提示，要求返回 JSON。"""
    alive = [p for p in state.alive_players() if p.id != pov_id]
    candidates = "、".join(f"{p.id}号{p.name}" for p in alive)
    ctx = build_game_context(state, pov_id)
    return (
        f"{ctx}\n\n"
        f"现在进行投票放逐。可投票的玩家：{candidates}\n"
        f"请选择你最想放逐的一名玩家，以如下 JSON 格式回复（不要有其他文字）：\n"
        f'{{"vote": 玩家编号, "reason": "30字以内理由"}}'
    )


# ── 夜间行动模板 ──────────────────────────────────────────────────────────

def wolf_discuss_prompt(state: GameState, wolf_id: int, ally_names: list[str]) -> str:
    """狼人夜间讨论与击杀决策。"""
    targets = [p for p in state.alive_players() if p.role.value != "werewolf"]
    target_str = "、".join(f"{p.id}号{p.name}" for p in targets)
    allies_str = "、".join(ally_names) if ally_names else "无（你是唯一狼人）"
    return (
        f"【夜晚·狼人行动 · 第{state.round}轮】\n"
        f"你的同伴：{allies_str}\n"
        f"可击杀的目标（非狼人存活玩家）：{target_str}\n\n"
        f"请先简短分析今晚应击杀谁（威胁最大的好人），再给出最终决定。\n"
        f"以 JSON 格式回复：\n"
        f'{{"analysis": "简短分析", "kill": 玩家编号}}'
    )


def seer_check_prompt(state: GameState, seer_id: int) -> str:
    """预言家查验提示。"""
    targets = [p for p in state.alive_players() if p.id != seer_id]
    target_str = "、".join(f"{p.id}号{p.name}" for p in targets)
    return (
        f"【夜晚·预言家查验 · 第{state.round}轮】\n"
        f"可查验的玩家：{target_str}\n\n"
        f"请选择一名玩家进行查验。以 JSON 格式回复：\n"
        f'{{"check": 玩家编号, "reason": "30字以内理由"}}'
    )


def witch_action_prompt(
    state: GameState,
    witch_id: int,
    killed_player_name: str | None,
    save_left: bool,
    poison_left: bool,
) -> str:
    """女巫夜间决策提示。"""
    lines = [f"【夜晚·女巫行动 · 第{state.round}轮】"]

    if killed_player_name and save_left:
        lines.append(f"今晚被狼人击杀的是：{killed_player_name}（你有解药，可以救他/她）。")
    elif killed_player_name:
        lines.append(f"今晚被狼人击杀的是：{killed_player_name}（你的解药已用完）。")
    else:
        lines.append("今晚没有玩家被击杀（或已被守卫保护）。")

    lines.append(f"解药：{'剩余' if save_left else '已用'} | 毒药：{'剩余' if poison_left else '已用'}")

    if poison_left:
        alive_others = [p for p in state.alive_players() if p.id != witch_id]
        poison_targets = "、".join(f"{p.id}号{p.name}" for p in alive_others)
        lines.append(f"可毒杀的玩家：{poison_targets}")

    lines.append(
        "\n请做出决定，以 JSON 格式回复（不要有其他文字）：\n"
        '{"save": true/false, "poison": 玩家编号或null, "reason": "简短理由"}'
    )
    return "\n".join(lines)


def guard_protect_prompt(state: GameState, guard_id: int, last_protect_id: int | None) -> str:
    """守卫保护提示。"""
    targets = [
        p for p in state.alive_players()
        if p.id != last_protect_id  # 不能连续保护同一人
    ]
    target_str = "、".join(f"{p.id}号{p.name}" for p in targets)
    note = f"（上晚保护了{last_protect_id}号，今晚不可再选）" if last_protect_id else ""
    return (
        f"【夜晚·守卫行动 · 第{state.round}轮】{note}\n"
        f"可保护的玩家：{target_str}\n\n"
        f"请选择今晚要保护的玩家。以 JSON 格式回复：\n"
        f'{{"protect": 玩家编号, "reason": "30字以内理由"}}'
    )


def hunter_shoot_prompt(state: GameState, hunter_id: int) -> str:
    """猎人射击提示。"""
    targets = [p for p in state.alive_players() if p.id != hunter_id]
    target_str = "、".join(f"{p.id}号{p.name}" for p in targets)
    return (
        f"【猎人技能触发】\n"
        f"你已死亡，现在可以射杀一名存活玩家为好人阵营复仇。\n"
        f"存活玩家：{target_str}\n\n"
        f"以 JSON 格式回复：\n"
        f'{{"shoot": 玩家编号, "reason": "30字以内理由"}}'
    )
