"""
main.py — 启动一局完整的 AI 狼人杀游戏
用法：
  py main.py                        # 标准 9 人局
  py main.py --preset quick_6       # 6 人快速局
  py main.py --preset debug_4       # 4 人调试局
"""
import asyncio
import sys
import os

os.environ.setdefault("PYTHONIOENCODING", "utf-8")

import config
from game.engine import GameEngine


async def main() -> None:
    preset = config.DEFAULT_PRESET
    for i, arg in enumerate(sys.argv[1:]):
        if arg == "--preset" and i + 1 < len(sys.argv) - 1:
            preset = sys.argv[i + 2]

    if preset not in config.ROLE_PRESETS:
        print(f"未知 preset: {preset}，可用：{list(config.ROLE_PRESETS.keys())}")
        sys.exit(1)

    engine = GameEngine(preset=preset, verbose=True)
    winner = await engine.run()
    if winner:
        from game.roles import Camp
        cn = "好人阵营" if winner == Camp.VILLAGER else "狼人阵营"
        print(f"\n最终获胜方：{cn}")


if __name__ == "__main__":
    asyncio.run(main())
