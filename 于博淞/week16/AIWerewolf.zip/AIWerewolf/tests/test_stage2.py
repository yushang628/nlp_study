"""
Stage 2 验证脚本 —— BaseAgent & LLM 接入
运行：
  py tests/test_stage2.py          # 单元测试（无需 API Key）
  py tests/test_stage2.py --live   # 含真实 LLM 调用（需要 .env 中的 API Key）
"""
import sys, os, asyncio, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

LIVE = "--live" in sys.argv  # 是否进行真实 LLM 调用


def section(title: str) -> None:
    print(f"\n{'='*55}")
    print(f"  {title}")
    print('='*55)


# ── 1. Prompt 生成 ────────────────────────────────────────────────────────

def test_role_prompts():
    section("1. 角色 System Prompt 生成")
    from prompts.role_prompts import build_system_prompt
    from game.roles import Role

    cases = [
        (Role.WEREWOLF, {"allies": ["阿丽", "阿强"]}),
        (Role.SEER,     {"checks": {"阿明": "狼人", "阿伟": "好人"}}),
        (Role.WITCH,    {"save_left": True, "poison_left": False}),
        (Role.GUARD,    {"last_protect": 3}),
        (Role.HUNTER,   {}),
        (Role.VILLAGER, {}),
    ]
    for role, ctx in cases:
        prompt = build_system_prompt(1, "测试", role, ctx)
        assert len(prompt) > 50, f"{role.value} prompt 太短"
        assert role.value != "werewolf" or "同伴" in prompt
        print(f"  {role.value:10s}  prompt 长度={len(prompt):4d}字符  [OK]")
    print("  [PASS]")


# ── 2. Action 模板 ────────────────────────────────────────────────────────

def test_action_templates():
    section("2. Action Prompt 模板")
    import config
    from game.state import GameState
    from prompts.action_templates import (
        speak_prompt, vote_prompt, wolf_discuss_prompt,
        seer_check_prompt, witch_action_prompt, guard_protect_prompt,
    )

    state = GameState.from_role_config(config.ROLE_PRESETS["quick_6"], config.PLAYER_NAMES)
    wolf  = next(p for p in state.players if p.role.value == "werewolf")
    seer  = next(p for p in state.players if p.role.value == "seer")
    witch = next(p for p in state.players if p.role.value == "witch")

    sp = speak_prompt(state, wolf.id, "你是第一个发言的")
    assert "第一个发言" in sp
    print(f"  speak_prompt       长度={len(sp):4d}  [OK]")

    vp = vote_prompt(state, wolf.id)
    assert "vote" in vp and "JSON" in vp
    print(f"  vote_prompt        长度={len(vp):4d}  [OK]")

    wd = wolf_discuss_prompt(state, wolf.id, ["阿明"])
    assert "kill" in wd
    print(f"  wolf_discuss_prompt长度={len(wd):4d}  [OK]")

    sc = seer_check_prompt(state, seer.id)
    assert "check" in sc
    print(f"  seer_check_prompt  长度={len(sc):4d}  [OK]")

    wa = witch_action_prompt(state, witch.id, "阿强", True, True)
    assert "save" in wa and "poison" in wa
    print(f"  witch_action_prompt长度={len(wa):4d}  [OK]")

    gp = guard_protect_prompt(state, 1, 2)
    assert "protect" in gp
    print(f"  guard_protect_prompt长度={len(gp):4d} [OK]")

    print("  [PASS]")


# ── 3. BaseAgent 实例化 & 辅助方法 ────────────────────────────────────────

def test_base_agent_unit():
    section("3. BaseAgent 实例化 & JSON 解析")
    import config
    from game.state import GameState
    from agents.base import BaseAgent
    from game.roles import Role
    from game.state import Player

    player = Player(id=1, name="测试狼", role=Role.WEREWOLF)

    # 跳过 LLM 客户端初始化（需要 API Key），仅测试辅助方法
    # 直接用 _extract_json
    cases = [
        ('{"vote": 3, "reason": "最可疑"}',   {"vote": 3, "reason": "最可疑"}),
        ('分析后：{"vote": 5, "reason": ""}',  {"vote": 5, "reason": ""}),
        ('```json\n{"kill": 2}\n```',           {"kill": 2}),
        ("完全无效文本",                        {}),
    ]
    for raw, expected in cases:
        result = BaseAgent._extract_json(raw)
        assert result == expected, f"输入:{raw!r} 预期:{expected} 得到:{result}"
        print(f"  _extract_json OK: {raw[:40]!r} → {result}")
    print("  [PASS]")


# ── 4. 事件注入 ───────────────────────────────────────────────────────────

def test_event_injection():
    section("4. 事件注入 & 上下文构建")
    import config
    from game.state import GameState
    from game.events import EventBus, EventType, Visibility
    from game.state import Player
    from game.roles import Role
    from prompts.action_templates import build_event_log

    bus = EventBus()
    bus.emit(EventType.GAME_START,   0, Visibility.PUBLIC,  "游戏开始！")
    bus.emit(EventType.WOLF_DISCUSS, 1, Visibility.WOLF,    "狼人讨论：杀阿梅")
    bus.emit(EventType.PLAYER_SPEECH,1, Visibility.PUBLIC,  "阿明说：我觉得5号有问题")

    wolf = Player(id=2, name="阿丽", role=Role.WEREWOLF)
    wolf_events = bus.events_for(wolf.id, wolf.role.value)
    assert len(wolf_events) == 3   # 看到全部（public + wolf）

    seer = Player(id=3, name="阿强", role=Role.SEER)
    seer_events = bus.events_for(seer.id, seer.role.value)
    assert len(seer_events) == 2   # 只看到 public（看不到 wolf_discuss）

    log = build_event_log(wolf_events)
    assert "狼人讨论" in log

    print(f"  狼人可见事件数={len(wolf_events)}  预言家可见事件数={len(seer_events)}")
    print(f"  事件日志片段: {log[:80]}...")
    print("  [PASS]")


# ── 5. 真实 LLM 调用（--live 模式）───────────────────────────────────────

async def test_live_llm():
    section("5. 真实 LLM 调用（qwen-plus）")
    import config
    from game.state import GameState, Player
    from game.roles import Role
    from game.events import GameEvent, EventType, Visibility
    from agents.base import BaseAgent

    if not config.DASHSCOPE_API_KEY:
        print("  跳过：未设置 DASHSCOPE_API_KEY")
        return

    state = GameState.from_role_config(config.ROLE_PRESETS["quick_6"], config.PLAYER_NAMES)
    wolf = next(p for p in state.players if p.role == Role.WEREWOLF)
    agent = BaseAgent(wolf)
    agent.role_context = {"allies": ["阿丽"]}

    # 注入一条公开事件
    fake_event = GameEvent(
        event_id=1, event_type=EventType.GAME_START, round=0,
        visibility=Visibility.PUBLIC, content="游戏开始！"
    )
    agent.receive_event(fake_event)

    print(f"  Agent: {agent}")
    print(f"  调用 speak()（白天发言）...")
    state.round = 1
    reply = await agent.speak(state, hint="你是第一个发言的玩家")
    print(f"  回复: {reply[:150]}")
    assert len(reply) > 5, "回复过短，LLM 可能未正常响应"

    print(f"\n  调用 vote()...")
    vid, reason = await agent.vote(state)
    print(f"  投票目标: {vid}号  理由: {reason}")
    alive_ids = {p.id for p in state.alive_players() if p.id != wolf.id}
    assert vid in alive_ids, f"投票目标 {vid} 不在存活玩家中"

    print("  [PASS] 真实 LLM 调用成功")


# ── main ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Stage 2 验证  {'（含 LLM 实调）' if LIVE else '（单元测试）'}")
    try:
        test_role_prompts()
        test_action_templates()
        test_base_agent_unit()
        test_event_injection()
        if LIVE:
            asyncio.run(test_live_llm())
        print("\n" + "="*55)
        print("  全部通过 ✓  Stage 2 BaseAgent 正常")
        print("="*55)
    except AssertionError as e:
        print(f"\n[FAIL] {e}")
        sys.exit(1)
