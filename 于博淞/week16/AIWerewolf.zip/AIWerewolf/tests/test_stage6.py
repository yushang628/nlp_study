"""
Stage 6 验证脚本 —— 自进化系统
用法：
  py tests/test_stage6.py           # 单元测试（无 LLM）
  py tests/test_stage6.py --live    # 真实 LLM：完整 1 周期进化
"""
import sys, os, asyncio, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

LIVE = "--live" in sys.argv


def section(title: str) -> None:
    print(f"\n{'='*55}")
    print(f"  {title}")
    print('='*55)


# ── 1. StrategyStore ──────────────────────────────────────────────────────

def test_strategy_store():
    section("1. StrategyStore — 初始化与版本管理")
    import tempfile, shutil
    from evolution.strategy_store import StrategyStore
    from game.roles import Role

    with tempfile.TemporaryDirectory() as tmpdir:
        store = StrategyStore(store_dir=tmpdir)

        # v0 应被自动创建
        assert store.get_current_version() == 0
        strats = store.load_strategies(0)
        assert len(strats) == len(list(Role)), \
            f"v0 应包含 {len(list(Role))} 个角色，实际 {len(strats)}"
        print(f"  v0 角色数: {len(strats)}  [OK]")

        # 保存 v1
        new_strats = dict(strats)
        new_strats["werewolf"] = "测试狼人新策略"
        store.save_version(new_strats, 1, ["replay_test.json"])
        assert store.get_current_version() == 1
        loaded = store.load_strategies(1)
        assert loaded["werewolf"] == "测试狼人新策略"
        print(f"  v1 保存与加载: werewolf={loaded['werewolf'][:20]}  [OK]")

        # list_all
        all_v = store.list_all()
        assert len(all_v) == 2
        print(f"  版本列表长度: {len(all_v)}  [OK]")

    print("  [PASS]")


# ── 2. ReplayAnalyzer（无 LLM）───────────────────────────────────────────

def test_replay_analyzer_unit():
    section("2. ReplayAnalyzer — 本地解析（无 LLM）")
    from evolution.replay_analyzer import ReplayAnalyzer, AnalysisResult
    import config

    analyzer = ReplayAnalyzer()

    # 构造一个最小 replay
    fake_replay = {
        "game_id": "test_001",
        "winner": "villager",
        "winner_reason": "所有狼人已被消灭",
        "rounds": 2,
        "players": [
            {"id": 1, "name": "阿明", "role": "werewolf", "survived": False},
            {"id": 2, "name": "阿丽", "role": "seer",     "survived": True},
            {"id": 3, "name": "阿强", "role": "villager", "survived": True},
        ],
        "timeline": [
            {"type": "event",    "round": 1, "phase": "night_wolf",
             "content": "狼人决定击杀2号"},
            {"type": "decision", "round": 1, "phase": "day_discuss",
             "player": "阿丽", "action": "speak",
             "content": "我是预言家，1号是狼人！", "reasoning": "查验结果"},
            {"type": "decision", "round": 1, "phase": "day_vote",
             "player": "阿强", "action": "vote",
             "content": "投1号", "reasoning": "信任预言家"},
            {"type": "settlement", "round": 1, "summary": "1号阿明死亡"},
            {"type": "event",    "round": 1, "phase": "game_end",
             "content": "好人获胜"},
        ],
    }

    # 测试 compact_timeline（不调用 LLM）
    compact = analyzer.compact_timeline(fake_replay["timeline"])
    assert "阿丽" in compact
    assert "speak" in compact
    print(f"  compact_timeline 长度: {len(compact)}  [OK]")

    # 测试 _build_prompt（不调用 LLM）
    prompt = analyzer._build_prompt(fake_replay)
    assert "好人阵营" in prompt
    assert "updated_strategies" in prompt
    print(f"  _build_prompt 长度: {len(prompt)}  [OK]")

    # 测试 _parse（模拟 LLM 返回）
    mock_llm_output = json.dumps({
        "key_moment": "阿丽跳出预言家引导投票",
        "winner_strategy": "预言家及时暴露信息",
        "loser_mistakes": "狼人击杀了预言家但被识破",
        "role_feedback": {
            "werewolf": {"strength": "主动出击", "weakness": "目标选择不当", "suggestion": "首夜避开神职"},
            "seer": {"strength": "及时指路", "weakness": "暴露过早", "suggestion": "积累2条信息再跳"},
        },
        "updated_strategies": {
            "werewolf": "优化后的狼人策略：首夜选择低威胁目标，第二晚再击杀神职...",
            "seer": "优化后的预言家策略：积累至少2条查验信息后再选择跳身份...",
        },
    }, ensure_ascii=False)

    result = analyzer._parse(fake_replay, mock_llm_output)
    assert result.winner == "villager"
    assert result.key_moment == "阿丽跳出预言家引导投票"
    assert "werewolf" in result.role_feedback
    assert "seer"     in result.updated_strategies
    print(f"  _parse: winner={result.winner} roles={list(result.role_feedback.keys())}  [OK]")
    print("  [PASS]")


# ── 3. Leaderboard ────────────────────────────────────────────────────────

def test_leaderboard():
    section("3. Leaderboard — 记录与展示")
    import tempfile, os
    from evolution.leaderboard import Leaderboard

    with tempfile.TemporaryDirectory() as tmpdir:
        stats_path = os.path.join(tmpdir, "stats.json")
        lb = Leaderboard(stats_path=stats_path)

        lb.record_game(0, "villager", 2)
        lb.record_game(0, "werewolf", 3)
        lb.record_game(0, "villager", 2)
        lb.record_game(1, "villager", 2)
        lb.record_game(1, "villager", 1)

        stats = lb.get_stats()
        assert stats["v0"]["total_games"] == 3
        assert stats["v0"]["villager_wins"] == 2
        assert stats["v1"]["total_games"] == 2
        print(f"  v0: {stats['v0']}  [OK]")
        print(f"  v1: {stats['v1']}  [OK]")

        print("\n  Leaderboard 渲染：")
        lb.print_table()
    print("  [PASS]")


# ── 4. 策略注入端到端（无 LLM，用 MockAgent）────────────────────────────

async def test_strategy_injection():
    section("4. 策略注入端到端（MockAgent + 自定义策略）")
    import config
    from game.engine import GameEngine
    from agents.base import BaseAgent
    from game.roles import Role

    class MockAgent(BaseAgent):
        def __init__(self, player, strategy_override=None):
            self.player = player
            self.event_history = []
            self.role_context = {}
            self.strategy_override = strategy_override

        def receive_event(self, e): self.event_history.append(e)
        async def speak(self, s, h=""): return "[mock发言]"
        async def last_words(self, s, c): return "[mock遗言]"
        async def vote(self, s):
            others = [p for p in s.alive_players() if p.id != self.player.id]
            return (others[0].id if others else self.player.id), "mock投票"
        async def hunter_shoot(self, s):
            others = [p for p in s.alive_players() if p.id != self.player.id]
            return others[0].id, "mock射击"
        async def night_action(self, s):
            r = self.player.role
            if r == Role.WEREWOLF:
                v = [p.id for p in s.alive_players() if p.role != Role.WEREWOLF]
                return {"kill": v[0] if v else None, "analysis": "mock"}
            if r == Role.SEER:
                v = [p.id for p in s.alive_players() if p.id != self.player.id]
                return {"check": v[0] if v else None}
            if r == Role.WITCH: return {"save": False, "poison": None}
            if r == Role.GUARD:
                v = [p.id for p in s.alive_players()]
                return {"protect": v[0] if v else None}
            return {}

    # 准备自定义策略
    custom_strategies = {"werewolf": "自进化测试：首夜击杀预言家优先。"}

    engine = GameEngine(preset="debug_4", verbose=False,
                        strategy_overrides=custom_strategies)
    engine._setup()

    # 替换 Agent
    overrides = {}
    for pid, agent in engine.agents.items():
        mock = MockAgent(agent.player,
                         strategy_override=custom_strategies.get(
                             agent.player.role.value))
        mock.role_context = agent.role_context.copy()
        overrides[pid] = mock
    engine.agents = overrides

    # 验证狼人 Agent 已注入策略
    wolf_agent = next(
        a for a in engine.agents.values()
        if a.player.role == Role.WEREWOLF
    )
    assert wolf_agent.strategy_override == custom_strategies["werewolf"]
    print(f"  狼人 strategy_override: {wolf_agent.strategy_override[:30]}...  [OK]")

    # 跑完整局
    winner = await engine.run()
    assert winner is not None
    print(f"  对局完成，胜者: {winner.value}  [PASS]")


# ── 5. 真实 LLM 进化一周期 ──────────────────────────────────────────────

async def test_live_evolution():
    section("5. 真实 LLM 进化（1周期×2局）")
    import config
    if not config.DASHSCOPE_API_KEY:
        print("  跳过：未设置 DASHSCOPE_API_KEY")
        return

    from evolution.evolution_runner import EvolutionRunner
    runner = EvolutionRunner(preset="debug_4")
    await runner.run_cycle(games_per_cycle=2, cycles=1)

    store = runner.store
    new_v = store.get_current_version()
    assert new_v >= 1, f"进化后版本应 >=1，实际 {new_v}"
    new_strats = store.load_strategies(new_v)
    assert len(new_strats) > 0
    print(f"\n  策略版本: v{new_v}  角色数: {len(new_strats)}")
    for role, text in new_strats.items():
        print(f"    [{role}] {text[:50]}...")
    print("  [PASS]")


# ── main ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Stage 6 自进化验证  {'（含 LLM 进化周期）' if LIVE else '（单元测试）'}")
    try:
        test_strategy_store()
        test_replay_analyzer_unit()
        test_leaderboard()
        asyncio.run(test_strategy_injection())
        if LIVE:
            asyncio.run(test_live_evolution())
        print("\n" + "="*55)
        print("  全部通过 ✓  Stage 6 自进化系统正常")
        print("="*55)
    except Exception as e:
        import traceback; traceback.print_exc()
        sys.exit(1)
