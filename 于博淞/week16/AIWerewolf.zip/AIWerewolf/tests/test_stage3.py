"""
Stage 3 验证脚本 —— 游戏引擎
用法：
  py tests/test_stage3.py           # 纯单元测试（无 LLM，用 MockAgent）
  py tests/test_stage3.py --live    # 真实 LLM，debug_4 快速局
"""
import sys, os, asyncio, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

LIVE = "--live" in sys.argv


def section(title: str) -> None:
    print(f"\n{'='*55}")
    print(f"  {title}")
    print('='*55)


# ── MockAgent：无 LLM 调用，行为完全确定 ─────────────────────────────────

class MockAgent:
    """替代 BaseAgent 用于单元测试，所有行动均预设。"""
    def __init__(self, player, kill_target=None, vote_target=None,
                 check_target=None, witch_save=False, witch_poison=None,
                 protect=None):
        self.player = player
        self.event_history = []
        self.role_context = {}
        self._kill = kill_target
        self._vote = vote_target
        self._check = check_target
        self._witch_save = witch_save
        self._witch_poison = witch_poison
        self._protect = protect

    def receive_event(self, event):
        self.event_history.append(event)

    async def speak(self, state, hint=""):
        return f"[{self.player.name}测试发言]"

    async def last_words(self, state, cause):
        return f"[{self.player.name}遗言]"

    async def vote(self, state):
        alive_others = [p for p in state.alive_players() if p.id != self.player.id]
        if not alive_others:
            return (self.player.id, "无人可投")
        vid = self._vote if self._vote in {p.id for p in alive_others} else alive_others[0].id
        return vid, "测试投票"

    async def hunter_shoot(self, state):
        alive_others = [p for p in state.alive_players() if p.id != self.player.id]
        return alive_others[0].id, "猎人测试射击"

    async def night_action(self, state):
        from game.roles import Role
        r = self.player.role
        if r == Role.WEREWOLF:
            valid = [p.id for p in state.alive_players() if p.role != Role.WEREWOLF]
            kill = self._kill if self._kill in valid else (valid[0] if valid else None)
            return {"kill": kill, "analysis": "测试击杀"}
        if r == Role.SEER:
            valid = [p.id for p in state.alive_players() if p.id != self.player.id]
            chk = self._check if self._check in valid else (valid[0] if valid else None)
            return {"check": chk}
        if r == Role.WITCH:
            return {"save": self._witch_save, "poison": self._witch_poison}
        if r == Role.GUARD:
            valid = [p.id for p in state.alive_players()]
            return {"protect": self._protect if self._protect in valid else valid[0]}
        return {}


# ── 1. 引擎初始化 ─────────────────────────────────────────────────────────

def test_engine_setup():
    section("1. 引擎初始化")
    from game.engine import GameEngine
    engine = GameEngine(preset="debug_4", verbose=False)
    engine._setup()

    assert len(engine.state.players) == 4
    assert len(engine.agents) == 4
    wolves = [p for p in engine.state.players if p.role.value == "werewolf"]
    assert len(wolves) == 1, f"debug_4 应有 1 只狼，得到 {len(wolves)}"
    print(f"  玩家数={len(engine.state.players)},  Agent数={len(engine.agents)}")
    for p in engine.state.players:
        print(f"    {p.id}号 {p.name} — {p.role.value}")
    print("  [PASS]")


# ── 2. 夜间结算逻辑（纯 Python） ─────────────────────────────────────────

def test_night_settlement():
    section("2. 夜间结算逻辑")
    from game.engine import GameEngine
    from game.state import NightRecord
    import config

    def make_engine():
        eng = GameEngine(preset="quick_6", verbose=False)
        eng._setup()
        return eng

    # case A: 狼人击杀，无保护 → 死亡
    eng = make_engine()
    eng.state.round = 1
    target = [p for p in eng.state.players if p.role.value != "werewolf"][0]
    eng.state.night_record = NightRecord(round=1, wolf_kill_target=target.id)
    eng._settle_night()
    assert not eng.state.get_player(target.id).is_alive, "无保护时应死亡"
    print(f"  case A: 击杀无保护 → {target.name} 死亡  [OK]")

    # case B: 守卫保护 → 存活
    eng = make_engine()
    eng.state.round = 1
    target = [p for p in eng.state.players if p.role.value != "werewolf"][0]
    eng.state.night_record = NightRecord(
        round=1, wolf_kill_target=target.id, guard_protect_target=target.id
    )
    eng._settle_night()
    assert eng.state.get_player(target.id).is_alive, "守卫保护时应存活"
    print(f"  case B: 守卫保护 → {target.name} 存活  [OK]")

    # case C: 女巫解药 → 存活
    eng = make_engine()
    eng.state.round = 1
    target = [p for p in eng.state.players if p.role.value != "werewolf"][0]
    eng.state.night_record = NightRecord(
        round=1, wolf_kill_target=target.id, witch_save=True
    )
    eng._settle_night()
    assert eng.state.get_player(target.id).is_alive, "女巫救药时应存活"
    print(f"  case C: 女巫解药 → {target.name} 存活  [OK]")

    # case D: 女巫毒药额外杀人
    eng = make_engine()
    eng.state.round = 1
    villagers = [p for p in eng.state.players if p.role.value == "villager"]
    assert len(villagers) >= 2
    eng.state.night_record = NightRecord(
        round=1, wolf_kill_target=villagers[0].id, witch_poison_target=villagers[1].id
    )
    eng._settle_night()
    assert not eng.state.get_player(villagers[0].id).is_alive
    assert not eng.state.get_player(villagers[1].id).is_alive
    print(f"  case D: 狼杀+毒药 → 两人死亡  [OK]")

    print("  [PASS]")


# ── 3. 投票计票 ───────────────────────────────────────────────────────────

def test_vote_counting():
    section("3. 投票计票逻辑")
    from collections import Counter
    # 模拟投票统计（不涉及 LLM）
    votes = {1: 3, 2: 3, 3: 5, 4: 5, 5: 1}  # 3、4号平局最高票
    counter = Counter(votes)
    max_v = max(counter.values())
    top = [pid for pid, cnt in counter.items() if cnt == max_v]
    assert set(top) == {3, 4}, f"预期平局{3,4}，得到{top}"
    print(f"  平局情况：top={top}（平局应无放逐）  [OK]")

    votes2 = {1: 1, 2: 1, 3: 4}
    counter2 = Counter(votes2)
    max_v2 = max(counter2.values())
    top2 = [pid for pid, cnt in counter2.items() if cnt == max_v2]
    assert top2 == [3]
    print(f"  单一最高：top={top2}（应放逐{top2[0]}号）  [OK]")
    print("  [PASS]")


# ── 4. Mock 全局游戏（无 LLM）─────────────────────────────────────────────

async def test_mock_full_game():
    section("4. MockAgent 全局对局（无 LLM）")
    from game.engine import GameEngine
    from game.state import GameState
    from game.roles import Role
    import config

    # 用 debug_4：1狼+1预言家+2村民
    engine = GameEngine(preset="debug_4", verbose=False)
    # 先 _setup 获取玩家分配，再替换 Agent
    engine._setup()

    overrides = {}
    for pid, agent in engine.agents.items():
        p = agent.player
        valid_others = [x.id for x in engine.state.players if x.id != p.id]
        target = valid_others[0] if valid_others else p.id
        overrides[pid] = MockAgent(
            p,
            kill_target=target,
            vote_target=target,
            check_target=target,
        )
        overrides[pid].role_context = agent.role_context.copy()

    engine.agents = overrides

    winner = await engine.run()
    assert winner is not None, "游戏应有胜者"
    print(f"  对局结束，胜者: {winner.value}  轮数: {engine.state.round}")
    print("  [PASS]")


# ── 5. 真实 LLM 全局对局 ──────────────────────────────────────────────────

async def test_live_full_game():
    section("5. 真实 LLM 全局对局（debug_4）")
    import config
    if not config.DASHSCOPE_API_KEY:
        print("  跳过：未设置 DASHSCOPE_API_KEY")
        return

    from game.engine import GameEngine
    engine = GameEngine(preset="debug_4", verbose=True)
    winner = await engine.run()
    assert winner is not None
    print(f"\n  对局结束，胜者: {winner.value}  [PASS]")


# ── main ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Stage 3 引擎验证  {'（含真实 LLM 对局）' if LIVE else '（Mock + 单元测试）'}")
    try:
        test_engine_setup()
        test_night_settlement()
        test_vote_counting()
        asyncio.run(test_mock_full_game())
        if LIVE:
            asyncio.run(test_live_full_game())
        print("\n" + "="*55)
        print("  全部通过 ✓  Stage 3 引擎正常")
        print("="*55)
    except AssertionError as e:
        import traceback
        traceback.print_exc()
        sys.exit(1)
