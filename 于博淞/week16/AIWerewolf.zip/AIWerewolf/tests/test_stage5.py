"""
Stage 5 验证脚本 —— 终端 UI + 引擎集成
用法：
  py tests/test_stage5.py           # 视觉冒烟测试（无 LLM）
  py tests/test_stage5.py --live    # 真实 LLM 完整对局
"""
import sys, os, asyncio
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("PYTHONIOENCODING", "utf-8")

LIVE = "--live" in sys.argv


def section(title: str) -> None:
    print(f"\n{'='*55}")
    print(f"  {title}")
    print('='*55)


# ── 复用 Stage3 MockAgent ────────────────────────────────────────────────

class MockAgent:
    def __init__(self, player, **kw):
        self.player = player
        self.event_history = []
        self.role_context = {}
    def receive_event(self, e): self.event_history.append(e)
    async def speak(self, s, h=""): return f"[{self.player.name}发言]"
    async def last_words(self, s, c): return f"[{self.player.name}遗言]"
    async def vote(self, s):
        others = [p for p in s.alive_players() if p.id != self.player.id]
        return (others[0].id if others else self.player.id), "测试投票"
    async def hunter_shoot(self, s):
        others = [p for p in s.alive_players() if p.id != self.player.id]
        return others[0].id, "测试射击"
    async def night_action(self, s):
        from game.roles import Role
        r = self.player.role
        if r == Role.WEREWOLF:
            v = [p.id for p in s.alive_players() if p.role != Role.WEREWOLF]
            return {"kill": v[0] if v else None, "analysis": "测试"}
        if r == Role.SEER:
            v = [p.id for p in s.alive_players() if p.id != self.player.id]
            return {"check": v[0] if v else None}
        if r == Role.WITCH:
            return {"save": False, "poison": None}
        if r == Role.GUARD:
            v = [p.id for p in s.alive_players()]
            return {"protect": v[0] if v else None}
        return {}


# ── 1. UI 组件渲染（无 LLM）─────────────────────────────────────────────

def test_ui_components():
    section("1. UI 组件渲染")
    import config
    from game.state import GameState
    from game.roles import Role, Camp
    from ui.terminal import GameUI

    state = GameState.from_role_config(config.ROLE_PRESETS["quick_6"],
                                       config.PLAYER_NAMES)
    ui = GameUI(verbose=True)

    print("\n--- game_start ---")
    ui.game_start(state, "quick_6")

    print("\n--- round_header ---")
    ui.round_header(2)

    print("\n--- phase_banner (夜/昼) ---")
    from game.state import Phase
    ui.phase_banner(Phase.NIGHT_WOLF)
    ui.phase_banner(Phase.DAY_DISCUSS)

    wolf = next(p for p in state.players if p.role == Role.WEREWOLF)
    seer = next(p for p in state.players if p.role == Role.SEER)

    print("\n--- night_wolf_choice ---")
    ui.night_wolf_choice(wolf.name, seer.id, seer.name)

    print("\n--- death_announce (有死亡) ---")
    ui.death_announce([seer.id], state)

    print("\n--- last_words ---")
    seer_player = state.get_player(seer.id)
    ui.last_words(seer_player, "我是预言家！1号是狼人，大家快放逐他！")

    print("\n--- discuss_header + player_speak ---")
    ui.discuss_header(len(state.alive_players()))
    ui.player_speak(wolf, "我觉得大家都很可疑，需要仔细观察。")

    print("\n--- vote_header + vote_cast + vote_result ---")
    ui.vote_header()
    ui.vote_cast(wolf, seer.id, seer.name, "发言逻辑有漏洞")
    tally = {seer.id: 3, wolf.id: 1}
    ui.vote_result(tally, state, seer.id)

    print("\n--- exile ---")
    ui.exile(seer_player)

    print("\n--- no_exile ---")
    ui.no_exile()

    print("\n--- death_announce (平安夜) ---")
    ui.death_announce([], state)

    # 模拟猎人触发
    from game.state import Player
    from game.roles import Role
    hunter_player = Player(id=99, name="测试猎人", role=Role.HUNTER)
    target_player = Player(id=98, name="测试目标", role=Role.VILLAGER)
    print("\n--- hunter_shoot ---")
    ui.hunter_shoot(hunter_player, target_player)

    # game_end
    from game.roles import Camp
    state.winner = Camp.VILLAGER
    state.winner_reason = "所有狼人已被消灭，好人阵营获胜！"
    state.round = 3
    state.get_player(wolf.id).is_alive = False
    print("\n--- game_end ---")
    ui.game_end(state)

    print("  [PASS] 所有 UI 组件无报错渲染")


# ── 2. Mock 全局对局（检查引擎+UI集成）──────────────────────────────────

async def test_mock_game_with_ui():
    section("2. Mock 对局 + UI 集成")
    from game.engine import GameEngine

    engine = GameEngine(preset="debug_4", verbose=True)
    engine._setup()
    overrides = {
        pid: MockAgent(a.player)
        for pid, a in engine.agents.items()
    }
    for pid, mock in overrides.items():
        mock.role_context = engine.agents[pid].role_context.copy()
    engine.agents = overrides

    winner = await engine.run()
    assert winner is not None, "游戏应有胜者"
    print(f"\n  胜者: {winner.value}  [PASS]")


# ── 3. Replay 文件验证 ────────────────────────────────────────────────────

async def test_replay_written():
    section("3. Replay 文件结构")
    import json, os
    from game.engine import GameEngine

    engine = GameEngine(preset="debug_4", verbose=False)
    engine._setup()
    overrides = {pid: MockAgent(a.player)
                 for pid, a in engine.agents.items()}
    for pid, m in overrides.items():
        m.role_context = engine.agents[pid].role_context.copy()
    engine.agents = overrides

    await engine.run()
    path = engine.logger.replay_path
    assert os.path.exists(path), f"Replay 文件未生成：{path}"

    with open(path, encoding="utf-8") as f:
        replay = json.load(f)

    required = {"game_id", "winner", "rounds", "players", "timeline"}
    missing  = required - set(replay.keys())
    assert not missing, f"Replay 缺少字段：{missing}"
    assert len(replay["players"]) == 4
    assert replay["rounds"] >= 1
    print(f"  Replay 路径: {path}")
    print(f"  字段齐全: {list(replay.keys())}")
    print(f"  玩家数: {len(replay['players'])}  轮数: {replay['rounds']}")
    print("  [PASS]")


# ── 4. 真实 LLM 完整对局 ──────────────────────────────────────────────────

async def test_live_game():
    section("4. 真实 LLM 完整对局（quick_6）")
    import config
    if not config.DASHSCOPE_API_KEY:
        print("  跳过：未设置 DASHSCOPE_API_KEY")
        return

    from game.engine import GameEngine
    engine = GameEngine(preset="quick_6", verbose=True)
    winner = await engine.run()
    assert winner is not None
    print(f"\n  对局结束，胜者: {winner.value}  [PASS]")


# ── main ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"Stage 5 UI 验证  {'（含 LLM 对局）' if LIVE else '（视觉冒烟 + Mock）'}")
    try:
        test_ui_components()
        asyncio.run(test_mock_game_with_ui())
        asyncio.run(test_replay_written())
        if LIVE:
            asyncio.run(test_live_game())
        print("\n" + "="*55)
        print("  全部通过 ✓  Stage 5 UI 正常")
        print("="*55)
    except Exception as e:
        import traceback; traceback.print_exc()
        sys.exit(1)
