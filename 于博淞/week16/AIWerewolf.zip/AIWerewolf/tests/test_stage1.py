"""
Stage 1 验证脚本 —— 数据模型 & 事件系统
运行：python -m tests.test_stage1
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from game.roles import Role, Camp, ROLE_CAMP, ROLE_NAME_CN
from game.state import GameState, Phase, Player
from game.events import EventBus, EventType, Visibility
import config


def section(title: str) -> None:
    print(f"\n{'='*50}")
    print(f"  {title}")
    print('='*50)


def test_role_meta():
    section("1. 角色元数据")
    for role in Role:
        camp = ROLE_CAMP[role]
        print(f"  {ROLE_NAME_CN[role]:4s}  阵营={camp.value}")
    # 验证所有非狼人角色都是好人阵营
    assert ROLE_CAMP[Role.WEREWOLF] == Camp.WEREWOLF
    for r in [Role.VILLAGER, Role.SEER, Role.WITCH, Role.HUNTER, Role.GUARD]:
        assert ROLE_CAMP[r] == Camp.VILLAGER
    print("  [PASS] 阵营映射正确")


def test_game_state_factory():
    section("2. GameState 工厂 & 玩家列表")
    state = GameState.from_role_config(
        config.ROLE_PRESETS["standard_9"],
        config.PLAYER_NAMES,
    )
    assert len(state.players) == 9
    wolf_count = sum(1 for p in state.players if p.role == Role.WEREWOLF)
    seer_count  = sum(1 for p in state.players if p.role == Role.SEER)
    assert wolf_count == 3, f"狼人应有3个，实际{wolf_count}"
    assert seer_count  == 1, f"预言家应有1个，实际{seer_count}"
    print(f"  共 {len(state.players)} 名玩家，狼人{wolf_count}，预言家{seer_count}")
    print(state.public_player_list())
    print("  [PASS] GameState 工厂正确")


def test_win_conditions():
    section("3. 胜负判定")

    # case A: 狼人全灭 → 村民胜
    state = GameState.from_role_config(config.ROLE_PRESETS["debug_4"], config.PLAYER_NAMES)
    wolf = next(p for p in state.players if p.role == Role.WEREWOLF)
    wolf.is_alive = False
    result = state.check_win()
    assert result == Camp.VILLAGER, f"预期村民胜，得到 {result}"
    print(f"  case A: 狼人全灭 → {result.value} [PASS]")

    # case B: 狼人数 >= 好人数 → 狼人胜
    state2 = GameState.from_role_config(config.ROLE_PRESETS["debug_4"], config.PLAYER_NAMES)
    villagers = [p for p in state2.players if p.role != Role.WEREWOLF]
    for p in villagers[:-1]:   # 保留1个好人，狼1 >= 好1
        p.is_alive = False
    result2 = state2.check_win()
    assert result2 == Camp.WEREWOLF, f"预期狼人胜，得到 {result2}"
    print(f"  case B: 狼人数≥好人数 → {result2.value} [PASS]")

    # case C: 均势（无结束）→ None
    state3 = GameState.from_role_config(config.ROLE_PRESETS["quick_6"], config.PLAYER_NAMES)
    result3 = state3.check_win()
    assert result3 is None
    print(f"  case C: 正常对局中 → None [PASS]")


def test_event_bus_visibility():
    section("4. 事件总线 & 可见性路由")
    bus = EventBus()
    state = GameState.from_role_config(config.ROLE_PRESETS["standard_9"], config.PLAYER_NAMES)

    wolf   = next(p for p in state.players if p.role == Role.WEREWOLF)
    seer   = next(p for p in state.players if p.role == Role.SEER)
    victim = next(p for p in state.players if p.role == Role.VILLAGER)

    # 公开事件
    bus.emit(EventType.GAME_START, 0, Visibility.PUBLIC, "游戏开始！")
    # 狼人专属
    bus.emit(EventType.WOLF_DISCUSS, 1, Visibility.WOLF, "狼人: 今晚杀谁？")
    # 私有（发给预言家）
    bus.emit(EventType.SEER_CHECK, 1, Visibility.PRIVATE,
             f"查验结果：{victim.name} 是 好人", recipient_id=seer.id)
    # 仅日志
    bus.emit(EventType.WOLF_KILL, 1, Visibility.LOG_ONLY,
             f"狼人选择击杀 {victim.name}", data={"target": victim.id})

    wolf_events = bus.events_for(wolf.id, wolf.role.value)
    seer_events  = bus.events_for(seer.id,  seer.role.value)

    wolf_types = {e.event_type for e in wolf_events}
    seer_types  = {e.event_type for e in seer_events}

    assert EventType.GAME_START  in wolf_types, "狼人应能看到公开事件"
    assert EventType.WOLF_DISCUSS in wolf_types, "狼人应能看到狼人专属事件"
    assert EventType.SEER_CHECK  not in wolf_types, "狼人不应看到预言家私有事件"
    assert EventType.WOLF_KILL   not in wolf_types, "LOG_ONLY 事件不应推送给任何 Agent"

    assert EventType.SEER_CHECK  in seer_types,  "预言家应收到自己的私有事件"
    assert EventType.WOLF_DISCUSS not in seer_types, "预言家不应看到狼人专属事件"

    print(f"  狼人可见事件: {[e.event_type.value for e in wolf_events]}")
    print(f"  预言家可见事件: {[e.event_type.value for e in seer_events]}")
    print("  [PASS] 可见性路由正确")


def test_config_loaded():
    section("5. 配置加载")
    print(f"  LLM_MODEL   = {config.LLM_MODEL}")
    print(f"  LLM_BASE_URL= {config.LLM_BASE_URL}")
    api_key_set = bool(config.DASHSCOPE_API_KEY)
    print(f"  API_KEY 已设置: {'是' if api_key_set else '否（请复制 .env.example 为 .env 并填写）'}")
    assert config.LLM_MODEL == "qwen-plus"
    assert "dashscope" in config.LLM_BASE_URL
    print("  [PASS] 配置正确")


if __name__ == "__main__":
    print("Stage 1 数据模型验证")
    try:
        test_role_meta()
        test_game_state_factory()
        test_win_conditions()
        test_event_bus_visibility()
        test_config_loaded()
        print("\n" + "="*50)
        print("  全部通过 ✓  Stage 1 数据模型正常")
        print("="*50)
    except AssertionError as e:
        print(f"\n[FAIL] {e}")
        sys.exit(1)
