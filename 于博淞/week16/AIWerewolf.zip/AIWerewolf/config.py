import os
from dotenv import load_dotenv

load_dotenv()

# LLM / API
DASHSCOPE_API_KEY: str = os.getenv("DASHSCOPE_API_KEY", "")
LLM_MODEL: str = "qwen-plus"
LLM_BASE_URL: str = "https://dashscope.aliyuncs.com/compatible-mode/v1"
LLM_TEMPERATURE: float = 0.8
LLM_MAX_TOKENS: int = 800

# Game presets  (role -> count)
ROLE_PRESETS: dict[str, dict[str, int]] = {
    "standard_9": {
        "werewolf": 3,
        "seer": 1,
        "witch": 1,
        "hunter": 1,
        "villager": 3,
    },
    "quick_6": {
        "werewolf": 2,
        "seer": 1,
        "witch": 1,
        "villager": 2,
    },
    "debug_4": {
        "werewolf": 1,
        "seer": 1,
        "villager": 2,
    },
}

DEFAULT_PRESET: str = "standard_9"

PLAYER_NAMES: list[str] = [
    "阿明", "阿丽", "阿强", "阿梅", "阿伟",
    "阿芳", "阿龙", "阿燕", "阿刚",
]

# Logging
LOG_DIR: str = "logs"
REPLAY_DIR: str = "replays"
