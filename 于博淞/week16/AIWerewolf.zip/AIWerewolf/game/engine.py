"""
GameEngine — 狼人杀对局引擎

回合流程：
  夜晚: 守卫 → 预言家 → 狼人(顺序讨论+投票) → 女巫
  白天: 死亡公告 → [猎人触发] → 顺序发言 → 投票 → 放逐结算 → [猎人触发]
  每阶段结束后检查胜负。
"""
from __future__ import annotations

import random
import time
from collections import Counter
from typing import Optional

from agents.base import BaseAgent
from agents.guard import GuardAgent
from agents.hunter import HunterAgent
from agents.seer import SeerAgent
from agents.villager import VillagerAgent
from agents.werewolf import WerewolfAgent
from agents.witch import WitchAgent
from game.events import EventBus, EventType, GameEvent, Visibility
from game.roles import Camp, Role, ROLE_NAME_CN
from game.state import GameState, NightRecord, Phase
from logger.game_logger import GameLogger
from ui.terminal import GameUI
import config

_AGENT_MAP = {
    Role.WEREWOLF: WerewolfAgent,
    Role.SEER:     SeerAgent,
    Role.WITCH:    WitchAgent,
    Role.GUARD:    GuardAgent,
    Role.HUNTER:   HunterAgent,
    Role.VILLAGER: VillagerAgent,
}


class GameEngine:
    def __init__(
        self,
        preset: str = config.DEFAULT_PRESET,
        verbose: bool = True,
        agent_overrides: Optional[dict[int, BaseAgent]] = None,
        strategy_overrides: Optional[dict[str, str]] = None,
    ):
        """
        agent_overrides:    {player_id: agent} 用于测试注入 MockAgent。
        strategy_overrides: {role_value: strategy_text} Stage 6 进化策略注入。
        """
        self.preset = preset
        self.verbose = verbose
        self.agent_overrides = agent_overrides or {}
        self.strategy_overrides = strategy_overrides or {}

        self.state: GameState = None   # type: ignore
        self.agents: dict[int, BaseAgent] = {}
        self.bus = EventBus()
        self.logger: GameLogger = None  # type: ignore
        self.ui = GameUI(verbose=verbose)
        self._start_time: float = 0.0

    # ═════════════════════════════════════════════════════════════════════
    # 公开入口
    # ═════════════════════════════════════════════════════════════════════

    async def run(self) -> Optional[Camp]:
        self._setup()
        self._start_time = time.time()

        self.ui.game_start(self.state, self.preset)
        self._announce_roles_to_players()
        self._emit(EventType.GAME_START, Visibility.PUBLIC, "游戏开始，天黑请闭眼。")
        self.logger.event(0, "pregame", "游戏开始")

        while not self.state.game_over:
            self.state.round += 1
            self.ui.round_header(self.state.round)
            self.logger.event(self.state.round, "round_start",
                              f"第{self.state.round}轮开始")

            await self._night_phase()
            if self._check_game_over():
                break

            await self._day_phase()
            self._check_game_over()

        elapsed = time.time() - self._start_time
        replay_path = self.logger.save_replay(self.state, elapsed)
        self.ui._p(f"\n[dim]用时 {elapsed:.1f}s  |  Replay → {replay_path}[/dim]")
        return self.state.winner

    # ═════════════════════════════════════════════════════════════════════
    # 初始化
    # ═════════════════════════════════════════════════════════════════════

    def _setup(self) -> None:
        game_id = f"game_{int(time.time())}"
        self.logger = GameLogger(game_id)

        role_counts = config.ROLE_PRESETS[self.preset]
        self.state = GameState.from_role_config(role_counts, config.PLAYER_NAMES)

        for player in self.state.players:
            if player.id in self.agent_overrides:
                agent = self.agent_overrides[player.id]
                agent.player = player
            else:
                # Stage 6: 将对应角色的策略注入 Agent
                strat = self.strategy_overrides.get(player.role.value)
                agent = _AGENT_MAP[player.role](player, strategy_override=strat)
            self.agents[player.id] = agent

        wolves = [p for p in self.state.players if p.role == Role.WEREWOLF]
        for wolf in wolves:
            allies = [p.name for p in wolves if p.id != wolf.id]
            self.agents[wolf.id].role_context["allies"] = allies

        witch = self._alive_agent(Role.WITCH)
        if witch:
            witch.role_context.update({"save_left": True, "poison_left": True})

    def _announce_roles_to_players(self) -> None:
        for player in self.state.players:
            role_cn = ROLE_NAME_CN[player.role]
            content = f"你的身份是【{role_cn}】。"
            if player.role == Role.WEREWOLF:
                allies = self.agents[player.id].role_context.get("allies", [])
                content += (f" 你的同伴是：{'、'.join(allies)}。"
                            if allies else " 你是唯一的狼人。")
            evt = self.bus.emit(EventType.GAME_START, 0, Visibility.PRIVATE,
                                content, recipient_id=player.id)
            self.agents[player.id].receive_event(evt)

    # ═════════════════════════════════════════════════════════════════════
    # 夜间阶段
    # ═════════════════════════════════════════════════════════════════════

    async def _night_phase(self) -> None:
        self.state.night_record = NightRecord(round=self.state.round)
        self.state.deaths_this_round = []

        self._set_phase(Phase.NIGHT_GUARD)
        await self._night_guard()

        self._set_phase(Phase.NIGHT_SEER)
        await self._night_seer()

        self._set_phase(Phase.NIGHT_WOLF)
        await self._night_wolf()

        self._set_phase(Phase.NIGHT_WITCH)
        await self._night_witch()

        self._settle_night()

    async def _night_guard(self) -> None:
        guard = self._alive_agent(Role.GUARD)
        if not guard:
            return
        self.ui.phase_banner(Phase.NIGHT_GUARD)
        result = await guard.night_action(self.state)
        protect_id = result.get("protect")
        if protect_id:
            self.state.night_record.guard_protect_target = protect_id
            self.state.guard_last_protect = protect_id
            guard.role_context["last_protect"] = protect_id
            self._emit_private(
                EventType.GUARD_PROTECT,
                f"你今晚保护了 {self.state.get_player(protect_id).name}（{protect_id}号）",
                recipient_id=guard.player.id,
                data={"protect": protect_id},
            )
            self.logger.decision(self.state.round, "night_guard",
                                 guard.player.name, "protect",
                                 f"保护{protect_id}号")

    async def _night_seer(self) -> None:
        seer = self._alive_agent(Role.SEER)
        if not seer:
            return
        self.ui.phase_banner(Phase.NIGHT_SEER)
        result = await seer.night_action(self.state)
        check_id = result.get("check")
        if not check_id:
            return
        target = self.state.get_player(check_id)
        if not target:
            return

        is_wolf = target.role == Role.WEREWOLF
        result_cn = "狼人" if is_wolf else "好人"
        self.state.seer_results[check_id] = is_wolf
        self.state.night_record.seer_check_target = check_id
        self.state.night_record.seer_check_result = is_wolf
        seer.role_context.setdefault("checks", {})[target.name] = result_cn

        self._emit_private(
            EventType.SEER_CHECK,
            f"查验结果：{target.name}（{check_id}号）是【{result_cn}】",
            recipient_id=seer.player.id,
            data={"check_id": check_id, "is_wolf": is_wolf},
        )
        self.logger.decision(self.state.round, "night_seer",
                             seer.player.name, "check",
                             f"查验{check_id}号→{result_cn}")

    async def _night_wolf(self) -> None:
        wolf_agents = [
            a for a in self.agents.values()
            if a.player.role == Role.WEREWOLF and a.player.is_alive
        ]
        if not wolf_agents:
            return
        self.ui.phase_banner(Phase.NIGHT_WOLF)

        kill_votes: dict[int, int] = {}
        for agent in wolf_agents:
            result = await agent.night_action(self.state)
            kill_id  = result.get("kill")
            analysis = result.get("analysis", "")
            if kill_id:
                kill_votes[agent.player.id] = kill_id

            discuss_content = (
                f"狼人{agent.player.name}：{analysis}"
                if analysis else
                f"狼人{agent.player.name}选择击杀{kill_id}号"
            )
            self._emit_wolf(EventType.WOLF_DISCUSS, discuss_content,
                            data={"wolf": agent.player.id, "kill": kill_id})
            self.logger.decision(self.state.round, "night_wolf",
                                 agent.player.name, "discuss",
                                 discuss_content[:80])

        if not kill_votes:
            return

        counter   = Counter(kill_votes.values())
        max_votes = max(counter.values())
        top       = [t for t, c in counter.items() if c == max_votes]
        final_kill = random.choice(top)
        self.state.night_record.wolf_kill_target = final_kill

        kill_target = self.state.get_player(final_kill)
        self.ui.night_wolf_choice(
            wolf_agents[0].player.name, final_kill, kill_target.name
        )
        self.logger.event(self.state.round, "night_wolf",
                          f"狼人决定击杀{final_kill}号{kill_target.name}",
                          data={"kill": final_kill})

    async def _night_witch(self) -> None:
        witch = self._alive_agent(Role.WITCH)
        if not witch:
            return
        self.ui.phase_banner(Phase.NIGHT_WITCH)

        kill_id   = self.state.night_record.wolf_kill_target
        kill_name = self.state.get_player(kill_id).name if kill_id else None
        witch.role_context["kill_target_name"] = kill_name
        witch.role_context["save_left"]        = self.state.witch_inventory.save_potion
        witch.role_context["poison_left"]      = self.state.witch_inventory.poison_potion

        result = await witch.night_action(self.state)

        if result.get("save") and self.state.witch_inventory.save_potion:
            self.state.witch_inventory.save_potion = False
            self.state.night_record.witch_save     = True
            witch.role_context["save_left"]        = False
            self._emit_private(EventType.WITCH_DECISION,
                               "你使用了解药，救下了被击杀的玩家。",
                               recipient_id=witch.player.id)
            self.logger.decision(self.state.round, "night_witch",
                                 witch.player.name, "save", f"救{kill_name}")

        poison_id = result.get("poison")
        if poison_id and self.state.witch_inventory.poison_potion:
            alive_ids = {p.id for p in self.state.alive_players()}
            if poison_id in alive_ids:
                self.state.witch_inventory.poison_potion       = False
                self.state.night_record.witch_poison_target    = poison_id
                witch.role_context["poison_left"]              = False
                poison_target = self.state.get_player(poison_id)
                self._emit_private(
                    EventType.WITCH_DECISION,
                    f"你使用了毒药，毒杀了{poison_target.name}（{poison_id}号）。",
                    recipient_id=witch.player.id,
                )
                self.logger.decision(self.state.round, "night_witch",
                                     witch.player.name, "poison",
                                     f"毒{poison_id}号")

    def _settle_night(self) -> None:
        nr     = self.state.night_record
        deaths: list[int]    = []
        protected: list[int] = []

        kill_id = nr.wolf_kill_target
        if kill_id:
            if kill_id == nr.guard_protect_target or nr.witch_save:
                protected.append(kill_id)
            else:
                deaths.append(kill_id)

        poison_id = nr.witch_poison_target
        if poison_id and poison_id not in deaths:
            deaths.append(poison_id)

        for pid in deaths:
            player = self.state.get_player(pid)
            if player:
                player.is_alive = False

        self.state.deaths_this_round = deaths
        self.ui.night_settle(deaths, protected, self.state)
        self.logger.settlement(
            self.state.round,
            f"夜间死亡：{deaths if deaths else '无'}",
            deaths=deaths, protected=protected,
        )

    # ═════════════════════════════════════════════════════════════════════
    # 白天阶段
    # ═════════════════════════════════════════════════════════════════════

    async def _day_phase(self) -> None:
        self._set_phase(Phase.DAY_ANNOUNCE)
        self.ui.phase_banner(Phase.DAY_ANNOUNCE)
        await self._announce_deaths()

        if self._check_game_over():
            return

        self._set_phase(Phase.DAY_DISCUSS)
        await self._day_discuss()

        self._set_phase(Phase.DAY_VOTE)
        exiled_id = await self._day_vote()

        self._set_phase(Phase.DAY_EXILE)
        if exiled_id:
            await self._exile_player(exiled_id)
        else:
            self._emit_public(EventType.NO_EXILE, "投票平局，今天没有玩家被放逐。")
            self.ui.no_exile()
            self.logger.event(self.state.round, "day_exile",
                              "投票平局，无放逐")

    async def _announce_deaths(self) -> None:
        deaths = self.state.deaths_this_round
        msg = (
            "昨晚是平安夜，没有玩家死亡。"
            if not deaths else
            "、".join(f"{self.state.get_player(d).name}（{d}号）"
                      for d in deaths) + " 死亡。"
        )
        self._emit_public(EventType.DAY_DEATHS, msg, data={"deaths": deaths})
        self.ui.death_announce(deaths, self.state)
        self.logger.event(self.state.round, "day_announce", msg, deaths=deaths)

        for pid in deaths:
            player = self.state.get_player(pid)
            if not player:
                continue
            agent = self.agents.get(pid)
            if agent:
                words = await agent.last_words(self.state, "被狼人击杀")
                self._emit_public(EventType.LAST_WORDS,
                                  f"{player.name}遗言：{words}",
                                  data={"player": pid})
                self.ui.last_words(player, words)
                self.logger.decision(self.state.round, "day_announce",
                                     player.name, "last_words", words)

            if player.role == Role.HUNTER:
                await self._trigger_hunter(player)
                if self._check_game_over():
                    return

    async def _day_discuss(self) -> None:
        alive = self.state.alive_players()
        self.ui.discuss_header(len(alive))

        for i, player in enumerate(alive):
            agent  = self.agents[player.id]
            hint   = "你是今天第一个发言的玩家。" if i == 0 else ""
            speech = await agent.speak(self.state, hint)

            self._emit_public(
                EventType.PLAYER_SPEECH,
                f"{player.name}（{player.id}号）：{speech}",
                data={"player": player.id, "speech": speech},
            )
            self.ui.player_speak(player, speech)
            self.logger.decision(self.state.round, "day_discuss",
                                 player.name, "speak", speech)

    async def _day_vote(self) -> Optional[int]:
        alive      = self.state.alive_players()
        vote_tally: Counter = Counter()
        self.ui.vote_header()

        for player in alive:
            agent             = self.agents[player.id]
            target_id, reason = await agent.vote(self.state)
            vote_tally[target_id] += 1

            target_player = self.state.get_player(target_id)
            target_name   = target_player.name if target_player else f"{target_id}号"
            self._emit_public(
                EventType.VOTE_CAST,
                f"{player.name}（{player.id}号）投票放逐 {target_id}号。理由：{reason}",
                data={"voter": player.id, "target": target_id},
            )
            self.ui.vote_cast(player, target_id, target_name, reason)
            self.logger.decision(self.state.round, "day_vote",
                                 player.name, "vote",
                                 f"投{target_id}号", reasoning=reason)

        self.state.votes = dict(vote_tally)
        if not vote_tally:
            return None

        max_votes = max(vote_tally.values())
        top       = [pid for pid, cnt in vote_tally.items() if cnt == max_votes]

        if len(top) > 1:
            self.ui.vote_result(dict(vote_tally), self.state, None)
            self.logger.event(self.state.round, "day_vote",
                              f"平局：{top}",  tally=dict(vote_tally))
            return None

        exiled_id = top[0]
        self.ui.vote_result(dict(vote_tally), self.state, exiled_id)
        self.logger.event(self.state.round, "day_vote",
                          f"计票结果：放逐{exiled_id}号",
                          tally=dict(vote_tally))
        return exiled_id

    async def _exile_player(self, player_id: int) -> None:
        player = self.state.get_player(player_id)
        if not player:
            return

        player.is_alive = False
        self._emit_public(EventType.EXILE,
                          f"{player.name}（{player_id}号）被放逐。",
                          data={"exiled": player_id, "role": player.role.value})
        self.ui.exile(player)
        self.logger.event(self.state.round, "day_exile",
                          f"{player.name}（{player_id}号）被放逐",
                          exiled=player_id, role=player.role.value)

        agent = self.agents.get(player_id)
        if agent:
            words = await agent.last_words(self.state, "被投票放逐")
            self._emit_public(EventType.LAST_WORDS,
                              f"{player.name}放逐遗言：{words}",
                              data={"player": player_id})
            self.ui.last_words(player, words)
            self.logger.decision(self.state.round, "day_exile",
                                 player.name, "last_words", words)

        if player.role == Role.HUNTER:
            await self._trigger_hunter(player)

    async def _trigger_hunter(self, hunter) -> None:
        agent = self.agents.get(hunter.id)
        if not agent or not isinstance(agent, HunterAgent):
            return
        alive_others = [p for p in self.state.alive_players() if p.id != hunter.id]
        if not alive_others:
            return

        shoot_id, reason = await agent.hunter_shoot(self.state)
        target = self.state.get_player(shoot_id)
        if not target:
            return

        target.is_alive = False
        self._emit_public(EventType.HUNTER_SHOOT,
                          f"猎人{hunter.name}射杀了{target.name}（{shoot_id}号）。",
                          data={"hunter": hunter.id, "shot": shoot_id})
        self.ui.hunter_shoot(hunter, target)
        self.logger.event(self.state.round, "hunter_shoot",
                          f"猎人{hunter.name}射杀{shoot_id}号{target.name}",
                          hunter=hunter.id, shot=shoot_id)

    # ═════════════════════════════════════════════════════════════════════
    # 工具方法
    # ═════════════════════════════════════════════════════════════════════

    def _check_game_over(self) -> bool:
        winner = self.state.check_win()
        if winner is None:
            return False

        self.state.game_over  = True
        self.state.winner     = winner
        wolves_alive  = [p for p in self.state.players
                         if p.role == Role.WEREWOLF and p.is_alive]
        village_alive = self.state.alive_villager_camp()

        self.state.winner_reason = (
            "所有狼人已被消灭，好人阵营获胜！"
            if winner == Camp.VILLAGER else
            f"存活狼人（{len(wolves_alive)}人）≥ 存活好人（{len(village_alive)}人），"
            "狼人阵营获胜！"
        )
        self._emit_public(EventType.GAME_END, self.state.winner_reason,
                          data={"winner": winner.value})
        self.ui.game_end(self.state)
        self.logger.event(self.state.round, "game_end",
                          self.state.winner_reason, winner=winner.value)
        return True

    def _set_phase(self, phase: Phase) -> None:
        self.state.phase = phase

    def _alive_agent(self, role: Role) -> Optional[BaseAgent]:
        for agent in self.agents.values():
            if agent.player.role == role and agent.player.is_alive:
                return agent
        return None

    # ── 事件发射 ─────────────────────────────────────────────────────────

    def _emit(
        self,
        event_type: EventType,
        visibility: Visibility,
        content: str,
        recipient_id: Optional[int] = None,
        data: Optional[dict] = None,
    ) -> GameEvent:
        evt = self.bus.emit(event_type, self.state.round, visibility,
                            content, recipient_id=recipient_id, data=data)
        for pid, agent in self.agents.items():
            player = self.state.get_player(pid)
            if evt.is_visible_to(pid, player.role.value):
                agent.receive_event(evt)
        return evt

    def _emit_public(self, et, content, data=None) -> GameEvent:
        return self._emit(et, Visibility.PUBLIC, content, data=data)

    def _emit_wolf(self, et, content, data=None) -> GameEvent:
        return self._emit(et, Visibility.WOLF, content, data=data)

    def _emit_private(self, et, content, recipient_id, data=None) -> GameEvent:
        return self._emit(et, Visibility.PRIVATE, content,
                          recipient_id=recipient_id, data=data)
