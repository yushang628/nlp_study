from __future__ import annotations

import random
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

from game.roles import Camp, Role, ROLE_CAMP


class Phase(str, Enum):
    PREGAME      = "pregame"
    NIGHT_GUARD  = "night_guard"
    NIGHT_SEER   = "night_seer"
    NIGHT_WOLF   = "night_wolf"
    NIGHT_WITCH  = "night_witch"
    DAY_ANNOUNCE = "day_announce"
    DAY_DISCUSS  = "day_discuss"
    DAY_VOTE     = "day_vote"
    DAY_EXILE    = "day_exile"
    GAME_OVER    = "game_over"


PHASE_NAME_CN: dict[Phase, str] = {
    Phase.PREGAME:      "游戏准备",
    Phase.NIGHT_GUARD:  "夜晚·守卫行动",
    Phase.NIGHT_SEER:   "夜晚·预言家查验",
    Phase.NIGHT_WOLF:   "夜晚·狼人袭击",
    Phase.NIGHT_WITCH:  "夜晚·女巫决策",
    Phase.DAY_ANNOUNCE: "白天·死亡公告",
    Phase.DAY_DISCUSS:  "白天·发言讨论",
    Phase.DAY_VOTE:     "白天·投票放逐",
    Phase.DAY_EXILE:    "白天·放逐结算",
    Phase.GAME_OVER:    "游戏结束",
}


class Player(BaseModel):
    id: int
    name: str
    role: Role
    is_alive: bool = True

    @property
    def camp(self) -> Camp:
        return ROLE_CAMP[self.role]

    def __str__(self) -> str:
        status = "存活" if self.is_alive else "死亡"
        return f"玩家{self.id}({self.name})[{status}]"


class WitchInventory(BaseModel):
    save_potion: bool = True    # 解药
    poison_potion: bool = True  # 毒药


class NightRecord(BaseModel):
    """单夜行动记录，供引擎结算使用。"""
    round: int
    wolf_kill_target: Optional[int] = None   # player_id
    guard_protect_target: Optional[int] = None
    seer_check_target: Optional[int] = None
    seer_check_result: Optional[bool] = None  # True = wolf
    witch_save: bool = False
    witch_poison_target: Optional[int] = None


class GameState(BaseModel):
    round: int = 0
    phase: Phase = Phase.PREGAME
    players: list[Player] = Field(default_factory=list)

    # Night action state
    night_record: NightRecord = Field(default_factory=lambda: NightRecord(round=0))
    witch_inventory: WitchInventory = Field(default_factory=WitchInventory)
    guard_last_protect: Optional[int] = None

    # Seer private knowledge: player_id -> is_wolf
    seer_results: dict[int, bool] = Field(default_factory=dict)

    # Votes: voter_id -> target_id
    votes: dict[int, int] = Field(default_factory=dict)

    # Deaths this round (announced at day_announce)
    deaths_this_round: list[int] = Field(default_factory=list)

    # Cumulative public speech log (day speeches / last words)
    speech_log: list[dict] = Field(default_factory=list)

    # Game result
    game_over: bool = False
    winner: Optional[Camp] = None
    winner_reason: str = ""

    # ── Convenience accessors ─────────────────────────────────────────────

    def get_player(self, pid: int) -> Optional[Player]:
        for p in self.players:
            if p.id == pid:
                return p
        return None

    def alive_players(self) -> list[Player]:
        return [p for p in self.players if p.is_alive]

    def alive_wolves(self) -> list[Player]:
        return [p for p in self.players if p.is_alive and p.role == Role.WEREWOLF]

    def alive_villager_camp(self) -> list[Player]:
        return [p for p in self.players if p.is_alive and p.camp == Camp.VILLAGER]

    def get_role_player(self, role: Role) -> Optional[Player]:
        for p in self.players:
            if p.role == role:
                return p
        return None

    # ── Win condition ─────────────────────────────────────────────────────

    def check_win(self) -> Optional[Camp]:
        wolves = len(self.alive_wolves())
        villagers = len(self.alive_villager_camp())
        if wolves == 0:
            return Camp.VILLAGER
        if wolves >= villagers:
            return Camp.WEREWOLF
        return None

    # ── Factory ───────────────────────────────────────────────────────────

    @classmethod
    def from_role_config(cls, role_counts: dict[str, int], names: list[str]) -> "GameState":
        """Build an initial GameState from a role distribution dict."""
        roles: list[Role] = []
        for role_str, count in role_counts.items():
            roles.extend([Role(role_str)] * count)

        if len(roles) > len(names):
            raise ValueError(f"需要 {len(roles)} 个玩家名称，只提供了 {len(names)} 个")

        random.shuffle(roles)
        players = [
            Player(id=i + 1, name=names[i], role=roles[i])
            for i in range(len(roles))
        ]
        return cls(players=players)

    # ── Helpers ───────────────────────────────────────────────────────────

    def public_player_list(self) -> str:
        """返回供 Agent 感知的存活玩家列表（不含角色）。"""
        lines = []
        for p in self.players:
            status = "存活" if p.is_alive else "【死亡】"
            lines.append(f"  {p.id}号 {p.name} {status}")
        return "\n".join(lines)
