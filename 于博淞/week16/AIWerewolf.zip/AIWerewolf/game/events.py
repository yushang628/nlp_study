from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class Visibility(str, Enum):
    PUBLIC   = "public"    # 所有存活玩家可见
    WOLF     = "wolf"      # 仅狼人可见（夜间狼群讨论）
    PRIVATE  = "private"   # 仅特定玩家可见（需配合 recipient_id）
    LOG_ONLY = "log_only"  # 仅写入日志，不推送给任何 Agent


class EventType(str, Enum):
    # 游戏流程
    GAME_START      = "game_start"
    ROUND_START     = "round_start"
    PHASE_CHANGE    = "phase_change"
    GAME_END        = "game_end"

    # 夜间行动
    WOLF_DISCUSS    = "wolf_discuss"    # WOLF
    WOLF_KILL       = "wolf_kill"       # LOG_ONLY → 天亮后变为 DAY_DEATH
    GUARD_PROTECT   = "guard_protect"   # PRIVATE(guard)
    SEER_CHECK      = "seer_check"      # PRIVATE(seer)
    WITCH_DECISION  = "witch_decision"  # PRIVATE(witch)

    # 白天
    DAY_DEATHS      = "day_deaths"      # PUBLIC
    PLAYER_SPEECH   = "player_speech"   # PUBLIC
    LAST_WORDS      = "last_words"      # PUBLIC
    VOTE_CAST       = "vote_cast"       # PUBLIC
    VOTE_RESULT     = "vote_result"     # PUBLIC
    EXILE           = "exile"           # PUBLIC
    NO_EXILE        = "no_exile"        # PUBLIC

    # 特殊技能
    HUNTER_SHOOT    = "hunter_shoot"    # PUBLIC


class GameEvent(BaseModel):
    event_id: int
    event_type: EventType
    round: int
    visibility: Visibility
    content: str                          # 人类可读的描述（中文）
    recipient_id: Optional[int] = None   # Visibility.PRIVATE 时使用
    data: dict[str, Any] = Field(default_factory=dict)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())

    def is_visible_to(self, player_id: int, player_role: str) -> bool:
        if self.visibility == Visibility.PUBLIC:
            return True
        if self.visibility == Visibility.WOLF:
            return player_role == "werewolf"
        if self.visibility == Visibility.PRIVATE:
            return self.recipient_id == player_id
        return False  # LOG_ONLY


class EventBus:
    """轻量事件总线：收集事件、按 Agent 权限过滤分发。"""

    def __init__(self) -> None:
        self._counter: int = 0
        self._events: list[GameEvent] = []

    def emit(
        self,
        event_type: EventType,
        round_: int,
        visibility: Visibility,
        content: str,
        recipient_id: Optional[int] = None,
        data: Optional[dict] = None,
    ) -> GameEvent:
        self._counter += 1
        event = GameEvent(
            event_id=self._counter,
            event_type=event_type,
            round=round_,
            visibility=visibility,
            content=content,
            recipient_id=recipient_id,
            data=data or {},
        )
        self._events.append(event)
        return event

    def events_for(self, player_id: int, player_role: str) -> list[GameEvent]:
        """返回该玩家有权看到的全部历史事件。"""
        return [e for e in self._events if e.is_visible_to(player_id, player_role)]

    def public_events(self) -> list[GameEvent]:
        return [e for e in self._events if e.visibility == Visibility.PUBLIC]

    def all_events(self) -> list[GameEvent]:
        return list(self._events)
