from enum import Enum


class Role(str, Enum):
    WEREWOLF = "werewolf"
    VILLAGER = "villager"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    GUARD = "guard"


class Camp(str, Enum):
    WEREWOLF = "werewolf"  # 狼人阵营
    VILLAGER = "villager"  # 好人阵营


ROLE_CAMP: dict[Role, Camp] = {
    Role.WEREWOLF: Camp.WEREWOLF,
    Role.VILLAGER: Camp.VILLAGER,
    Role.SEER:     Camp.VILLAGER,
    Role.WITCH:    Camp.VILLAGER,
    Role.HUNTER:   Camp.VILLAGER,
    Role.GUARD:    Camp.VILLAGER,
}

ROLE_NAME_CN: dict[Role, str] = {
    Role.WEREWOLF: "狼人",
    Role.VILLAGER: "村民",
    Role.SEER:     "预言家",
    Role.WITCH:    "女巫",
    Role.HUNTER:   "猎人",
    Role.GUARD:    "守卫",
}

ROLE_ABILITY_CN: dict[Role, str] = {
    Role.WEREWOLF: "每晚与同伴商议后击杀一名好人，白天需伪装成好人规避投票。",
    Role.VILLAGER: "无特殊技能，靠推理识别狼人，引导投票。",
    Role.SEER:     "每晚可查验一名玩家的真实阵营（好人/狼人）。",
    Role.WITCH:    "持有解药×1（救夜间死者）和毒药×1（毒杀任意玩家），各限用一次。",
    Role.HUNTER:   "被狼人杀死或投票放逐时，可立即射杀场上任意一名存活玩家。",
    Role.GUARD:    "每晚保护一名玩家免遭狼人击杀，不可连续两晚守护同一人。",
}

ROLE_WIN_GOAL_CN: dict[Role, str] = {
    Role.WEREWOLF: "让存活狼人数量大于等于存活好人数量。",
    Role.VILLAGER: "投票放逐或借助神职技能消灭所有狼人。",
    Role.SEER:     "利用查验信息引导好人阵营消灭所有狼人。",
    Role.WITCH:    "在关键时刻使用药水扭转战局，协助消灭所有狼人。",
    Role.HUNTER:   "死亡时带走一名狼人，用生命换取好人阵营的优势。",
    Role.GUARD:    "保护关键好人（尤其是神职），延缓狼人的猎杀节奏。",
}
