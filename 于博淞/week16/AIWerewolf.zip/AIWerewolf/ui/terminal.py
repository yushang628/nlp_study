"""
ui/terminal.py — 终端观战 UI（Rich 渲染）

设计原则：
  - GameUI 只负责显示，不持有任何游戏状态
  - 所有方法在 verbose=False 时静默
  - 夜间/白天风格自动切换
"""
from __future__ import annotations

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from game.roles import Camp, Role, ROLE_NAME_CN
from game.state import GameState, Phase, Player, PHASE_NAME_CN

# ── 主题常量 ──────────────────────────────────────────────────────────────

ROLE_STYLE: dict[Role, str] = {
    Role.WEREWOLF: "bold red",
    Role.SEER:     "bold blue",
    Role.WITCH:    "bold magenta",
    Role.HUNTER:   "bold dark_orange",
    Role.GUARD:    "bold cyan",
    Role.VILLAGER: "bold green",
}

NIGHT_PHASES = {
    Phase.NIGHT_GUARD, Phase.NIGHT_SEER,
    Phase.NIGHT_WOLF,  Phase.NIGHT_WITCH,
}


class GameUI:
    def __init__(self, verbose: bool = True) -> None:
        self.verbose = verbose
        self.console = Console()

    def _p(self, *args, **kwargs) -> None:
        if self.verbose:
            self.console.print(*args, **kwargs)

    # ── 游戏生命周期 ──────────────────────────────────────────────────────

    def game_start(self, state: GameState, preset: str) -> None:
        if not self.verbose:
            return
        title = Text("🐺   AI 狼人杀   🐺", style="bold white", justify="center")
        self._p(Panel(title, style="bold blue", border_style="blue",
                      padding=(0, 4)))
        self._p(f"  [cyan]预设[/cyan]: {preset}   "
                f"[cyan]玩家数[/cyan]: {len(state.players)}   "
                f"[cyan]轮次上限[/cyan]: 无限制\n")
        self.player_table(state, show_roles=True, title="角色分配（观战视角）")

    def round_header(self, round_num: int) -> None:
        self._p(Rule(f"[bold yellow]  第 {round_num} 轮  [/bold yellow]",
                     style="yellow"))

    def phase_banner(self, phase: Phase) -> None:
        name = PHASE_NAME_CN.get(phase, phase.value)
        if phase in NIGHT_PHASES:
            self._p(f"  [dim blue]🌙 {name}[/dim blue]")
        else:
            self._p(f"  [dim green]☀  {name}[/dim green]")

    def game_end(self, state: GameState) -> None:
        if not self.verbose:
            return
        winner = state.winner
        if winner == Camp.VILLAGER:
            color, emoji, text = "green", "🎉", "好人阵营 获胜！"
        else:
            color, emoji, text = "red", "🐺", "狼人阵营 获胜！"

        self._p(Panel(
            f"[bold {color}]{emoji}  {text}[/bold {color}]\n\n"
            f"[dim]{state.winner_reason}[/dim]\n\n"
            f"共 [bold]{state.round}[/bold] 轮",
            border_style=color, padding=(1, 4),
        ))
        self.player_table(state, show_roles=True, title="最终角色揭示")

    # ── 夜间 ──────────────────────────────────────────────────────────────

    def night_wolf_choice(self, wolf_name: str, target_id: int,
                          target_name: str) -> None:
        self._p(f"  [dim red]🐺 {wolf_name} 决定击杀 → "
                f"{target_id}号 {target_name}[/dim red]")

    def night_settle(self, deaths: list[int], protected: list[int],
                     state: GameState) -> None:
        for pid in protected:
            p = state.get_player(pid)
            if p:
                self._p(f"  [cyan]🛡  {p.name}（{pid}号）被保护/解救，安全度过[/cyan]")
        for pid in deaths:
            p = state.get_player(pid)
            if p:
                self._p(f"  [red]💀 {p.name}（{pid}号）死亡[/red]")

    # ── 死亡公告 ─────────────────────────────────────────────────────────

    def death_announce(self, deaths: list[int], state: GameState) -> None:
        if not deaths:
            self._p(Panel("[green]🌅 昨晚是平安夜，没有玩家死亡。[/green]",
                          border_style="green", padding=(0, 1)))
        else:
            parts = "、".join(
                f"[bold red]{state.get_player(d).name}（{d}号）[/bold red]"
                for d in deaths if state.get_player(d)
            )
            self._p(Panel(f"💀 昨晚死亡：{parts}",
                          border_style="red", padding=(0, 1)))

    def last_words(self, player: Player, words: str) -> None:
        style = ROLE_STYLE.get(player.role, "dim")
        self._p(Panel(
            f"[italic]{words}[/italic]",
            title=f"[{style}]☠  {player.name}（{player.id}号）遗言[/{style}]",
            border_style="dim", padding=(0, 1),
        ))

    # ── 白天发言 ─────────────────────────────────────────────────────────

    def discuss_header(self, alive_count: int) -> None:
        self._p(f"\n  [bold green]☀  白天发言阶段 — {alive_count} 名玩家依次开口[/bold green]")

    def player_speak(self, player: Player, speech: str) -> None:
        style = ROLE_STYLE.get(player.role, "white")
        # 取颜色部分用于 border（最后一个词）
        border_color = style.split()[-1]
        self._p(Panel(
            speech,
            title=f"[{style}]{player.id}号 · {player.name}[/{style}]",
            border_style=border_color,
            padding=(0, 1),
        ))

    # ── 投票 ─────────────────────────────────────────────────────────────

    def vote_header(self) -> None:
        self._p(f"\n  [bold orange1]🗳  投票环节[/bold orange1]")

    def vote_cast(self, voter: Player, target_id: int,
                  target_name: str, reason: str) -> None:
        self._p(
            f"  [white]{voter.id}号 {voter.name:<4}[/white]"
            f" → [bold]{target_id}号 {target_name}[/bold]"
            f"  [dim]{reason[:45]}[/dim]"
        )

    def vote_result(self, tally: dict[int, int], state: GameState,
                    exiled_id: int | None) -> None:
        if not self.verbose:
            return
        t = Table(title="计票结果", box=box.SIMPLE_HEAVY, show_header=True,
                  header_style="bold")
        t.add_column("玩家", min_width=10)
        t.add_column("票数", justify="center", min_width=6)
        t.add_column("结果", justify="center", min_width=6)

        for pid, cnt in sorted(tally.items(), key=lambda x: -x[1]):
            p = state.get_player(pid)
            name_str = f"{pid}号 {p.name}" if p else f"{pid}号"
            result_str = ("[bold red]⚖ 放逐[/bold red]"
                          if pid == exiled_id else "")
            t.add_row(name_str, str(cnt), result_str)
        self._p(t)

    def no_exile(self) -> None:
        self._p(Panel("[yellow]🤝 投票平局，今天没有玩家被放逐。[/yellow]",
                      border_style="yellow", padding=(0, 1)))

    def exile(self, player: Player) -> None:
        style = ROLE_STYLE.get(player.role, "white")
        self._p(Panel(
            f"真实身份：[{style}]{ROLE_NAME_CN[player.role]}[/{style}]",
            title=f"[bold red]⚖  {player.name}（{player.id}号）被放逐[/bold red]",
            border_style="red", padding=(0, 1),
        ))

    # ── 特殊事件 ─────────────────────────────────────────────────────────

    def hunter_shoot(self, hunter: Player, target: Player) -> None:
        self._p(Panel(
            f"猎人 [bold yellow]{hunter.name}[/bold yellow] 拉响扳机，"
            f"射杀了 [bold red]{target.name}（{target.id}号）[/bold red]！",
            title="🔫 猎人技能触发",
            border_style="yellow", padding=(0, 1),
        ))

    # ── 玩家状态表 ────────────────────────────────────────────────────────

    def player_table(self, state: GameState, show_roles: bool = False,
                     title: str = "玩家状态") -> None:
        if not self.verbose:
            return
        t = Table(title=title, box=box.ROUNDED, show_lines=True,
                  highlight=True)
        t.add_column("编号", justify="center", width=4)
        t.add_column("姓名", width=6)
        if show_roles:
            t.add_column("身份", width=6)
            t.add_column("阵营", width=4)
        t.add_column("状态", width=10)

        for p in state.players:
            status = ("[green]✓ 存活[/green]"
                      if p.is_alive else "[dim red]✗ 死亡[/dim red]")
            row = [str(p.id), p.name]
            if show_roles:
                rs = ROLE_STYLE.get(p.role, "white")
                row.append(f"[{rs}]{ROLE_NAME_CN[p.role]}[/{rs}]")
                camp_s = ("🐺 狼" if p.camp == Camp.WEREWOLF else "👤 好")
                row.append(camp_s)
            row.append(status)
            t.add_row(*row)
        self._p(t)
