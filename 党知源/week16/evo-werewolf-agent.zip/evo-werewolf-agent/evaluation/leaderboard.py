import os
import json
from typing import Dict, Any, List, Optional

LEADERBOARD_FILE = os.path.join(os.path.dirname(__file__), "leaderboard.json")


def _load() -> Dict[str, Any]:
    if not os.path.exists(LEADERBOARD_FILE):
        return {"models": {}, "games": []}
    with open(LEADERBOARD_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(data: Dict[str, Any]):
    os.makedirs(os.path.dirname(LEADERBOARD_FILE), exist_ok=True)
    with open(LEADERBOARD_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def record_game_result(
    game_id: str,
    model_name: str,
    winner: str,
    config_name: str,
    day_number: int,
    player_results: Optional[List[Dict[str, Any]]] = None,
):
    data = _load()
    if model_name not in data["models"]:
        data["models"][model_name] = {
            "model": model_name,
            "games_played": 0,
            "good_wins": 0,
            "evil_wins": 0,
            "total_days": 0,
            "avg_score": 0,
            "score_sum": 0,
        }
    entry = data["models"][model_name]
    entry["games_played"] += 1
    if winner == "good":
        entry["good_wins"] += 1
    elif winner == "evil":
        entry["evil_wins"] += 1
    entry["total_days"] += day_number
    if player_results:
        avg = sum(r.get("total_score", 0) for r in player_results) / max(len(player_results), 1)
        entry["score_sum"] = entry.get("score_sum", 0) + avg
        entry["avg_score"] = round(entry["score_sum"] / entry["games_played"], 2)

    data["games"].append({
        "game_id": game_id,
        "model": model_name,
        "winner": winner,
        "config_name": config_name,
        "day_number": day_number,
    })
    if len(data["games"]) > 500:
        data["games"] = data["games"][-500:]
    _save(data)


def get_leaderboard() -> List[Dict[str, Any]]:
    data = _load()
    rows = []
    for model, stats in data["models"].items():
        gp = stats["games_played"]
        rows.append({
            "model": model,
            "games_played": gp,
            "good_wins": stats["good_wins"],
            "evil_wins": stats["evil_wins"],
            "good_win_rate": round(stats["good_wins"] / gp, 3) if gp else 0,
            "evil_win_rate": round(stats["evil_wins"] / gp, 3) if gp else 0,
            "avg_days": round(stats["total_days"] / gp, 2) if gp else 0,
            "avg_score": stats.get("avg_score", 0),
        })
    rows.sort(key=lambda x: (-x["good_win_rate"], -x["avg_score"]))
    return rows
