import os
import json
from typing import Dict, Any, List

EVAL_DIR = os.path.join(os.path.dirname(__file__), "results")


def _ensure_dir():
    os.makedirs(EVAL_DIR, exist_ok=True)


def evaluate_game(
    game_id: str,
    winner: str,
    death_records: List[Dict[str, Any]],
    dialogues: List[Dict[str, Any]],
    players: List[Dict[str, Any]],
    day_number: int,
) -> Dict[str, Any]:
    _ensure_dir()
    player_scores: Dict[int, Dict[str, Any]] = {}
    for p in players:
        pid = p["player_id"]
        speeches = [d for d in dialogues if d.get("player_id") == pid and d.get("action") == "speech"]
        votes = [d for d in dialogues if d.get("player_id") == pid and d.get("action") == "vote"]
        night_actions = [d for d in dialogues if d.get("player_id") == pid and d.get("action") in ("night_kill", "seer_check", "heal", "poison")]
        is_winner = p.get("camp") == winner
        survived = p.get("is_alive", False)
        speech_score = min(100, len(speeches) * 25 + sum(len(d.get("content", "")) for d in speeches) // 10)
        vote_score = 80 if votes else 40
        action_score = min(100, len(night_actions) * 30)
        survival_bonus = 20 if survived else 0
        win_bonus = 30 if is_winner else 0
        total = int((speech_score * 0.35 + vote_score * 0.25 + action_score * 0.25) + survival_bonus + win_bonus)
        player_scores[pid] = {
            "player_id": pid,
            "name": p.get("name"),
            "role": p.get("role"),
            "camp": p.get("camp"),
            "is_winner": is_winner,
            "survived": survived,
            "speech_count": len(speeches),
            "vote_count": len(votes),
            "night_action_count": len(night_actions),
            "speech_score": speech_score,
            "vote_score": vote_score,
            "action_score": action_score,
            "total_score": min(100, total),
        }

    result = {
        "game_id": game_id,
        "winner": winner,
        "day_number": day_number,
        "death_count": len(death_records),
        "dialogue_count": len(dialogues),
        "player_scores": list(player_scores.values()),
        "camp_good_avg": _avg_score(player_scores, players, "good"),
        "camp_evil_avg": _avg_score(player_scores, players, "evil"),
    }

    path = os.path.join(EVAL_DIR, f"{game_id}_eval.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result


def _avg_score(scores: Dict[int, Dict], players: List[Dict], camp: str) -> float:
    vals = []
    for p in players:
        if p.get("camp") == camp and p["player_id"] in scores:
            vals.append(scores[p["player_id"]]["total_score"])
    return round(sum(vals) / len(vals), 2) if vals else 0.0
