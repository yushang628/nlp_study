"""Role definitions for Werewolf game."""

from roles.base import BaseRole, RoleType, Camp, is_god_role, is_villager_role
from roles.werewolf import Werewolf
from roles.seer import Seer
from roles.witch import Witch
from roles.hunter import Hunter
from roles.villager import Villager
from roles.idiot import Idiot

__all__ = [
    "BaseRole",
    "RoleType",
    "Camp",
    "Werewolf",
    "Seer",
    "Witch",
    "Hunter",
    "Villager",
    "Idiot",
    "is_god_role",
    "is_villager_role",
]