from typing import Optional, Dict, Any
from roles.base import BaseRole, RoleType, Camp


class Idiot(BaseRole):
    def __init__(self, player_id: int):
        super().__init__(player_id)
        self._revealed = False

    @property
    def role_type(self) -> RoleType:
        return RoleType.IDIOT

    @property
    def camp(self) -> Camp:
        return Camp.GOOD

    @property
    def revealed(self) -> bool:
        return self._revealed

    def reveal(self):
        self._revealed = True

    def can_speak(self) -> bool:
        return self._is_alive

    def can_vote(self) -> bool:
        return self._is_alive and not self._revealed

    def on_death(self, cause: str, game_state: Dict[str, Any]) -> Optional[list]:
        if cause == "vote" and not self._revealed:
            self.reveal()
            return None
        self._is_alive = False
        return None

    def get_private_context(self) -> Dict[str, Any]:
        ctx = super().get_private_context()
        ctx.update({
            "revealed": self._revealed,
            "note": "You are the Idiot. When voted out the first time you reveal and survive but cannot vote.",
        })
        return ctx

    def check_win(self, game_state: Dict[str, Any]) -> bool:
        players = game_state.get("players", [])
        alive_wolves = [
            p for p in players
            if p.get("role") == RoleType.WEREWOLF.value and p.get("is_alive")
        ]
        return len(alive_wolves) == 0
