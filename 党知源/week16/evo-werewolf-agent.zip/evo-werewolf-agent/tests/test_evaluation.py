import os
from evaluation.evaluator import evaluate_game
from evaluation.leaderboard import record_game_result, get_leaderboard, LEADERBOARD_FILE


class TestEvaluation:
    def test_evaluate_game(self):
        result = evaluate_game(
            "test_game",
            "good",
            [{"player_id": 0, "cause": "vote"}],
            [{"player_id": 0, "action": "speech", "content": "hello"}],
            [{"player_id": 0, "name": "P0", "role": "villager", "camp": "good", "is_alive": True}],
            2,
        )
        assert result["winner"] == "good"
        assert len(result["player_scores"]) == 1

    def test_leaderboard(self):
        record_game_result("g1", "test-model", "good", "standard_6", 3, [{"total_score": 80}])
        board = get_leaderboard()
        assert any(e["model"] == "test-model" for e in board)
        if os.path.exists(LEADERBOARD_FILE):
            os.remove(LEADERBOARD_FILE)
