from roles.idiot import Idiot
from roles.base import RoleType


class TestIdiot:
    def test_role_type(self):
        idiot = Idiot(0)
        assert idiot.role_type == RoleType.IDIOT

    def test_reveal_on_vote(self):
        idiot = Idiot(0)
        result = idiot.on_death("vote", {})
        assert result is None
        assert idiot.revealed is True
        assert idiot.is_alive is True

    def test_die_after_revealed(self):
        idiot = Idiot(0)
        idiot.reveal()
        result = idiot.on_death("vote", {})
        assert idiot.is_alive is False
