"""游戏引擎（裁判）

控制游戏流程，协调各角色行动，判定胜负
"""

import asyncio
from typing import List, Dict, Any, Optional, Set

from engine.state import GameState
from engine.phase import GamePhase, TurnOrder
from engine.player import Player
from roles.base import RoleType
from roles.werewolf import Werewolf
from roles.seer import Seer
from roles.witch import Witch
from roles.hunter import Hunter
from roles.villager import Villager
from roles.idiot import Idiot
from agent.player_agent import PlayerAgent, create_player_agent, create_judge_agent
from agent.summary_agent import SummaryAgent
from memory.experience import save_experience
from evaluation.evaluator import evaluate_game
from evaluation.leaderboard import record_game_result

SUMMARY_STEP_INDEX = 100


class GameEngine:
    """游戏引擎（裁判）

    负责：
    1. 初始化游戏（分配角色、创建玩家代理）
    2. 推进游戏流程（白天/夜晚切换）
    3. 收集玩家决策
    4. 执行游戏规则（死亡判定、胜负判定）
    5. 管理游戏状态
    6. 记录游戏对话
    """

    def __init__(self, player_names: List[str], logger=None):
        """初始化游戏引擎

        Args:
            player_names: 玩家名称列表，长度应为6
            logger: 可选的日志记录器，用于记录游戏过程
        """
        self.player_names = player_names
        self.game_state = GameState()
        self.judge_agent = create_judge_agent()
        self.player_agents: Dict[int, PlayerAgent] = {}
        self._is_running = False
        self._controller = None  # 游戏控制器
        self.logger = logger  # 游戏日志记录器
        self.death_records: List[Dict[str, Any]] = []  # 死亡记录
        self._night_death_causes: Dict[int, str] = {}  # 夜晚死亡原因追踪
        self._step_index = 0  # 逐步执行模式下的阶段索引
        self.game_id = None  # 游戏ID（API使用）
        self._summaries_done = False
        self._summary_agent = SummaryAgent()
        self.summaries: List[Dict] = []
        self.human_player_ids: Set[int] = set()
        self._pending_human: Optional[Dict[str, Any]] = None
        self._human_action_buffer: Dict[str, Dict[str, Any]] = {}
        self._abort_day_after_speech = False
        self.config_name = "standard_6"
        self.evaluation: Optional[Dict[str, Any]] = None

    def _log(self, level: str, msg: str):
        """内部日志方法"""
        if self.logger:
            if level == "log_action":
                self.logger.log_action_event(msg)
            elif level == "log_speech":
                self.logger.log_speech_event(msg)
            elif level == "log_vote":
                self.logger.log_vote_event(msg)
            elif level == "log_death":
                self.logger.log_death_event(msg)
            elif level == "log_night_action":
                self.logger.log_night_action_event(msg)
            elif level == "log_event":
                self.logger.log_event(msg)
            else:
                getattr(self.logger, level.lower())(msg)

    async def initialize(
        self,
        role_assignment: Dict[int, str],
        player_styles: Dict[int, str] = None,
        human_player_ids: Optional[List[int]] = None,
    ):
        if player_styles is None:
            player_styles = {}
        if human_player_ids is None:
            human_player_ids = []
        self.human_player_ids = set(human_player_ids)

        for player_id, name in enumerate(self.player_names):
            role_type = role_assignment.get(player_id, "villager")
            role = self._create_role(role_type, player_id)
            is_human = player_id in self.human_player_ids
            player = Player(player_id=player_id, role=role, name=name, is_human=is_human)

            if not is_human:
                style = player_styles.get(player_id, "balanced")
                private_context = player.role.get_private_context()
                agent = create_player_agent(
                    player_id=player_id,
                    role_name=role.name,
                    private_context=private_context,
                    camp=role.camp.value,
                    decision_style=style,
                    role_type=role.role_type.value,
                )
                player.agent = agent
                self.player_agents[player_id] = agent

            self.game_state.players.append(player)

        # 设置发言顺序（警长决定或默认顺序）
        self.game_state.set_speaker_order([p.player_id for p in self.game_state.players])

        print(f"游戏初始化完成，{len(self.game_state.players)} 名玩家已就位。")

    def _create_role(self, role_type: str, player_id: int):
        """创建角色实例

        Args:
            role_type: 角色类型
            player_id: 玩家ID

        Returns:
            角色实例
        """
        role_map = {
            "werewolf": Werewolf,
            "seer": Seer,
            "witch": Witch,
            "hunter": Hunter,
            "villager": Villager,
            "idiot": Idiot,
        }
        role_class = role_map.get(role_type, Villager)
        return role_class(player_id=player_id)

    def _index_to_phase(self, idx: int) -> str:
        nights = ["night_wolf", "night_seer", "night_witch", "night_result"]
        if idx < 4:
            return nights[idx]
        day_phases = ["day_start"]
        if self.game_state.day_number == 1 and not self.game_state.election_done:
            day_phases.append("election")
        day_phases.extend(["speech", "vote", "day_end"])
        return day_phases[idx - 4]

    def _day_phase_count(self) -> int:
        count = 4
        if self.game_state.day_number == 1 and not self.game_state.election_done:
            count += 1
        return count

    def submit_human_action(self, player_id: int, decision: Dict[str, Any]) -> bool:
        if not self._pending_human:
            return False
        if self._pending_human.get("player_id") != player_id:
            return False
        key = self._pending_human["key"]
        self._human_action_buffer[key] = decision
        self._pending_human = None
        return True

    def _human_buffer_key(self, action_type: str, player_id: int) -> str:
        return f"{action_type}_{self.game_state.day_number}_{self._step_index}_{player_id}"

    async def _resolve_decision(
        self,
        player: Player,
        action_type: str,
        ai_coro,
    ) -> Optional[Dict[str, Any]]:
        if player.player_id in self.human_player_ids:
            key = self._human_buffer_key(action_type, player.player_id)
            if key in self._human_action_buffer:
                return self._human_action_buffer.pop(key)
            self._pending_human = {
                "player_id": player.player_id,
                "player_name": player.name,
                "action_type": action_type,
                "key": key,
                "context": self.game_state.get_player_private_context(player.player_id),
            }
            return None
        if ai_coro is None:
            return {}
        if asyncio.iscoroutine(ai_coro):
            return await ai_coro
        return ai_coro

    def _build_step_response(
        self,
        phase_name: str,
        step_data: Dict[str, Any],
        dialog_len_before: int,
        death_len_before: int,
        is_game_over: bool = False,
        winner: Optional[str] = None,
        awaiting_human: bool = False,
    ) -> Dict[str, Any]:
        new_dialogues = self.game_state.dialogues[dialog_len_before:]
        new_deaths = self.death_records[death_len_before:]
        resp = {
            "phase": phase_name,
            "day_number": self.game_state.day_number,
            "step_data": step_data,
            "players": [p.to_dict() for p in self.game_state.players],
            "dialogues": new_dialogues,
            "deaths": new_deaths,
            "is_game_over": is_game_over,
            "winner": winner,
            "awaiting_human": awaiting_human,
            "pending_human": self._pending_human,
        }
        return resp

    async def start(self, controller=None):
        """开始游戏

        Args:
            controller: 可选的游戏控制器，用于手动控制游戏流程
        """
        self._is_running = True
        self._controller = controller
        print("=" * 50)
        print("狼人杀游戏开始！")
        print("=" * 50)

        # 游戏循环
        while self._is_running and not self.game_state.is_game_over():
            # 检查控制器的状态
            if self._controller:
                action = await self._controller.wait_if_needed(
                    self.game_state.day_number, "day_start"
                )
                if action == "stop":
                    self._is_running = False
                    break
                elif action == "skip_to_end":
                    # 直接跳到胜负判定
                    break

            # 夜晚阶段
            await self._night_phase()

            # 检查游戏是否结束
            if self.game_state.is_game_over():
                break

            # 白天阶段
            await self._day_phase()

            # 增加天数
            self.game_state.day_number += 1

        # 游戏结束
        await self._end_game()

    async def step(self) -> Dict[str, Any]:
        if not self.game_state.players:
            raise RuntimeError("Game not initialized. Call initialize() first.")

        if self._pending_human:
            return self._build_step_response(
                "human_input",
                {"pending": self._pending_human},
                len(self.game_state.dialogues),
                len(self.death_records),
                awaiting_human=True,
            )

        if self._step_index == -1:
            winner = self.game_state.get_winner()
            return self._build_step_response(
                "game_over",
                {},
                len(self.game_state.dialogues),
                len(self.death_records),
                is_game_over=True,
                winner=winner,
            )

        if self.game_state.is_game_over() and self._step_index != SUMMARY_STEP_INDEX and not self._summaries_done:
            self._step_index = SUMMARY_STEP_INDEX

        if self._step_index == SUMMARY_STEP_INDEX:
            await self._run_summaries()
            self._step_index = -1
            self._summaries_done = True
            winner = self.game_state.get_winner()
            return self._build_step_response(
                "summary",
                {"summaries_complete": True, "summaries": list(self.summaries), "evaluation": self.evaluation},
                len(self.game_state.dialogues),
                len(self.death_records),
                is_game_over=True,
                winner=winner,
            )

        dialog_len_before = len(self.game_state.dialogues)
        death_len_before = len(self.death_records)
        phase_name = self._index_to_phase(self._step_index)
        step_data: Dict[str, Any] = {}

        if phase_name == "night_wolf":
            self.game_state.clear_night_deaths()
            self._night_death_causes.clear()
            self.game_state.phase = GamePhase.NIGHT_WOLF
            self._abort_day_after_speech = False
            waited = await self._wolf_kill()
            if waited:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            wolf_votes = [
                {"player_id": d["player_id"], "target": d.get("target"), "reasoning": d.get("reasoning")}
                for d in self.game_state.dialogues[dialog_len_before:] if d.get("action") == "night_kill"
            ]
            step_data = {
                "wolf_votes": wolf_votes,
                "final_target": self.game_state.night_deaths[-1] if self.game_state.night_deaths else None,
            }

        elif phase_name == "night_seer":
            self.game_state.phase = GamePhase.NIGHT_SEER
            waited = await self._seer_check()
            if waited:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            for d in self.game_state.dialogues[dialog_len_before:]:
                if d.get("action") == "seer_check":
                    step_data = {
                        "seer_id": d["player_id"],
                        "target": d.get("target"),
                        "result": d.get("result"),
                        "reasoning": d.get("reasoning"),
                    }

        elif phase_name == "night_witch":
            self.game_state.phase = GamePhase.NIGHT_WITCH
            waited = await self._witch_action()
            if waited:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            for d in self.game_state.dialogues[dialog_len_before:]:
                if d.get("action") in ("heal", "poison"):
                    step_data = {"action": d["action"], "target": d.get("target")}

        elif phase_name == "night_result":
            await self._announce_night_deaths()
            hunter_wait = await self._handle_hunter_death(list(self.game_state.night_deaths))
            if hunter_wait:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            step_data = {
                "night_deaths": list(self.game_state.night_deaths),
                "deaths": self.death_records[death_len_before:],
            }

        elif phase_name == "day_start":
            self.game_state.phase = GamePhase.DAY_START
            await self._announce_day_start()
            step_data = {"sheriff_id": self.game_state.sheriff_id}

        elif phase_name == "election":
            self.game_state.phase = GamePhase.ELECTION
            waited = await self._sheriff_election()
            if waited:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            step_data = {
                "sheriff_id": self.game_state.sheriff_id,
                "election_done": self.game_state.election_done,
            }

        elif phase_name == "speech":
            self.game_state.phase = GamePhase.SPEECH
            waited, speech_data = await self._public_speeches()
            if waited:
                return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
            step_data = speech_data
            if self._abort_day_after_speech:
                self._step_index = 4 + self._day_phase_count() - 1
                return self._build_step_response(phase_name, step_data, dialog_len_before, death_len_before)

        elif phase_name == "vote":
            if self._abort_day_after_speech:
                step_data = {"skipped": True, "reason": "self_destruct"}
            else:
                self.game_state.phase = GamePhase.VOTE
                waited = await self._vote()
                if waited:
                    return self._build_step_response("human_input", {}, dialog_len_before, death_len_before, awaiting_human=True)
                votes = {}
                for d in self.game_state.dialogues[dialog_len_before:]:
                    if d.get("action") == "vote":
                        votes[d["player_id"]] = d.get("target")
                eliminated = None
                for death in self.death_records[death_len_before:]:
                    if death.get("cause") in ("vote", "shoot"):
                        eliminated = death["player_id"]
                step_data = {"votes": votes, "eliminated": eliminated}

        elif phase_name == "day_end":
            game_over = self.game_state.is_game_over()
            winner = self.game_state.get_winner()
            step_data = {
                "game_over": game_over,
                "winner": winner,
                "next_day": self.game_state.day_number + 1 if not game_over else None,
            }
            if game_over:
                self._is_running = False
                self._step_index = SUMMARY_STEP_INDEX
            else:
                self.game_state.day_number += 1
                self._step_index = 0
            return self._build_step_response(
                phase_name,
                step_data,
                dialog_len_before,
                death_len_before,
                is_game_over=game_over,
                winner=winner if game_over else None,
            )

        self._step_index += 1
        return self._build_step_response(phase_name, step_data, dialog_len_before, death_len_before)

    async def _night_phase(self):
        """执行夜晚阶段"""
        day = self.game_state.day_number
        print(f"\n{'='*30} 第 {day} 夜 {'='*30}")
        self._log("info", f"=== 第 {day} 夜 ===")

        # 清除之前的夜晚死亡记录
        self.game_state.clear_night_deaths()
        self._night_death_causes.clear()

        # 获取夜间行动顺序
        night_order = TurnOrder.get_night_order()

        for phase in night_order:
            # 检查是否还有需要执行的夜间阶段
            if self.game_state.is_game_over():
                break

            self.game_state.phase = phase
            print(f"\n[{phase.value}]")
            self._log("debug", f"阶段: {phase.value}")

            if phase == GamePhase.NIGHT_WOLF:
                await self._wolf_kill()
            elif phase == GamePhase.NIGHT_SEER:
                await self._seer_check()
            elif phase == GamePhase.NIGHT_WITCH:
                await self._witch_action()

        # 夜晚结束，宣布死亡
        await self._announce_night_deaths()

        # 处理猎人死亡开枪（在死亡标记之后）
        await self._handle_hunter_death(self.game_state.night_deaths)

    async def _wolf_kill(self) -> bool:
        alive_wolves = [
            p for p in self.game_state.players
            if p.role_type == RoleType.WEREWOLF and p.is_alive
        ]
        if not alive_wolves:
            return False

        kill_targets = []
        for wolf in alive_wolves:
            game_state = self.game_state.get_player_private_context(wolf.player_id)

            async def _ai():
                return await wolf.agent.decide_night_action(game_state)

            decision = await self._resolve_decision(wolf, "night_action", _ai() if wolf.agent else None)
            if decision is None:
                return True

            target = decision.get("target")
            reasoning = decision.get("reasoning", "")
            thought = decision.get("thought", reasoning)
            if target is not None and target != wolf.player_id:
                kill_targets.append(target)
            self.game_state.dialogues.append({
                "day": self.game_state.day_number,
                "phase": "狼人杀人",
                "player_id": wolf.player_id,
                "player_name": wolf.name,
                "role": wolf.role.name,
                "action": "night_kill",
                "target": target,
                "reasoning": reasoning,
                "thought": thought,
            })

        if kill_targets:
            target = self._count_vote(kill_targets)
            self.game_state.add_night_death(target)
            self._night_death_causes[target] = "night_kill"
        return False

    async def _seer_check(self) -> bool:
        alive_seers = [
            p for p in self.game_state.players
            if p.role_type == RoleType.SEER and p.is_alive
        ]

        for seer in alive_seers:
            game_state = self.game_state.get_player_private_context(seer.player_id)

            async def _ai():
                return await seer.agent.decide_night_action(game_state)

            decision = await self._resolve_decision(seer, "night_action", _ai() if seer.agent else None)
            if decision is None:
                return True
            target = decision.get("target")
            reasoning = decision.get("reasoning", "")
            thought = decision.get("thought", reasoning)
            if target is not None:
                player = self.game_state.get_player(target)
                if player:
                    result = "wolf" if player.role_type == RoleType.WEREWOLF else "good"
                    seer.role._check_result = {"target": target, "result": result}
                    if not hasattr(seer.role, "_check_history"):
                        seer.role._check_history = []
                    seer.role._check_history.append({"target": target, "result": result})
                    self.game_state.dialogues.append({
                        "day": self.game_state.day_number,
                        "phase": "预言家查验",
                        "player_id": seer.player_id,
                        "player_name": seer.name,
                        "role": seer.role.name,
                        "action": "seer_check",
                        "target": target,
                        "result": result,
                        "reasoning": reasoning,
                        "thought": thought,
                    })
        return False

    async def _witch_action(self) -> bool:
        alive_witches = [
            p for p in self.game_state.players
            if p.role_type == RoleType.WITCH and p.is_alive
        ]

        tonight_death = self.game_state.night_deaths[-1] if self.game_state.night_deaths else None

        for witch in alive_witches:
            if not (witch.role.has_heal or witch.role.has_poison):
                continue
            game_state = self.game_state.get_player_private_context(witch.player_id)
            game_state["tonight_death"] = tonight_death
            if tonight_death == witch.player_id:
                game_state["cannot_self_heal"] = True

            async def _ai():
                return await witch.agent.decide_night_action(game_state)

            decision = await self._resolve_decision(witch, "night_action", _ai() if witch.agent else None)
            if decision is None:
                return True

            action = decision.get("action", "")
            target = decision.get("target")
            used_heal = (
                "heal" in action
                and tonight_death is not None
                and tonight_death != witch.player_id
                and witch.role.has_heal
            )
            used_poison = (
                "poison" in action
                and target is not None
                and witch.role.has_poison
                and target != witch.player_id
            )

            if used_heal:
                witch.role.use_heal()
                if tonight_death in self.game_state.night_deaths:
                    self.game_state.night_deaths.remove(tonight_death)
            elif used_poison:
                witch.role.use_poison()
                self.game_state.add_night_death(target)
                self._night_death_causes[target] = "poison"

            if used_heal or used_poison:
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "女巫用药",
                    "player_id": witch.player_id,
                    "player_name": witch.name,
                    "role": witch.role.name,
                    "action": "heal" if used_heal else "poison",
                    "target": tonight_death if used_heal else target,
                    "thought": decision.get("thought", decision.get("reasoning", "")),
                })
        return False

    async def _handle_hunter_death(self, killed_player_ids: List[int]) -> bool:
        for player_id in killed_player_ids:
            player = self.game_state.get_player(player_id)
            if not player or player.role_type != RoleType.HUNTER or not player.role.can_shoot:
                continue
            cause = self._night_death_causes.get(player_id, "night_kill")
            if cause == "poison":
                player.role.lock_shoot()
                continue

            game_state = self.game_state.get_player_private_context(player_id)
            game_state["hunter_shoot"] = True

            async def _ai():
                return await player.agent.decide_night_action(game_state)

            decision = await self._resolve_decision(player, "hunter_shot", _ai() if player.agent else None)
            if decision is None:
                return True

            target = decision.get("target")
            alive_ids = {p.player_id for p in self.game_state.get_alive_players()}
            if target is None or target not in alive_ids:
                player.role.lock_shoot()
                continue

            player.role.lock_shoot()
            target_player = self.game_state.get_player(target)
            if target_player:
                target_player.role.is_alive = False
                self.death_records.append({
                    "player_id": target,
                    "player_name": target_player.name,
                    "role": target_player.role.name,
                    "cause": "shoot",
                    "day": self.game_state.day_number,
                })
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "猎人开枪",
                    "player_id": player_id,
                    "player_name": player.name,
                    "role": player.role.name,
                    "action": "hunter_shot",
                    "target": target,
                    "thought": decision.get("thought", decision.get("reasoning", "")),
                })
                if self.game_state.is_game_over():
                    self._step_index = SUMMARY_STEP_INDEX
        return False

    async def _announce_night_deaths(self):
        """宣布夜晚死亡"""
        if self.game_state.night_deaths:
            for player_id in self.game_state.night_deaths:
                player = self.game_state.get_player(player_id)
                if player:
                    cause = self._night_death_causes.get(player_id, "night_kill")
                    player.kill(cause, self.game_state.to_dict())
                    print(f"玩家 {player_id} ({player.role.name}) 死亡")
                    self._log("log_death", f"玩家{player_id}({player.role.name}) 死亡")
                    # 记录死亡
                    self.death_records.append({
                        "player_id": player_id,
                        "player_name": player.name,
                        "role": player.role.name,
                        "cause": cause,
                        "day": self.game_state.day_number,
                    })
        else:
            print("今晚无人死亡")
            self._log("log_event", "今晚无人死亡")

    async def _day_phase(self):
        """执行白天阶段"""
        print(f"\n{'='*30} 第 {self.game_state.day_number} 天 {'='*30}")
        self._log("info", f"=== 第 {self.game_state.day_number} 天 ===")

        # 阶段1：宣布昨晚死亡
        self.game_state.phase = GamePhase.DAY_START
        await self._announce_day_start()

        if self.game_state.day_number == 1 and not self.game_state.election_done:
            self.game_state.phase = GamePhase.ELECTION
            await self._sheriff_election()

        self.game_state.phase = GamePhase.SPEECH
        _, speech_result = await self._public_speeches()
        if self._abort_day_after_speech:
            return

        self.game_state.phase = GamePhase.VOTE
        await self._vote()

    async def _announce_day_start(self):
        """宣布白天开始（不暴露死者角色，符合标准规则）"""
        if self.game_state.night_deaths:
            death_names = [f"玩家{p}" for p in self.game_state.night_deaths]
            print(f"昨晚死亡：{', '.join(death_names)}")
        else:
            print("昨晚是平安夜，无人死亡")

    async def _sheriff_election(self) -> bool:
        alive = self.game_state.get_alive_players()
        candidates = []

        for player in alive:
            game_state = self.game_state.get_player_private_context(player.player_id)
            game_state["election_mode"] = "run"

            gs = dict(game_state)

            async def _ai_run(p=player, g=gs):
                return await p.agent.decide_election(g)

            decision = await self._resolve_decision(
                player, "election_run", _ai_run() if player.agent else None
            )
            if decision is None:
                return True
            if decision.get("run", False):
                candidates.append(player.player_id)
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "警长选举",
                    "player_id": player.player_id,
                    "player_name": player.name,
                    "action": "sheriff_run",
                    "content": decision.get("content", ""),
                })

        if not candidates:
            candidates = [alive[0].player_id]

        vote_weights: Dict[int, float] = {}
        for player in alive:
            if player.player_id in candidates:
                continue
            game_state = self.game_state.get_player_private_context(player.player_id)
            game_state["election_mode"] = "vote"
            game_state["candidates"] = candidates

            gs2 = dict(game_state)

            async def _ai_vote(p=player, g=gs2):
                return await p.agent.decide_election(g)

            decision = await self._resolve_decision(
                player, "election_vote", _ai_vote() if player.agent else None
            )
            if decision is None:
                return True
            target = decision.get("target")
            if target in candidates:
                weight = self.game_state.get_vote_weight(player.player_id)
                vote_weights[target] = vote_weights.get(target, 0) + weight

        if vote_weights:
            max_v = max(vote_weights.values())
            winners = [pid for pid, v in vote_weights.items() if v == max_v]
            sheriff_id = winners[0]
        else:
            sheriff_id = candidates[0]

        sheriff = self.game_state.get_player(sheriff_id)
        if sheriff:
            sheriff.is_sheriff = True
            self.game_state.sheriff_id = sheriff_id
            order = [sheriff_id] + [p.player_id for p in alive if p.player_id != sheriff_id]
            self.game_state.set_speaker_order(order)

        self.game_state.election_done = True
        self.game_state.dialogues.append({
            "day": self.game_state.day_number,
            "phase": "警长选举",
            "action": "sheriff_elected",
            "target": sheriff_id,
        })
        return False

    async def _public_speeches(self):
        alive_players = self.game_state.get_alive_players()
        order_ids = self.game_state.speaker_order or [p.player_id for p in alive_players]
        ordered = []
        for pid in order_ids:
            p = self.game_state.get_player(pid)
            if p and p.is_alive:
                ordered.append(p)
        for p in alive_players:
            if p not in ordered:
                ordered.append(p)

        speeches = []
        for player in ordered:
            game_state = self.game_state.get_player_private_context(player.player_id)

            async def _ai():
                return await player.agent.decide_speech(game_state)

            decision = await self._resolve_decision(player, "speech", _ai() if player.agent else None)
            if decision is None:
                return True, {"speeches": speeches}

            if decision.get("action") == "self_destruct" and player.role_type == RoleType.WEREWOLF:
                player.kill("self_destruct", self.game_state.to_dict())
                self.death_records.append({
                    "player_id": player.player_id,
                    "player_name": player.name,
                    "role": player.role.name,
                    "cause": "self_destruct",
                    "day": self.game_state.day_number,
                })
                self.game_state.dialogues.append({
                    "day": self.game_state.day_number,
                    "phase": "公开演讲",
                    "player_id": player.player_id,
                    "player_name": player.name,
                    "action": "self_destruct",
                    "thought": decision.get("thought", ""),
                })
                self._abort_day_after_speech = True
                return False, {"self_destruct": player.player_id, "speeches": speeches}

            content = decision.get("content", "")
            thought = decision.get("thought", "")
            self.game_state.dialogues.append({
                "day": self.game_state.day_number,
                "phase": "公开演讲",
                "player_id": player.player_id,
                "player_name": player.name,
                "role": player.role.name,
                "action": "speech",
                "content": content,
                "thought": thought,
            })
            speeches.append({
                "player_id": player.player_id,
                "player_name": player.name,
                "content": content,
                "thought": thought,
            })
        return False, {"speeches": speeches}

    async def _vote(self) -> bool:
        alive_players = self.game_state.get_alive_players()
        vote_weights: Dict[int, float] = {}

        for player in alive_players:
            if player.role_type == RoleType.IDIOT and getattr(player.role, "revealed", False):
                continue
            if not player.role.can_vote():
                continue

            game_state = self.game_state.get_player_private_context(player.player_id)

            async def _ai():
                return await player.agent.decide_vote(game_state)

            decision = await self._resolve_decision(player, "vote", _ai() if player.agent else None)
            if decision is None:
                return True

            target = decision.get("target")
            if target is not None:
                tp = self.game_state.get_player(target)
                if tp and tp.is_alive:
                    weight = self.game_state.get_vote_weight(player.player_id)
                    vote_weights[target] = vote_weights.get(target, 0) + weight
                    self.game_state.add_vote(player.player_id, target)
                    self.game_state.dialogues.append({
                        "day": self.game_state.day_number,
                        "phase": "投票",
                        "player_id": player.player_id,
                        "player_name": player.name,
                        "role": player.role.name,
                        "action": "vote",
                        "target": target,
                        "thought": decision.get("thought", ""),
                    })

        if vote_weights:
            max_votes = max(vote_weights.values())
            eliminated = [pid for pid, c in vote_weights.items() if c == max_votes]
            if len(eliminated) == 1:
                eid = eliminated[0]
                victim = self.game_state.get_player(eid)
                if victim and victim.role_type == RoleType.IDIOT and not victim.role.revealed:
                    victim.role.reveal()
                    self.game_state.dialogues.append({
                        "day": self.game_state.day_number,
                        "phase": "投票",
                        "action": "idiot_reveal",
                        "player_id": eid,
                    })
                else:
                    victim.kill("vote", self.game_state.to_dict())
                    self.death_records.append({
                        "player_id": eid,
                        "player_name": victim.name,
                        "role": victim.role.name,
                        "cause": "vote",
                        "day": self.game_state.day_number,
                    })
                    waited = await self._handle_hunter_death([eid])
                    if waited:
                        return True

        self.game_state.reset_vote_record()
        return False

    async def _end_game(self):
        """游戏结束"""
        winner = self.game_state.get_winner()
        print(f"\n{'='*50}")
        print("游戏结束！")
        print(f"胜利方：{'善良阵营' if winner == 'good' else '邪恶阵营'}")
        print(f"{'='*50}")

        self._is_running = False

        # 生成总结并保存经验（仅当未通过 step() 执行过）
        if not self._summaries_done:
            await self._run_summaries()
            self._summaries_done = True

    async def _run_summaries(self):
        """游戏结束后为每个玩家生成总结并保存经验"""
        winner = self.game_state.get_winner()
        print(f"\n{'='*30} 玩家总结 {'='*30}")
        self._log("info", "=== 开始生成玩家总结 ===")

        camp_map = {"good": "good", "evil": "evil"}

        for player in self.game_state.players:
            if not player.agent:
                continue

            # 获取该玩家的视角（含信息隔离过滤）
            player_context = self.game_state.get_player_private_context(player.player_id)
            dialogues = player_context.get("dialogues", [])

            # 将对话格式化为可读文本
            history_lines = []
            for d in dialogues:
                phase = d.get("phase", "")
                action = d.get("action", "")
                content = d.get("content", "")
                target = d.get("target")

                if action == "night_kill":
                    history_lines.append(f"[夜晚] 你投票击杀玩家{target}（{d.get('reasoning', '')}）")
                elif action == "seer_check":
                    result = "狼人" if d.get("result") == "wolf" else "好人"
                    history_lines.append(f"[夜晚] 你查验玩家{target}，结果：{result}")
                elif action == "heal":
                    history_lines.append(f"[夜晚] 你使用解药救活了玩家{target}")
                elif action == "poison":
                    history_lines.append(f"[夜晚] 你使用毒药毒杀了玩家{target}")
                elif action == "speech":
                    history_lines.append(f"[白天] 你发言：{content[:100]}")
                elif action == "vote":
                    history_lines.append(f"[白天] 你投票给玩家{target}")
                elif action == "hunter_shot":
                    history_lines.append(f"[夜晚] 你开枪带走了玩家{target}")

            # 添加死亡信息
            for death in self.death_records:
                if death["player_id"] == player.player_id:
                    cause_map = {"night_kill": "被狼人杀害", "poison": "被毒杀", "vote": "被投票出局", "shoot": "被枪杀"}
                    history_lines.append(f"[死亡] 你在第{death['day']}天{cause_map.get(death['cause'], death['cause'])}")

            personal_history = "\n".join(history_lines) if history_lines else "无记录"

            # 调用总结代理
            summary_data = await self._summary_agent.generate_summary(
                player_name=player.name,
                role_name=player.role.name,
                camp=player.camp.value,
                winner=winner,
                personal_history=personal_history,
            )

            # 保存经验
            role_type = player.role.role_type.value  # "werewolf", "seer" 等
            experience = {
                "game_id": self.game_id,
                "player_id": player.player_id,
                "player_name": player.name,
                "camp": player.camp.value,
                "winner": winner,
                "is_winner": player.camp.value == winner,
                **summary_data,
            }
            save_experience(role_type, experience)

            # 存入内存供 API 展示
            self.summaries.append({
                "player_id": player.player_id,
                "player_name": player.name,
                "role": player.role.name,
                "camp": player.camp.value,
                "role_type": role_type,
                "is_winner": player.camp.value == winner,
                **summary_data,
            })

            print(f"  {player.name}({player.role.name}) 总结已保存")
            self._log("info", f"玩家{player.name} 的总结经验已保存")

        print(f"{'='*30} 总结完成 {'='*30}")
        self._log("info", "=== 所有玩家总结完成 ===")

        winner = self.game_state.get_winner()
        players_dict = [p.to_dict() for p in self.game_state.players]
        try:
            from schema.system_config import load_system_config
            model_name = load_system_config("config/system_config.json").default_model
        except Exception:
            model_name = "default"

        self.evaluation = evaluate_game(
            self.game_id or "unknown",
            winner or "unknown",
            self.death_records,
            self.game_state.dialogues,
            players_dict,
            self.game_state.day_number,
        )
        record_game_result(
            self.game_id or "unknown",
            model_name,
            winner or "unknown",
            self.config_name,
            self.game_state.day_number,
            self.evaluation.get("player_scores"),
        )

    def _count_vote(self, targets: List[int]) -> int:
        """统计票数，返回最高票的目标"""
        from collections import Counter
        count = Counter(targets)
        return count.most_common(1)[0][0]

    def stop(self):
        """停止游戏"""
        self._is_running = False


async def create_game(player_names: List[str], role_assignment: Dict[int, str]) -> GameEngine:
    """工厂函数：创建并初始化游戏

    Args:
        player_names: 玩家名称列表
        role_assignment: 角色分配

    Returns:
        GameEngine实例
    """
    engine = GameEngine(player_names)
    await engine.initialize(role_assignment)
    return engine


# 标准6人局角色配置
STANDARD_6P_ROLES = {
    0: "werewolf",
    1: "werewolf",
    2: "seer",
    3: "witch",
    4: "hunter",
    5: "villager",
}

# 预定义角色配置
ROLE_CONFIGS = {
    "standard_6": {
        "name": "标准6人局",
        "description": "2狼、1预言家、1女巫、1猎人、1村民",
        "roles": {
            0: "werewolf",
            1: "werewolf",
            2: "seer",
            3: "witch",
            4: "hunter",
            5: "villager",
        }
    },
    "simple_4": {
        "name": "简易4人局",
        "description": "1狼、1预言家、1女巫、1村民",
        "roles": {
            0: "werewolf",
            1: "seer",
            2: "witch",
            3: "villager",
        }
    },
    "big_9": {
        "name": "标准9人局",
        "description": "3狼、1预言家、1女巫、1猎人、2村民、1白痴",
        "roles": {
            0: "werewolf",
            1: "werewolf",
            2: "werewolf",
            3: "seer",
            4: "witch",
            5: "hunter",
            6: "villager",
            7: "villager",
            8: "idiot",  # 白痴（暂未实现）
        }
    },
}


def get_role_config(config_name: str) -> Dict[int, str]:
    """获取角色配置

    Args:
        config_name: 配置名称，如 "standard_6", "simple_4"

    Returns:
        角色分配字典
    """
    if config_name in ROLE_CONFIGS:
        return ROLE_CONFIGS[config_name]["roles"].copy()
    else:
        raise ValueError(f"Unknown config: {config_name}. Available: {list(ROLE_CONFIGS.keys())}")


def shuffle_roles(role_assignment: Dict[int, str]) -> Dict[int, str]:
    """随机打乱角色分配

    Args:
        role_assignment: 原始角色分配

    Returns:
        打乱后的角色分配
    """
    import random
    roles = list(role_assignment.values())
    random.shuffle(roles)
    return {i: r for i, r in enumerate(roles)}


def create_random_roles(num_players: int, wolf_ratio: float = 0.3) -> Dict[int, str]:
    """根据玩家数量和狼人比例随机生成角色

    Args:
        num_players: 玩家数量
        wolf_ratio: 狼人比例，默认0.3

    Returns:
        随机角色分配
    """
    import random

    num_wolves = max(1, int(num_players * wolf_ratio))
    num_gods = max(1, num_players // 6)
    num_villagers = num_players - num_wolves - num_gods

    roles = (
        ["werewolf"] * num_wolves +
        ["seer", "witch", "hunter"][:num_gods] +
        ["villager"] * num_villagers
    )

    # 确保有狼人和好人
    if "werewolf" not in roles:
        roles[0] = "werewolf"
    if not any(r in roles for r in ["seer", "witch", "hunter"]):
        roles[1] = "seer"

    random.shuffle(roles)
    return {i: r for i, r in enumerate(roles)}


async def run_game(player_names: List[str] = None, config_name: str = "standard_6", shuffle: bool = True):
    """运行游戏

    Args:
        player_names: 玩家名称列表，默认使用默认名称
        config_name: 角色配置名称，如 "standard_6", "simple_4", "big_9"
        shuffle: 是否打乱角色分配，默认True
    """
    if player_names is None:
        config = ROLE_CONFIGS.get(config_name, ROLE_CONFIGS["standard_6"])
        player_names = [f"玩家{i+1}" for i in range(len(config["roles"]))]

    # 获取角色配置
    role_assignment = get_role_config(config_name)

    # 打乱角色（可选）
    if shuffle:
        role_assignment = shuffle_roles(role_assignment)

    print(f"使用配置：{ROLE_CONFIGS[config_name]['name']}")
    print(f"角色分配：{role_assignment}")

    game = await create_game(player_names, role_assignment)
    await game.start()


if __name__ == "__main__":
    asyncio.run(run_game())