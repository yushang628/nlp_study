const BASE = ''

export async function createGame(configName, shuffle = true, humanPlayerIds = null) {
  const body = { config_name: configName, shuffle }
  if (humanPlayerIds && humanPlayerIds.length) {
    body.human_player_ids = humanPlayerIds
  }
  const res = await fetch(`${BASE}/games`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`创建游戏失败: ${res.status}`)
  return res.json()
}

export async function stepGame(gameId) {
  const res = await fetch(`${BASE}/games/${gameId}/step`, { method: 'POST' })
  if (!res.ok) throw new Error(`推进游戏失败: ${res.status}`)
  return res.json()
}

export async function getGameStatus(gameId) {
  const res = await fetch(`${BASE}/games/${gameId}`)
  if (!res.ok) throw new Error(`获取游戏状态失败: ${res.status}`)
  return res.json()
}

export async function deleteGame(gameId) {
  const res = await fetch(`${BASE}/games/${gameId}`, { method: 'DELETE' })
  if (!res.ok) throw new Error(`删除游戏失败: ${res.status}`)
  return res.json()
}

export async function getConfigs() {
  const res = await fetch(`${BASE}/configs`)
  if (!res.ok) throw new Error(`获取配置失败: ${res.status}`)
  return res.json()
}

export async function getGameSummaries(gameId) {
  const res = await fetch(`${BASE}/games/${gameId}/summaries`)
  if (!res.ok) throw new Error(`获取总结失败: ${res.status}`)
  return res.json()
}

export async function submitHumanAction(gameId, playerId, decision) {
  const res = await fetch(`${BASE}/games/${gameId}/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ player_id: playerId, decision }),
  })
  if (!res.ok) throw new Error(`提交操作失败: ${res.status}`)
  return res.json()
}

export async function getLeaderboard() {
  const res = await fetch(`${BASE}/leaderboard`)
  if (!res.ok) throw new Error(`获取排行榜失败: ${res.status}`)
  return res.json()
}
