<template>
  <div v-if="pending" class="human-panel">
    <h3>你的回合：{{ pending.player_name }}</h3>
    <p class="action-type">行动类型：{{ actionLabel }}</p>

    <div v-if="pending.action_type === 'election_run'" class="form-row">
      <label>
        <input type="checkbox" v-model="form.run" />
        竞选警长
      </label>
      <textarea v-model="form.content" placeholder="竞选发言（可选）" rows="3" />
    </div>

    <div v-else-if="pending.action_type === 'election_vote'" class="form-row">
      <label>投票选警长（候选人 ID）</label>
      <input v-model.number="form.target" type="number" min="0" />
    </div>

    <div v-else-if="pending.action_type === 'speech'" class="form-row">
      <textarea v-model="form.content" placeholder="发言内容" rows="4" />
      <label v-if="isWerewolf" class="destruct">
        <input type="checkbox" v-model="form.selfDestruct" />
        狼人自爆（跳过投票直接进入夜晚）
      </label>
    </div>

    <div v-else-if="pending.action_type === 'vote'" class="form-row">
      <label>投票目标玩家 ID（留空为弃票）</label>
      <input v-model.number="form.target" type="number" min="0" />
    </div>

    <div v-else class="form-row">
      <label>目标玩家 ID</label>
      <input v-model.number="form.target" type="number" min="0" />
      <input v-model="form.action" placeholder="行动，如 heal / poison / night_action" />
    </div>

    <button class="primary" :disabled="submitting" @click="submit">
      {{ submitting ? '提交中...' : '提交决策' }}
    </button>
  </div>
</template>

<script setup>
import { ref, computed, watch } from 'vue'

const props = defineProps({
  pending: { type: Object, default: null },
  humanRole: { type: String, default: '' },
  submitting: { type: Boolean, default: false },
})

const emit = defineEmits(['submit'])

const form = ref({
  run: false,
  content: '',
  target: null,
  action: 'night_action',
  selfDestruct: false,
})

const actionLabels = {
  night_action: '夜间行动',
  speech: '白天发言',
  vote: '投票',
  election_run: '警长竞选',
  election_vote: '警长投票',
  hunter_shot: '猎人开枪',
}

const actionLabel = computed(() => actionLabels[props.pending?.action_type] || props.pending?.action_type)
const isWerewolf = computed(() => props.humanRole === 'werewolf')

watch(() => props.pending, () => {
  form.value = { run: false, content: '', target: null, action: 'night_action', selfDestruct: false }
})

function submit() {
  const p = props.pending
  if (!p) return
  let decision = {}
  if (p.action_type === 'election_run') {
    decision = { run: form.value.run, content: form.value.content, thought: form.value.content }
  } else if (p.action_type === 'election_vote') {
    decision = { target: form.value.target, thought: '' }
  } else if (p.action_type === 'speech') {
    if (form.value.selfDestruct && isWerewolf.value) {
      decision = { action: 'self_destruct', thought: form.value.content }
    } else {
      decision = { action: 'speech', content: form.value.content, thought: form.value.content }
    }
  } else if (p.action_type === 'vote') {
    decision = { action: 'vote', target: form.value.target ?? null, thought: '' }
  } else {
    decision = { action: form.value.action || 'night_action', target: form.value.target, thought: '' }
  }
  emit('submit', p.player_id, decision)
}
</script>

<style scoped>
.human-panel {
  background: var(--bg-secondary);
  border: 2px solid var(--accent-blue);
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 20px;
}
.human-panel h3 {
  margin-bottom: 8px;
}
.action-type {
  color: var(--text-muted);
  font-size: 13px;
  margin-bottom: 12px;
}
.form-row {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 12px;
}
textarea, input[type='number'], input[type='text'] {
  width: 100%;
  padding: 8px;
  border-radius: 6px;
  border: 1px solid var(--border-color);
  background: var(--bg-card);
  color: var(--text-primary);
}
.destruct {
  color: var(--accent-red);
  font-size: 13px;
}
.human-panel button {
  width: 100%;
  padding: 10px;
}
</style>
