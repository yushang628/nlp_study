import asyncio
import argparse
from schema.system_config import load_system_config
from engine.game_engine import GameEngine, get_role_config, shuffle_roles, ROLE_CONFIGS
from evaluation.leaderboard import get_leaderboard


async def run_batch(config_name: str, rounds: int, shuffle: bool = True):
    config = load_system_config("config/system_config.json")
    model_name = config.default_model
    wins = {"good": 0, "evil": 0}

    for i in range(rounds):
        roles = get_role_config(config_name)
        if shuffle:
            roles = shuffle_roles(roles)
        count = len(roles)
        names = [f"玩家{j+1}" for j in range(count)]
        engine = GameEngine(names)
        engine.config_name = config_name
        engine.game_id = f"evo_{i:04d}"
        await engine.initialize(roles)

        while engine._step_index != -1:
            if engine._pending_human:
                break
            result = await engine.step()
            if result.get("awaiting_human"):
                break
            if result.get("phase") == "summary":
                break

        winner = engine.game_state.get_winner()
        if winner:
            wins[winner] = wins.get(winner, 0) + 1
        print(f"Round {i+1}/{rounds} winner={winner} day={engine.game_state.day_number}")

    print(f"\nModel: {model_name}")
    print(f"Good wins: {wins.get('good', 0)}  Evil wins: {wins.get('evil', 0)}")
    print("\nLeaderboard:")
    for row in get_leaderboard()[:10]:
        print(row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", default="standard_6")
    parser.add_argument("-n", "--rounds", type=int, default=10)
    parser.add_argument("--no-shuffle", action="store_true")
    args = parser.parse_args()
    if args.config not in ROLE_CONFIGS:
        raise SystemExit(f"Unknown config: {args.config}")
    asyncio.run(run_batch(args.config, args.rounds, shuffle=not args.no_shuffle))


if __name__ == "__main__":
    main()
