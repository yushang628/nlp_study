import { useEffect, useRef, useState, useCallback } from 'react'
import { GamePublicState } from '../types/game'

export function useWebSocket(
  gameId: string,
  onState: (state: GamePublicState) => void,
) {
  const wsRef = useRef<WebSocket | null>(null)
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    if (!gameId) return

    // Connect directly to backend (bypass Vite proxy for WebSocket reliability)
    const wsUrl = `ws://localhost:8000/api/games/${gameId}/ws`

    const ws = new WebSocket(wsUrl)
    wsRef.current = ws

    ws.onopen = () => setConnected(true)

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data)
        if (msg.type === 'game_state' && msg.data) {
          const gs = msg.data as GamePublicState
          console.log(`[WS] game_state phase=${gs.phase} round=${gs.round_number} chat=${gs.chat_log?.length || 0} players=${gs.players?.length || 0} speaker=${gs.current_speaker || '-'}`)
          onState(gs)
        } else {
          console.log('[WS] Received:', msg.type)
        }
      } catch {
        console.log('[WS] Malformed message:', event.data)
      }
    }

    ws.onclose = () => setConnected(false)
    ws.onerror = () => setConnected(false)

    return () => {
      ws.close()
      wsRef.current = null
    }
  }, [gameId, onState])

  const sendAction = useCallback((playerId: string, actionType: string, target: string, text?: string) => {
    const payload = {
      type: 'human_action',
      player_id: playerId,
      action: { type: actionType, target, message: text },
    }
    console.log('[WS] Sending human_action:', payload, 'ws state:', wsRef.current?.readyState)
    wsRef.current?.send(JSON.stringify(payload))
  }, [])

  const sendChat = useCallback((playerId: string, content: string): boolean => {
    const ws = wsRef.current
    console.log(`[WS] sendChat: ws=${!!ws} readyState=${ws?.readyState} player=${playerId} content=${content.slice(0, 20)}`)
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      console.error('[WS] Cannot send chat: WebSocket not open! readyState=', ws?.readyState)
      return false
    }
    try {
      ws.send(JSON.stringify({
        type: 'human_chat',
        player_id: playerId,
        content,
      }))
      return true
    } catch (e) {
      console.error('[WS] sendChat error:', e)
      return false
    }
  }, [])

  return { connected, sendAction, sendChat }
}
