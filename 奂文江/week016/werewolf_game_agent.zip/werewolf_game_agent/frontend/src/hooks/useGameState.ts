import { useState, useCallback } from 'react'
import { GamePublicState } from '../types/game'

const initial: GamePublicState = {
  phase: 'lobby',
  round_number: 0,
  players: [],
  chat_log: [],
  vote_results: null,
  night_deaths: [],
  winner: null,
  timer_remaining: null,
  current_speaker: '',
  speaker_index: 0,
  total_speakers: 0,
  timeline: [],
}

export function useGameState() {
  const [gameState, setGameState] = useState<GamePublicState>(initial)

  return { gameState, setGameState }
}
