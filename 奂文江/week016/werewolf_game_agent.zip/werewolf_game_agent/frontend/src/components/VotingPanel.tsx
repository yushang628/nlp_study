import { VoteResult, PlayerPublic } from '../types/game'

interface Props {
  results: VoteResult | null
  players: PlayerPublic[]
}

export default function VotingPanel({ results, players }: Props) {
  if (!results) {
    return <div className="p-3 text-sm text-gray-500">等待投票结果...</div>
  }

  const nameMap = Object.fromEntries(players.map(p => [p.id, p.name]))

  // Count votes per target
  const counts: Record<string, number> = {}
  Object.values(results.votes).forEach((target) => {
    if (target && target !== 'abstain') {
      counts[target] = (counts[target] || 0) + 1
    }
  })

  const sortedTargets = Object.entries(counts).sort((a, b) => b[1] - a[1])

  return (
    <div className="border-t border-gray-700 p-3">
      <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-2">🗳️ 投票统计</h3>

      {sortedTargets.length === 0 && (
        <p className="text-xs text-gray-500">全部弃权</p>
      )}

      {sortedTargets.map(([targetId, count]) => {
        const isEliminated = results.eliminated_id === targetId
        return (
          <div
            key={targetId}
            className={`flex items-center justify-between py-1 px-2 rounded text-sm ${
              isEliminated ? 'bg-red-900/40 border border-red-700/50' : ''
            }`}
          >
            <span>
              {nameMap[targetId] || targetId}
              {isEliminated && <span className="text-red-400 ml-1">← 放逐</span>}
            </span>
            <span className="font-mono font-bold">{count} 票</span>
          </div>
        )
      })}

      {/* Individual votes */}
      <div className="mt-3 space-y-1">
        <p className="text-xs text-gray-500">详细投票:</p>
        {Object.entries(results.votes).map(([voter, target]) => (
          <div key={voter} className="text-xs text-gray-400 flex justify-between">
            <span>{nameMap[voter] || voter}</span>
            <span>→ {target === 'abstain' ? '弃权' : (nameMap[target] || target)}</span>
          </div>
        ))}
      </div>

      {results.was_tie && (
        <p className="text-xs text-yellow-400 mt-2">⚠️ 平票，随机选择放逐目标</p>
      )}
    </div>
  )
}
