import { GamePublicState, ROLE_NAMES, ROLE_ICONS } from '../types/game'
import GameTimeline from './GameTimeline'

interface Props {
  state: GamePublicState
  onPlayAgain: () => void
}

export default function GameOverScreen({ state, onPlayAgain }: Props) {
  const winner = state.winner
  const winnerLabel = winner === 'werewolf' ? '🐺 狼人阵营' : '🛡️ 好人阵营'
  const aliveCount = state.players.filter(p => p.is_alive).length
  const deadCount = state.players.length - aliveCount

  // Speaker stats: most active
  const speakerCounts: Record<string, number> = {}
  state.chat_log.forEach(m => {
    speakerCounts[m.speaker_name] = (speakerCounts[m.speaker_name] || 0) + 1
  })
  let mvp = ''
  let mvpCount = 0
  Object.entries(speakerCounts).forEach(([name, count]) => {
    if (count > mvpCount) { mvp = name; mvpCount = count }
  })

  // Death log
  const deathLog: string[] = []
  state.timeline.forEach(ev => {
    if (ev.icon === '💀' || ev.icon === '☀️') {
      deathLog.push(ev.label === '平安夜' ? '🌙 平安夜' : `💀 ${ev.detail}`)
    }
  })

  // Werewolf count
  const wolfCount = state.players.filter(p => p.role === 'werewolf').length
  const wolfAlive = state.players.filter(p => p.role === 'werewolf' && p.is_alive).length

  return (
    <div className="bg-gray-800 rounded-2xl p-8 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <div className="text-6xl mb-4">{winner === 'werewolf' ? '🐺' : '🛡️'}</div>
        <h1 className="text-3xl font-bold">游戏结束</h1>
        <p className="text-xl text-yellow-400 mt-2">{winnerLabel} 获胜!</p>
      </div>

      {/* Key stats grid */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        <div className="bg-gray-900 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-white">{state.round_number}</div>
          <div className="text-[10px] text-gray-500">总轮数</div>
        </div>
        <div className="bg-gray-900 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-green-400">{aliveCount}</div>
          <div className="text-[10px] text-gray-500">存活</div>
        </div>
        <div className="bg-gray-900 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-red-400">{deadCount}</div>
          <div className="text-[10px] text-gray-500">死亡</div>
        </div>
        <div className="bg-gray-900 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-blue-400">{state.chat_log.length}</div>
          <div className="text-[10px] text-gray-500">发言数</div>
        </div>
      </div>

      {/* Wolf vs Villager bar */}
      <div className="bg-gray-900 rounded-lg p-4 mb-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span>🐺 狼人 {wolfAlive}/{wolfCount}</span>
          <span>{state.players.length - wolfCount - aliveCount + wolfAlive}/{state.players.length - wolfCount} 🛡️ 好人</span>
        </div>
        <div className="h-3 bg-gray-700 rounded-full overflow-hidden flex">
          <div className="bg-red-500 h-full transition-all" style={{ width: `${(wolfAlive / state.players.length) * 100}%` }} />
          <div className="bg-green-500 h-full transition-all" style={{ width: `${((aliveCount - wolfAlive) / state.players.length) * 100}%` }} />
          <div className="bg-gray-600 h-full transition-all" style={{ width: `${(deadCount / state.players.length) * 100}%` }} />
        </div>
        <div className="flex text-[10px] text-gray-500 mt-1 justify-between">
          <span>🐺存活</span><span>🛡️存活</span><span>💀死亡</span>
        </div>
      </div>

      {/* MVP */}
      {mvp && (
        <div className="bg-yellow-900/20 border border-yellow-700/30 rounded-lg p-4 mb-4 text-center">
          <div className="text-lg">⭐</div>
          <div className="text-sm text-yellow-300 font-semibold">最活跃玩家</div>
          <div className="text-lg text-white">{mvp}</div>
          <div className="text-xs text-gray-400">发言 {mvpCount} 次</div>
        </div>
      )}

      {/* Death log */}
      {deathLog.length > 0 && (
        <div className="bg-gray-900 rounded-lg p-4 mb-4">
          <h3 className="text-sm font-semibold text-gray-400 mb-2">💀 死亡记录</h3>
          <div className="space-y-1">
            {deathLog.map((d, i) => (
              <div key={i} className="text-xs text-gray-300">{d}</div>
            ))}
          </div>
        </div>
      )}

      {/* Role reveal */}
      <div className="bg-gray-900 rounded-lg p-4 mb-4">
        <h3 className="text-sm font-semibold text-gray-400 mb-3">身份公布</h3>
        <div className="space-y-2">
          {state.players.map((p) => {
            const icon = p.role ? ROLE_ICONS[p.role] : '❓'
            const name = p.role ? ROLE_NAMES[p.role] : '?'
            return (
              <div
                key={p.id}
                className={`flex items-center justify-between py-1 px-2 rounded ${
                  p.is_alive ? 'bg-green-900/20' : 'bg-red-900/10'
                }`}
              >
                <span className="text-sm">
                  <span className="mr-2">{icon}</span>
                  {p.name}
                </span>
                <span className="text-xs">
                  <span className="text-gray-400">{name}</span>
                  <span className={`ml-2 ${p.is_alive ? 'text-green-400' : 'text-red-400'}`}>
                    {p.is_alive ? '存活' : '死亡'}
                  </span>
                </span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-gray-900 rounded-lg p-4 mb-6">
        <h3 className="text-sm font-semibold text-gray-400 mb-2">📋 对局时间线</h3>
        <GameTimeline events={state.timeline} />
      </div>

      <button
        onClick={onPlayAgain}
        className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition"
      >
        再来一局
      </button>
    </div>
  )
}
