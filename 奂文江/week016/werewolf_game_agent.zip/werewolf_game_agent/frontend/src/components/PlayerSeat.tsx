import { useState } from 'react'
import { PlayerPublic, ROLE_NAMES, ROLE_ICONS } from '../types/game'

interface Props {
  player: PlayerPublic
  speaking: boolean
  voteCount?: number
  isAlly?: boolean
  style?: React.CSSProperties
}

export default function PlayerSeat({ player, speaking, voteCount, isAlly, style }: Props) {
  const [hover, setHover] = useState(false)
  const roleIcon = player.role ? ROLE_ICONS[player.role] : null
  const roleLabel = player.role ? ROLE_NAMES[player.role] : null

  const borderClass = !player.is_alive
    ? 'border-red-500/60 bg-gray-800/80'
    : isAlly
    ? 'border-green-500 bg-green-900/20'
    : speaking
    ? 'border-yellow-400 bg-yellow-500/10'
    : 'border-gray-600 bg-gray-800/60 hover:border-gray-400'

  const pulseClass = speaking ? 'animate-pulse' : ''

  return (
    <div
      className={`seat-circle ${borderClass} ${pulseClass}`}
      style={style}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      {/* Ally marker */}
      {isAlly && player.is_alive && (
        <div className="absolute -top-1 -left-1 w-4 h-4 bg-green-500 rounded-full
                        flex items-center justify-center text-[8px] text-white">🐺</div>
      )}

      {/* Role icon */}
      {roleIcon && (
        <div className="text-xl">{roleIcon}</div>
      )}
      {!roleIcon && player.is_alive && (
        <div className="text-xl opacity-40">❓</div>
      )}
      {!roleIcon && !player.is_alive && (
        <div className="text-xl">💀</div>
      )}

      {/* Name + ally indicator */}
      <div className="text-[11px] font-bold mt-0.5 text-center leading-tight px-1">
        {player.name}
        {isAlly && <span className="text-green-400 text-[9px] ml-0.5">队友</span>}
      </div>

      {/* Role label (dead/revealed) */}
      {roleLabel && (
        <div className="text-[10px] text-yellow-400/70">{roleLabel}</div>
      )}

      {/* Alive/dead */}
      <div className={`text-[10px] mt-0.5 ${player.is_alive ? 'text-green-400/60' : 'text-red-400'}`}>
        {player.is_alive ? '存活' : '死亡'}
      </div>

      {/* Human marker */}
      {player.is_human && player.is_alive && (
        <div className="absolute top-1 right-2 text-xs">👤</div>
      )}

      {/* Vote count */}
      {voteCount !== undefined && voteCount > 0 && (
        <div className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 rounded-full
                        flex items-center justify-center text-[10px] font-bold text-white">
          {voteCount}
        </div>
      )}

      {/* Speaking indicator */}
      {speaking && (
        <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-yellow-500 text-black
                        text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap z-10">
          发言中
        </div>
      )}

      {/* Hover tooltip */}
      {hover && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-20
                        bg-gray-900 border border-gray-600 rounded-lg p-2 w-40 shadow-xl
                        pointer-events-none">
          <div className="text-xs font-bold text-white">{player.name}</div>
          <div className="text-[10px] text-gray-400 mt-1 space-y-0.5">
            <div>状态: {player.is_alive ? '🟢 存活' : '🔴 死亡'}</div>
            {roleLabel && <div>身份: {roleIcon} {roleLabel}</div>}
            {!roleLabel && player.is_alive && <div>身份: ❓ 未知</div>}
            {player.is_human && <div className="text-yellow-400">👤 人类玩家</div>}
            {isAlly && <div className="text-green-400">🐺 狼队友</div>}
            {speaking && <div className="text-yellow-400">🗣️ 正在发言</div>}
            {voteCount !== undefined && voteCount > 0 && (
              <div className="text-red-400">🗳️ 获得 {voteCount} 票</div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
