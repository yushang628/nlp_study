import { useState } from 'react'
import { Role } from '../types/game'

interface Props {
  onGameCreated: (gameId: string, spectate: boolean, humanRole: Role | null, wolfAllies: string[]) => void
}

export default function LobbyView({ onGameCreated }: Props) {
  const [playerCount] = useState(12)
  const [humanCount, setHumanCount] = useState(0)
  const [creating, setCreating] = useState(false)
  const [mode, setMode] = useState<'spectate' | 'play'>('spectate')
  const [error, setError] = useState<string | null>(null)

  const createGame = async () => {
    setCreating(true)
    setError(null)
    try {
      const humanIds = Array.from({ length: humanCount }, (_, i) => `player_${i + 1}`)
      const res = await fetch('/api/games', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          config: {
            num_players: playerCount,
            discussion_timeout: 60,
            vote_timeout: 45,
            night_action_timeout: 20,
            max_discussion_rounds: 1,
            ai_model: '',
          },
          human_player_ids: mode === 'play' ? humanIds : [],
        }),
      })

      if (!res.ok) {
        const text = await res.text()
        throw new Error(`创建失败 (${res.status}): ${text}`)
      }

      const data = await res.json()
      const gid = data.game_id
      const humanRoles: Record<string, string> = data.human_roles || {}
      const wolfAllies: string[] = data.wolf_allies || []

      const startRes = await fetch(`/api/games/${gid}/start`, { method: 'POST' })
      if (!startRes.ok) {
        const text = await startRes.text()
        throw new Error(`启动失败 (${startRes.status}): ${text}`)
      }

      const firstHumanId = humanIds[0]
      const humanRole = (humanRoles[firstHumanId] || null) as Role | null

      onGameCreated(gid, mode === 'spectate', humanRole, wolfAllies)
    } catch (err: any) {
      const msg = err?.message || String(err)
      setError(msg)
      console.error('Failed to create game:', err)
    }
    setCreating(false)
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-2xl p-8 max-w-md w-full shadow-2xl">
        <h1 className="text-3xl font-bold text-center mb-2">狼人杀 AI 对战</h1>
        <p className="text-gray-400 text-center mb-6">Multi-Agent Werewolf Game</p>

        <div className="mb-4">
          <label className="block text-sm text-gray-400 mb-2">模式选择</label>
          <div className="flex gap-2">
            <button
              onClick={() => setMode('spectate')}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${
                mode === 'spectate' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >观战模式</button>
            <button
              onClick={() => { setMode('play'); setHumanCount(Math.max(1, humanCount)) }}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${
                mode === 'play' ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >参与对战</button>
          </div>
        </div>

        {mode === 'play' && (
          <div className="mb-4">
            <label className="block text-sm text-gray-400 mb-2">人类玩家数量: {humanCount}</label>
            <input type="range" min={1} max={6} value={humanCount}
              onChange={(e) => setHumanCount(Number(e.target.value))} className="w-full" />
            <p className="text-xs text-gray-500">其余 {playerCount - humanCount} 名玩家为 AI 控制</p>
          </div>
        )}

        <div className="bg-gray-900 rounded-lg p-4 mb-4 text-sm">
          <p className="text-gray-400">玩家数: <span className="text-white">{playerCount}</span></p>
          <p className="text-gray-400 mt-1">角色: 4狼人 · 4村民 · 1预言家 · 1女巫 · 1猎人 · 1守卫</p>
        </div>

        {error && (
          <div className="bg-red-900/40 border border-red-700 rounded-lg p-3 mb-4 text-sm text-red-300">
            错误: {error}
          </div>
        )}

        <button
          onClick={createGame}
          disabled={creating}
          className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600
                     text-white font-bold rounded-lg transition text-lg"
        >
          {creating ? '创建中...' : mode === 'spectate' ? '开始观战' : '开始游戏'}
        </button>
      </div>
    </div>
  )
}
