import { useRef, useEffect } from 'react'
import { ChatMessage } from '../types/game'

interface Props {
  messages: ChatMessage[]
}

export default function ChatLog({ messages }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  // Debug: show raw data if empty when we expect messages
  if (messages.length === 0) {
    console.log('[ChatLog] Empty messages array — check if state.chat_log is being passed correctly')
  }

  return (
    <div className="flex-1 overflow-y-auto p-3 space-y-2 min-h-[200px] max-h-[400px]">
      <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-2">
        💬 讨论记录 ({messages.length})
      </h3>
      {messages.length === 0 && (
        <p className="text-xs text-gray-500 italic">暂无发言...（等待进入讨论阶段）</p>
      )}
      {messages.map((m, i) => (
        <div
          key={m.id || i}
          className={`rounded-lg p-2 text-sm ${
            m.is_private
              ? 'bg-purple-900/30 border border-purple-700/50'
              : 'bg-gray-700/50'
          }`}
        >
          <span className="font-semibold text-blue-400">{m.speaker_name}</span>
          {m.is_private && <span className="text-xs text-purple-400 ml-1">[私聊]</span>}
          <p className="text-gray-200 mt-0.5">{m.content}</p>
        </div>
      ))}
      <div ref={bottomRef} />
    </div>
  )
}
