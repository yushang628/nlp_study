import { Phase } from '../types/game'

interface Props {
  phase: Phase
}

const PHASE_DESCRIPTIONS: Record<string, string> = {
  night_guard: '🛡️ 守卫正在选择守护目标...',
  night_werewolf: '🐺 狼人正在商议击杀目标...',
  night_seer: '🔮 预言家正在查验身份...',
  night_witch: '🧪 女巫正在决定是否用药...',
  day_break: '☀️ 天亮了，公布夜间结果...',
  death_activation: '🔫 猎人正在选择开枪目标...',
}

export default function NightActions({ phase }: Props) {
  const desc = PHASE_DESCRIPTIONS[phase] || '夜晚行动中...'

  return (
    <div className="border-t border-gray-700 p-4">
      <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wide mb-3">🌙 夜间行动</h3>
      <div className="flex flex-col items-center py-6">
        <div className="text-4xl mb-3 animate-pulse">
          {phase === 'night_guard' ? '🛡️' :
           phase === 'night_werewolf' ? '🐺' :
           phase === 'night_seer' ? '🔮' :
           phase === 'night_witch' ? '🧪' : '🌙'}
        </div>
        <p className="text-sm text-gray-300">{desc}</p>
        <div className="mt-4 w-full bg-gray-700 rounded-full h-1.5 overflow-hidden">
          <div className="bg-blue-500 h-full rounded-full animate-pulse w-2/3" />
        </div>
      </div>
    </div>
  )
}
