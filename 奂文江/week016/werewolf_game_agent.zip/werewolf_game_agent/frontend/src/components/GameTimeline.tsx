import { useRef, useEffect } from 'react'
import { TimelineEvent, ROLE_NAMES, PHASE_NAMES } from '../types/game'

interface Props {
  events: TimelineEvent[]
}

export default function GameTimeline({ events }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollRef.current.scrollWidth
    }
  }, [events.length])

  if (events.length === 0) return null

  return (
    <div className="bg-gray-800/80 border-t border-gray-700">
      <div
        ref={scrollRef}
        className="flex gap-1 overflow-x-auto px-3 py-2 scrollbar-thin"
        style={{ scrollBehavior: 'smooth' }}
      >
        {events.map((ev, i) => (
          <div
            key={i}
            className="flex-shrink-0 flex flex-col items-center bg-gray-700/50 rounded-lg px-2 py-1.5
                       border border-gray-600/50 min-w-[72px]"
            title={`${ev.label}: ${ev.detail} (第${ev.round_number}轮)`}
          >
            <div className="text-lg leading-none">{ev.icon}</div>
            <div className="text-[9px] text-gray-300 mt-0.5 whitespace-nowrap">{ev.label}</div>
            {ev.detail && (
              <div className="text-[8px] text-gray-500 truncate max-w-[60px]">{ev.detail}</div>
            )}
            <div className="text-[8px] text-gray-600">R{ev.round_number}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
