import { GamePublicState, PHASE_NAMES } from '../types/game'

interface Props {
  state: GamePublicState | null
  connected: boolean
}

export default function PhaseBanner({ state, connected }: Props) {
  const phaseName = state ? PHASE_NAMES[state.phase] || state.phase : '加载中...'
  const isNight = state?.phase.startsWith('night_')
  const isDiscussion = state?.phase === 'day_discussion'

  return (
    <div className="bg-gray-800 border-b border-gray-700 px-4 py-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">
            {isNight ? '🌙' : state?.phase === 'day_break' ? '☀️' : '🐺'} 狼人杀 AI 对战
          </h2>
          <p className="text-sm text-gray-400">
            第 {state?.round_number ?? 0} 轮 · {phaseName}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-xs text-gray-500">{connected ? '已连接' : '未连接'}</span>
        </div>
      </div>

      {/* Current speaker indicator */}
      {isDiscussion && state?.current_speaker && (
        <div className="mt-2 bg-blue-900/30 border border-blue-700/30 rounded-lg px-3 py-1.5 flex items-center gap-2">
          <span className="text-yellow-400 text-sm">🗣️</span>
          <span className="text-blue-300 text-sm font-medium">{state.current_speaker} 正在发言</span>
          <span className="text-gray-500 text-xs ml-auto">
            {state.speaker_index}/{state.total_speakers}
          </span>
        </div>
      )}

      {/* Debug: raw chat data */}
      <div className="mt-1 text-xs text-gray-600">
        发言数: {(state as any)?.chat_log?.length ?? 0} |
        阶段: {state?.phase ?? '?'} |
        存活: {(state as any)?.players?.filter((p: any) => p.is_alive).length ?? 0}
      </div>
    </div>
  )
}
