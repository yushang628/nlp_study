import { useState, useEffect } from 'react'

interface GenerationMetrics {
  generation: number
  werewolf_win_rate: number
  villager_win_rate: number
  avg_game_rounds: number
  total_games: number
}

export default function EvolutionDashboard() {
  const [metrics, setMetrics] = useState<GenerationMetrics[]>([])
  const [loading, setLoading] = useState(false)

  const loadMetrics = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/evolution/metrics')
      const data = await res.json()
      setMetrics(data.generations || [])
    } catch {
      console.error('Failed to load evolution metrics')
    }
    setLoading(false)
  }

  useEffect(() => {
    loadMetrics()
  }, [])

  return (
    <div className="bg-gray-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">📊 自进化指标</h2>
        <button
          onClick={loadMetrics}
          disabled={loading}
          className="px-3 py-1 text-sm bg-gray-700 hover:bg-gray-600 rounded-lg transition"
        >
          {loading ? '加载中...' : '刷新'}
        </button>
      </div>

      {metrics.length === 0 ? (
        <p className="text-gray-500 text-center py-8">
          暂无数据。运行进化管道以生成指标。
        </p>
      ) : (
        <div className="space-y-4">
          {metrics.map((gen) => (
            <div key={gen.generation} className="bg-gray-900 rounded-lg p-4">
              <h3 className="font-semibold mb-2">第 {gen.generation} 代</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="text-gray-400">对局数</div>
                <div className="text-right">{gen.total_games}</div>
                <div className="text-gray-400">狼人胜率</div>
                <div className="text-right text-red-400">{(gen.werewolf_win_rate * 100).toFixed(1)}%</div>
                <div className="text-gray-400">好人胜率</div>
                <div className="text-right text-green-400">{(gen.villager_win_rate * 100).toFixed(1)}%</div>
                <div className="text-gray-400">平均轮数</div>
                <div className="text-right">{gen.avg_game_rounds.toFixed(1)}</div>
              </div>
              {/* Win rate bar */}
              <div className="mt-2 h-2 bg-gray-700 rounded-full overflow-hidden flex">
                <div
                  className="bg-red-500 h-full transition-all"
                  style={{ width: `${gen.werewolf_win_rate * 100}%` }}
                />
                <div
                  className="bg-green-500 h-full transition-all"
                  style={{ width: `${gen.villager_win_rate * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
