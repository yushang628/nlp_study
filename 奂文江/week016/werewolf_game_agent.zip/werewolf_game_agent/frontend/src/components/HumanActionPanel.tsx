import { useState } from 'react'
import { GamePublicState, PlayerPublic, Role, ROLE_NAMES, ROLE_ICONS } from '../types/game'

interface Props {
  state: GamePublicState
  humanRole: Role | null
  onSendAction: (playerId: string, actionType: string, target: string, text?: string) => void
  onSendChat: (playerId: string, content: string) => boolean
}

function findHumanPlayer(state: GamePublicState): PlayerPublic | null {
  return state.players.find(p => p.is_human && p.is_alive) || null
}

const ROLE_NIGHT_PHASE: Record<string, string> = {
  guard: 'night_guard',
  werewolf: 'night_werewolf',
  seer: 'night_seer',
  witch: 'night_witch',
}

export default function HumanActionPanel({ state, humanRole, onSendAction, onSendChat }: Props) {
  const [chatText, setChatText] = useState('')
  const [selectedTarget, setSelectedTarget] = useState('')
  const [sending, setSending] = useState(false)
  const [sentMsg, setSentMsg] = useState('')

  const phase = state.phase
  const humanPlayer = findHumanPlayer(state)
  const alivePlayers = state.players.filter(p => p.is_alive && p.id !== humanPlayer?.id)

  if (!humanPlayer) {
    return (
      <div className="border-t border-gray-700 p-3 text-center text-gray-500 text-sm">
        你已死亡，正在观战中...
      </div>
    )
  }

  const isDiscussion = phase === 'day_discussion'
  const isVote = phase === 'day_vote'
  const isMyNightTurn = humanRole ? ROLE_NIGHT_PHASE[humanRole] === phase : false
  const roleName = humanRole ? ROLE_NAMES[humanRole] : '?'
  const isNight = phase.startsWith('night_')

  const sendChat = () => {
    const text = chatText.trim()
    if (!text || sending) return
    setSending(true)
    const ok = onSendChat(humanPlayer.id, text)
    if (ok) {
      setChatText('')
      setSentMsg('已发送')
    } else {
      setSentMsg('发送失败，请刷新页面重试')
    }
    setTimeout(() => { setSentMsg(''); setSending(false) }, 2000)
  }

  const sendVote = () => {
    if (selectedTarget) {
      onSendAction(humanPlayer.id, 'vote', selectedTarget)
    }
  }

  return (
    <div className="border-t border-gray-700 p-3">
      {/* Role identity badge */}
      <div className="flex items-center gap-2 mb-3 p-2 bg-gray-700/50 rounded-lg">
        <div className="text-2xl">{humanRole ? ROLE_ICONS[humanRole] : '❓'}</div>
        <div>
          <div className="text-sm font-semibold text-white">{humanPlayer.name}</div>
          <div className="text-xs text-yellow-400">
            {roleName}
            {humanRole === 'werewolf' && ' · 狼人阵营'}
            {humanRole && humanRole !== 'werewolf' && ' · 好人阵营'}
          </div>
        </div>
      </div>

      <h3 className="text-sm font-semibold text-yellow-400 uppercase tracking-wide mb-2">
        你的操作
      </h3>

      {/* Night: waiting for others */}
      {isNight && !isMyNightTurn && (
        <div className="text-center py-4">
          <div className="text-3xl mb-2 animate-pulse">⏳</div>
          <p className="text-sm text-gray-400">AI 玩家行动中...</p>
          <p className="text-xs text-gray-500 mt-1">你的角色是{roleName}，当前不需要操作</p>
          <p className="text-xs text-gray-600 mt-1">等待 AI 完成夜间行动后进入白天讨论</p>
        </div>
      )}

      {/* Night: my turn */}
      {isMyNightTurn && (
        <div>
          <p className="text-sm text-yellow-300 mb-2">
            {phase === 'night_guard' && '选择今晚要守护的玩家:'}
            {phase === 'night_werewolf' && '选择今晚要击杀的目标:'}
            {phase === 'night_seer' && '选择今晚要查验的玩家:'}
            {phase === 'night_witch' && '选择行动（解药/毒药）:'}
          </p>
          <div className="space-y-1 mb-3">
            {alivePlayers.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedTarget(p.id)}
                className={`w-full text-left px-3 py-1.5 rounded text-sm transition ${
                  selectedTarget === p.id ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
          <button
            onClick={() => onSendAction(humanPlayer.id, 'night_action', selectedTarget)}
            disabled={!selectedTarget}
            className="w-full py-2 bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600
                       rounded-lg text-sm font-bold transition"
          >
            确认行动
          </button>
        </div>
      )}

      {/* Discussion chat input */}
      {isDiscussion && (
        <div>
          <p className="text-xs text-gray-500 mb-1">轮到你发言了</p>
          <div className="flex gap-2">
            <input
              type="text"
              value={chatText}
              onChange={(e) => setChatText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendChat()}
              placeholder="发表你的观点..."
              className="flex-1 bg-gray-700 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500
                         border border-gray-600 focus:border-blue-500 focus:outline-none"
              disabled={sending}
            />
            <button
              onClick={sendChat}
              disabled={sending || !chatText.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 rounded-lg text-sm font-bold transition"
            >
              {sending ? '发送中...' : '发言'}
            </button>
          </div>
          {sentMsg && <p className="text-xs text-green-400 mt-1">{sentMsg}，等待其他玩家发言...</p>}
        </div>
      )}

      {/* Vote input */}
      {isVote && (
        <div>
          <p className="text-sm text-gray-300 mb-2">选择放逐目标:</p>
          <div className="space-y-1 mb-3">
            <button
              onClick={() => setSelectedTarget('abstain')}
              className={`w-full text-left px-3 py-1.5 rounded text-sm transition ${
                selectedTarget === 'abstain' ? 'bg-blue-600' : 'bg-gray-700 hover:bg-gray-600'
              }`}
            >
              弃权
            </button>
            {alivePlayers.map(p => (
              <button
                key={p.id}
                onClick={() => setSelectedTarget(p.id)}
                className={`w-full text-left px-3 py-1.5 rounded text-sm transition ${
                  selectedTarget === p.id ? 'bg-red-600' : 'bg-gray-700 hover:bg-gray-600'
                }`}
              >
                {p.name}
              </button>
            ))}
          </div>
          <button
            onClick={sendVote}
            disabled={!selectedTarget}
            className="w-full py-2 bg-red-600 hover:bg-red-500 disabled:bg-gray-600
                       rounded-lg text-sm font-bold transition"
          >
            投票
          </button>
        </div>
      )}
    </div>
  )
}
