import { GamePublicState, Role } from '../types/game'
import PlayerSeat from './PlayerSeat'
import ChatLog from './ChatLog'
import VotingPanel from './VotingPanel'
import NightActions from './NightActions'
import HumanActionPanel from './HumanActionPanel'

interface Props {
  state: GamePublicState | null
  spectateMode: boolean
  humanRole: Role | null
  wolfAllies: string[]
  onSendAction: (playerId: string, actionType: string, target: string, text?: string) => void
  onSendChat: (playerId: string, content: string) => boolean
}

export default function GameBoard({ state, spectateMode, humanRole, wolfAllies, onSendAction, onSendChat }: Props) {
  if (!state) {
    return <div className="flex-1 flex items-center justify-center text-gray-500">加载中...</div>
  }

  const players = state.players
  const total = players.length
  const radius = 240
  const center = { x: 280, y: 260 }
  const seatSize = 56  // half of w-28

  const isNight = state.phase.startsWith('night_')
  const isVote = state.phase === 'day_vote'
  const isDiscussion = state.phase === 'day_discussion'

  // Build position lookup for vote lines
  const positions: Record<string, { x: number; y: number }> = {}
  players.forEach((p, i) => {
    const angle = (i / total) * 2 * Math.PI - Math.PI / 2
    positions[p.id] = {
      x: center.x + radius * Math.cos(angle),
      y: center.y + radius * Math.sin(angle),
    }
  })

  // Count votes per target
  const voteCounts: Record<string, number> = {}
  if (isVote && state.vote_results) {
    Object.values(state.vote_results.votes).forEach((target) => {
      if (target && target !== 'abstain') {
        voteCounts[target] = (voteCounts[target] || 0) + 1
      }
    })
  }

  return (
    <div className="flex-1 flex flex-col lg:flex-row">
      {/* Game board - circular player seats */}
      <div className="flex-1 relative flex items-center justify-center min-h-[520px]">
        <div className="relative" style={{ width: 560, height: 520 }}>

          {/* Vote connection lines (SVG layer) */}
          {isVote && state.vote_results && (
            <svg className="absolute inset-0 pointer-events-none" style={{ width: 560, height: 520 }}>
              {Object.entries(state.vote_results.votes).map(([voterId, targetId]) => {
                if (targetId === 'abstain' || !positions[voterId] || !positions[targetId]) return null
                const from = positions[voterId]
                const to = positions[targetId]
                // Shorten line to not overlap seat circle
                const dx = to.x - from.x
                const dy = to.y - from.y
                const dist = Math.sqrt(dx * dx + dy * dy) || 1
                const shorten = seatSize + 8
                const x1 = from.x + (dx / dist) * shorten
                const y1 = from.y + (dy / dist) * shorten
                const x2 = to.x - (dx / dist) * shorten
                const y2 = to.y - (dy / dist) * shorten
                return (
                  <line
                    key={`${voterId}-${targetId}`}
                    x1={x1} y1={y1} x2={x2} y2={y2}
                    stroke="rgb(239,68,68)"
                    strokeWidth={1.5}
                    strokeOpacity={0.5}
                    markerEnd="url(#arrowhead)"
                  />
                )
              })}
              <defs>
                <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                  <polygon points="0 0, 8 3, 0 6" fill="rgb(239,68,68)" fillOpacity={0.6} />
                </marker>
              </defs>
            </svg>
          )}

          {/* Player seats */}
          {players.map((p, i) => {
            const pos = positions[p.id]
            return (
              <PlayerSeat
                key={p.id}
                player={p}
                speaking={isDiscussion && state.current_speaker === p.name}
                voteCount={voteCounts[p.id]}
                isAlly={wolfAllies.includes(p.id)}
                style={{
                  position: 'absolute',
                  left: pos.x - seatSize,
                  top: pos.y - seatSize,
                }}
              />
            )
          })}

          {/* Center indicator */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center pointer-events-none">
            <div className={`text-4xl mb-1 ${isNight ? 'opacity-60' : ''}`}>
              {isNight ? '🌙' : '☀️'}
            </div>
            <div className="text-sm text-gray-400">第 {state.round_number} 轮</div>
          </div>
        </div>
      </div>

      {/* Side panel */}
      <div className="lg:w-96 bg-gray-800 flex flex-col max-h-screen">
        <ChatLog messages={state.chat_log} />
        {isVote && <VotingPanel results={state.vote_results} players={players} />}
        {isNight && spectateMode && <NightActions phase={state.phase} />}

        {!spectateMode && (
          <HumanActionPanel
            state={state}
            humanRole={humanRole}
            onSendAction={onSendAction}
            onSendChat={onSendChat}
          />
        )}
      </div>
    </div>
  )
}
