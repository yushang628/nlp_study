export type Role = 'werewolf' | 'villager' | 'seer' | 'witch' | 'hunter' | 'guard';
export type Team = 'werewolf' | 'villager';
export type Phase =
  | 'lobby' | 'night_guard' | 'night_werewolf' | 'night_seer' | 'night_witch'
  | 'day_break' | 'day_discussion' | 'day_vote' | 'day_trial'
  | 'day_execution' | 'death_activation' | 'win_check' | 'game_over';
export type GameStatus = 'waiting' | 'in_progress' | 'paused' | 'finished';
export type ActionType = 'protect' | 'kill' | 'check' | 'heal' | 'poison' | 'vote' | 'shoot' | 'speak' | 'reveal';

export interface PlayerPublic {
  id: string;
  name: string;
  is_alive: boolean;
  is_human: boolean;
  role: Role | null;
  seat_number: number;
  can_vote: boolean;
}

export interface ChatMessage {
  id: string;
  speaker_id: string;
  speaker_name: string;
  content: string;
  phase: Phase;
  round_number: number;
  is_private: boolean;
  timestamp: string;
}

export interface VoteResult {
  votes: Record<string, string>;
  eliminated_id: string | null;
  was_tie: boolean;
}

export interface NightDeath {
  player_id: string;
  cause: string;
  role: Role | null;
}

export interface TimelineEvent {
  round_number: number;
  phase: Phase;
  icon: string;
  label: string;
  detail: string;
}

export interface GamePublicState {
  phase: Phase;
  round_number: number;
  players: PlayerPublic[];
  chat_log: ChatMessage[];
  vote_results: VoteResult | null;
  night_deaths: NightDeath[];
  winner: Team | null;
  timer_remaining: number | null;
  current_speaker: string;
  speaker_index: number;
  total_speakers: number;
  timeline: TimelineEvent[];
}

export interface GameConfig {
  num_players: number;
  discussion_timeout: number;
  vote_timeout: number;
  night_action_timeout: number;
  ai_model: string;
}

export const ROLE_NAMES: Record<Role, string> = {
  werewolf: '狼人',
  villager: '村民',
  seer: '预言家',
  witch: '女巫',
  hunter: '猎人',
  guard: '守卫',
};

export const ROLE_ICONS: Record<Role, string> = {
  werewolf: '🐺',
  villager: '👤',
  seer: '🔮',
  witch: '🧪',
  hunter: '🔫',
  guard: '🛡️',
};

export const PHASE_NAMES: Record<Phase, string> = {
  lobby: '等待开始',
  night_guard: '守卫守护',
  night_werewolf: '狼人行动',
  night_seer: '预言家查验',
  night_witch: '女巫用药',
  day_break: '天亮了',
  day_discussion: '讨论阶段',
  day_vote: '投票阶段',
  day_trial: '最后陈述',
  day_execution: '处决阶段',
  death_activation: '猎人开枪',
  win_check: '胜负判定',
  game_over: '游戏结束',
};
