import { useState, useCallback } from 'react'
import { GamePublicState, Role } from './types/game'
import { useWebSocket } from './hooks/useWebSocket'
import { useGameState } from './hooks/useGameState'
import LobbyView from './components/LobbyView'
import GameBoard from './components/GameBoard'
import GameOverScreen from './components/GameOverScreen'
import PhaseBanner from './components/PhaseBanner'
import GameTimeline from './components/GameTimeline'

export default function App() {
  const [gameId, setGameId] = useState<string | null>(null)
  const [spectateMode, setSpectateMode] = useState(true)
  const [humanRole, setHumanRole] = useState<Role | null>(null)
  const [wolfAllies, setWolfAllies] = useState<string[]>([])

  const handleGameState = useCallback((state: GamePublicState) => {
    setGameState(state)
  }, [])

  const { gameState, setGameState } = useGameState()
  const { connected, sendAction, sendChat } = useWebSocket(gameId ?? '', handleGameState)

  const onGameCreated = (gid: string, spectate: boolean, role: Role | null, allies: string[]) => {
    setGameId(gid)
    setSpectateMode(spectate)
    setHumanRole(role)
    setWolfAllies(allies)
  }

  const onPlayAgain = () => {
    setGameId(null)
    setHumanRole(null)
    setGameState(null as unknown as GamePublicState)
  }

  if (!gameId) {
    return <LobbyView onGameCreated={onGameCreated} />
  }

  if (gameState?.winner) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4">
        <GameOverScreen state={gameState} onPlayAgain={onPlayAgain} />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <PhaseBanner state={gameState} connected={connected} />
      <GameBoard
        state={gameState}
        spectateMode={spectateMode}
        humanRole={humanRole}
        wolfAllies={wolfAllies}
        onSendAction={sendAction}
        onSendChat={sendChat}
      />
      <GameTimeline events={gameState?.timeline || []} />
    </div>
  )
}
