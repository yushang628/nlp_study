# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Multi-Agent Werewolf (狼人杀) game system. Each agent plays a specific role (Werewolf, Villager, Seer, Witch, Hunter, Guard) with independent goals, strategies, and action spaces under strict information isolation. Built with Python/FastAPI backend + React/TypeScript frontend.

## Commands

```bash
# Backend
cd backend
python -m pytest tests/ -v          # Run all unit tests (22 tests, no LLM calls)
pip install -r requirements.txt     # Install Python dependencies
python run_game.py                  # CLI: run one AI-only game (requires OPENAI_API_KEY)
uvicorn app.main:app --reload       # Start API server at localhost:8000

# Frontend
cd frontend
npm install                         # Install JS dependencies
npm run dev                         # Dev server at localhost:5173
npm run build                       # Production build
npx tsc --noEmit                    # Type check only
```

## Architecture

```
Frontend (React + Vite) ←→ WebSocket ←→ FastAPI Backend
                                            ├── API layer (REST + WS broadcast)
                                            ├── Game Engine (FSM + action resolver + vote + win check)
                                            ├── Agent Framework (LLM reasoning + info isolation)
                                            └── Evolution (collect → analyze → optimize)
```

**Key layers (backend):**
- `engine/` — Pure game logic, no I/O. Phase machine, action resolution, vote tally, win checker.
- `agents/` — AI players. Base agent uses OpenAI structured output. Info filter ensures each agent only sees role-appropriate data. Prompt manager builds role/phase-specific system prompts with Chinese strategy guidance.
- `api/` — FastAPI REST + WebSocket. Game CRUD, WS state broadcast, human action relay.
- `evolution/` — Self-evolution pipeline: data collector → metrics → LLM analyzer (Coach) → prompt optimizer with generation versioning.

**Agent info isolation:** See `info_filter.py` — each role sees a different subset of game state (e.g., werewolves know pack members, witch knows potion status, seer stores check history in `_seer_results`).

**Game flow:** 11-phase state machine in `phase_machine.py`:
`LOBBY → NIGHT_GUARD → NIGHT_WEREWOLF → NIGHT_SEER → NIGHT_WITCH → DAY_BREAK → DAY_DISCUSSION → DAY_VOTE → DAY_TRIAL → DAY_EXECUTION → DEATH_ACTIVATION → WIN_CHECK → (loop or GAME_OVER)`

**Night resolution rules** (action_resolver.py): Guard blocks wolf kill / Witch heal saves / Witch poison kills / Guard cannot repeat same target consecutively.

**12-player standard config:** 4 Werewolves, 4 Villagers, 1 Seer, 1 Witch, 1 Hunter, 1 Guard.

## Key Files

- `backend/app/engine/game_engine.py` — Async game loop orchestrator; coordinates agents + engine components
- `backend/app/agents/base_agent.py` — Abstract agent with OpenAI structured output; `decide()` pipeline
- `backend/app/agents/prompt_manager.py` — Chinese system prompts per role/phase
- `backend/app/agents/info_filter.py` — Per-role observation builder
- `backend/app/engine/action_resolver.py` — Night death resolution
- `backend/app/evolution/analyzer.py` — Coach LLM analysis of game logs
- `backend/app/evolution/optimizer.py` — Prompt refinement with generation versioning
- `frontend/src/components/GameBoard.tsx` — Main game UI with circular player layout
- `frontend/src/components/HumanActionPanel.tsx` — Human player controls (chat/vote/night action)

## Configuration

Copy `backend/.env.example` to `backend/.env` and set `OPENAI_API_KEY`. Optional: `OPENAI_MODEL` (default gpt-4o), `OPENAI_BASE_URL` for custom endpoints.
