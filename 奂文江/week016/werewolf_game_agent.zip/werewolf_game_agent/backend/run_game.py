"""CLI test harness: run a complete AI-only werewolf game."""

import asyncio
import os
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from dotenv import load_dotenv
load_dotenv()

from app.models.game import GameConfig, GameState
from app.models.enums import Phase, Role, Team
from app.engine.game_engine import GameEngine


async def print_state(state: GameState):
    """Simple CLI state reporter."""
    ps = state.public_state
    alive = [p.name for p in ps.players if p.is_alive]
    dead = [f"{p.name}({p.role.value if p.role else '?'})" for p in ps.players if not p.is_alive]

    print(f"\n{'='*60}")
    print(f"  第 {state.round_number} 轮 | 阶段: {state.phase.value}")
    print(f"  存活 ({len(alive)}): {', '.join(alive)}")
    if dead:
        print(f"  死亡: {', '.join(dead)}")
    if ps.night_deaths:
        for d in ps.night_deaths:
            print(f"  [死亡] {d.player_id}: {d.cause}")
    if ps.vote_results and ps.vote_results.eliminated_id:
        print(f"  [投票放逐] {ps.vote_results.eliminated_id}")
    if ps.winner:
        print(f"\n  *** 游戏结束! 胜者: {ps.winner.value} ***")

    # Show recent chat
    recent = ps.chat_log[-3:]
    for m in recent:
        print(f"  [{m.speaker_name}]: {m.content[:80]}...")


async def main():
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        print("WARNING: OPENAI_API_KEY not set. Agents will fail to call LLM.")
        print("Set it in .env file or environment variable.")

    config = GameConfig(
        num_players=12,
        ai_model=os.getenv("OPENAI_MODEL", "gpt-4o"),
        discussion_timeout=90,
        vote_timeout=45,
        night_action_timeout=20,
    )

    engine = GameEngine(config, on_state_change=print_state)

    print("设置 12 名玩家（全 AI）...")
    engine.setup_players(human_ids=[])

    print("\n角色分配:")
    for pid in engine.state.player_order:
        p = engine.state.players[pid]
        print(f"  {p.name} (座位{p.seat_number}): {p.role.value}")

    print(f"\n游戏 ID: {engine.state.game_id}")
    print("开始对局...\n")

    await engine.run()

    # Final report
    winner = engine.state.public_state.winner
    print(f"\n{'='*60}")
    print(f"游戏结束! 胜者: {winner.value if winner else '?'}")
    print("\n身份公布:")
    for pid in engine.state.player_order:
        p = engine.state.players[pid]
        status = "存活" if p.is_alive else "死亡"
        print(f"  {p.name}: {p.role.value} [{p.team.value}] - {status}")


if __name__ == "__main__":
    asyncio.run(main())
