"""FastAPI application entry point."""

from contextlib import asynccontextmanager

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.game_routes import router as game_router
from app.api.evolution_routes import router as evolution_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.active_games = {}
    app.state.evolution_manager = None
    yield


app = FastAPI(title="Werewolf Game Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(game_router, prefix="/api/games")
app.include_router(evolution_router)
