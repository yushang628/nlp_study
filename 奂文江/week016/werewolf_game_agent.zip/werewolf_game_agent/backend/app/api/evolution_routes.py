"""REST API for evolution control and monitoring."""

from fastapi import APIRouter, HTTPException

from app.models.game import GameConfig
from app.engine.game_engine import GameEngine
from app.evolution.data_collector import DataCollector
from app.evolution.metrics import calculate_metrics
from app.evolution.analyzer import analyze_generation
from app.evolution.optimizer import PromptOptimizer

router = APIRouter(prefix="/api/evolution")

# Global state for evolution runs
_evolution_state = {
    "running": False,
    "current_generation": 0,
    "games_played": 0,
    "generations": [],
}


@router.get("/status")
async def evolution_status():
    return _evolution_state


@router.post("/run")
async def run_evolution(games_per_gen: int = 10, generations: int = 3):
    if _evolution_state["running"]:
        raise HTTPException(status_code=400, detail="Evolution already running")

    _evolution_state["running"] = True

    try:
        for gen in range(generations):
            _evolution_state["current_generation"] = gen
            collector = DataCollector(generation=gen)

            # Load optimized prompts for this generation
            optimizer = PromptOptimizer(generation=gen)
            strategies = optimizer.get_all_strategies()

            # Run games
            for i in range(games_per_gen):
                config = GameConfig()
                engine = GameEngine(config)

                # Override prompt strategies
                for pid, agent in engine.agents.items():
                    role = engine.state.players[pid].role
                    if role.value in optimizer.strategies:
                        pass  # Agent will use updated prompts from optimizer

                await engine.run()
                collector.add_game(engine.state, config)
                _evolution_state["games_played"] += 1

            # Analyze generation
            games = collector.load_generation(gen)
            metrics = calculate_metrics(games)

            if gen < generations - 1:
                analysis = await analyze_generation(games, metrics, strategies)
                new_strategies = await optimizer.optimize(analysis, metrics)

            _evolution_state["generations"].append({
                "generation": gen,
                "games": len(games),
                "metrics": metrics,
            })

    finally:
        _evolution_state["running"] = False

    return {"status": "completed", "generations": _evolution_state["generations"]}


@router.get("/metrics")
async def evolution_metrics():
    collector = DataCollector()
    all_gens = collector.all_generations()

    result = []
    for gen in all_gens:
        games = collector.load_generation(gen)
        metrics = calculate_metrics(games)
        metrics["generation"] = gen
        result.append(metrics)

    return {"generations": result}


@router.get("/generations")
async def list_generations():
    versions = PromptOptimizer.list_versions()
    return {"generations": versions}


@router.post("/rollback/{generation}")
async def rollback(generation: int):
    try:
        strategies = PromptOptimizer.rollback(generation)
        return {"status": "rolled_back", "generation": generation, "strategies": strategies}
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"Generation {generation} not found")
