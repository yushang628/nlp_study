"""REST API routes for game management."""

import sys
import traceback
import uuid
import asyncio
from typing import Any

from fastapi import APIRouter, HTTPException, WebSocket, Request
from pydantic import BaseModel

from app.models.game import GameConfig, GameState, GamePublicState
from app.models.enums import GameStatus
from app.engine.game_engine import GameEngine
from app.api.ws_manager import manager
from app.api.ws_handler import handle_ws

router = APIRouter()


class CreateGameRequest(BaseModel):
    config: GameConfig = GameConfig()
    human_player_ids: list[str] = []


class CreateGameResponse(BaseModel):
    game_id: str
    human_roles: dict[str, str]  # player_id -> role
    wolf_allies: list[str] = []  # other werewolf player IDs (if human is wolf)


# In-memory store
_games: dict[str, GameEngine] = {}


async def _state_broadcaster(state: GameState):
    """Callback: broadcast game state to all WebSocket clients."""
    data = state.public_state.model_dump(mode='json')
    print(f"[BROADCAST] phase={state.phase.value} round={state.round_number} "
          f"players={len(data.get('players',[]))} chat_msgs={len(data.get('chat_log',[]))} "
          f"dead={len(data.get('night_deaths',[]))}")
    await manager.broadcast(
        state.game_id,
        {"type": "game_state", "data": data},
    )


@router.post("", response_model=CreateGameResponse)
async def create_game(req: CreateGameRequest):
    game_id = str(uuid.uuid4())[:8]
    engine = GameEngine(req.config, on_state_change=_state_broadcaster)
    engine.state.game_id = game_id
    engine.setup_players(human_ids=req.human_player_ids)
    _games[game_id] = engine

    human_roles = {
        pid: engine.state.players[pid].role.value
        for pid in req.human_player_ids
    }
    # If human is werewolf, include fellow wolf IDs
    wolf_allies: list[str] = []
    for pid in req.human_player_ids:
        player = engine.state.players.get(pid)
        if player and player.role.value == "werewolf":
            wolf_allies = [
                p.id for p in engine.state.players.values()
                if p.role.value == "werewolf" and p.id != pid
            ]
            break
    return CreateGameResponse(game_id=game_id, human_roles=human_roles, wolf_allies=wolf_allies)


@router.get("", response_model=list[dict])
async def list_games():
    return [
        {
            "game_id": gid,
            "status": eng.state.status.value,
            "phase": eng.state.phase.value,
            "round": eng.state.round_number,
            "player_count": len(eng.state.players),
        }
        for gid, eng in _games.items()
    ]


@router.get("/{game_id}", response_model=GamePublicState)
async def get_game(game_id: str):
    engine = _games.get(game_id)
    if engine is None:
        raise HTTPException(status_code=404, detail="Game not found")
    return engine.state.public_state


@router.post("/{game_id}/start")
async def start_game(game_id: str):
    engine = _games.get(game_id)
    if engine is None:
        raise HTTPException(status_code=404, detail="Game not found")
    if engine.state.status != GameStatus.WAITING:
        raise HTTPException(status_code=400, detail="Game already started")

    async def _run_with_log():
        try:
            await engine.run()
        except Exception:
            print(f"[Game {game_id}] Engine crashed:", file=sys.stderr)
            traceback.print_exc()

    asyncio.create_task(_run_with_log())
    return {"status": "started"}


@router.get("/{game_id}/history")
async def get_history(game_id: str):
    engine = _games.get(game_id)
    if engine is None:
        raise HTTPException(status_code=404, detail="Game not found")
    return {
        "game_id": game_id,
        "status": engine.state.status.value,
        "rounds": engine.state.round_number,
        "players": [
            {"id": p.id, "name": p.name, "role": p.role.value, "alive": p.is_alive}
            for p in engine.state.players.values()
        ],
        "winner": engine.state.public_state.winner.value if engine.state.public_state.winner else None,
        "chat_log": [
            {"speaker": m.speaker_name, "content": m.content}
            for m in engine.state.public_state.chat_log
        ],
    }


@router.websocket("/{game_id}/ws")
async def game_websocket(ws: WebSocket, game_id: str):
    engine = _games.get(game_id)
    if engine is None:
        await ws.close(code=4004, reason="Game not found")
        return
    await handle_ws(ws, game_id, engine)
