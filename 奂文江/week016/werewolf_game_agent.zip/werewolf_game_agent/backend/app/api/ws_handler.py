"""WebSocket message handler — routes all real-time game communication."""

import json

from fastapi import WebSocket, WebSocketDisconnect

from app.api.ws_manager import manager


async def handle_ws(ws: WebSocket, game_id: str, engine):
    """Main WebSocket handler for a game session."""
    await manager.connect(game_id, ws)

    # Send initial state
    ps = engine.state.public_state
    await ws.send_json({
        "type": "game_state",
        "data": ps.model_dump(mode='json'),
    })

    try:
        while True:
            raw = await ws.receive_text()
            msg = json.loads(raw)
            msg_type = msg.get("type", "")
            print(f"[WS_HANDLER] Received: type={msg_type} payload={msg}")

            if msg_type == "human_action":
                player_id = msg.get("player_id")
                action_data = msg.get("action", {})
                engine.submit_human_action(player_id, action_data)
                await ws.send_json({"type": "action_received", "player_id": player_id})

            elif msg_type == "human_chat":
                player_id = msg.get("player_id")
                content = msg.get("content", "")
                if player_id and content:
                    from app.models.messages import ChatMessage
                    import uuid
                    player = engine.state.players.get(player_id)
                    msg_obj = ChatMessage(
                        id=str(uuid.uuid4())[:8],
                        speaker_id=player_id,
                        speaker_name=player.name if player else "Unknown",
                        content=content,
                        phase=engine.state.phase,
                        round_number=engine.state.round_number,
                    )
                    engine.state.public_state.chat_log.append(msg_obj)
                    # Release the engine wait (unblock discussion phase)
                    engine.submit_human_action(player_id, {"type": "chat", "content": content})
                await ws.send_json({"type": "chat_received"})

            elif msg_type == "ping":
                await ws.send_json({"type": "pong"})

    except WebSocketDisconnect:
        manager.disconnect(game_id, ws)
