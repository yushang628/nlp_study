"""WebSocket connection pool manager."""

from fastapi import WebSocket


class ConnectionManager:
    """Manages WebSocket connections per game room."""

    def __init__(self):
        self._rooms: dict[str, list[WebSocket]] = {}

    async def connect(self, game_id: str, ws: WebSocket):
        await ws.accept()
        if game_id not in self._rooms:
            self._rooms[game_id] = []
        self._rooms[game_id].append(ws)

    def disconnect(self, game_id: str, ws: WebSocket):
        if game_id in self._rooms:
            self._rooms[game_id].remove(ws)
            if not self._rooms[game_id]:
                del self._rooms[game_id]

    async def broadcast(self, game_id: str, message: dict):
        if game_id not in self._rooms:
            return
        disconnected = []
        for ws in self._rooms[game_id]:
            try:
                await ws.send_json(message)
            except Exception:
                disconnected.append(ws)
        for ws in disconnected:
            self.disconnect(game_id, ws)

    async def send_to(self, ws: WebSocket, message: dict):
        try:
            await ws.send_json(message)
        except Exception:
            pass

    def room_count(self, game_id: str) -> int:
        return len(self._rooms.get(game_id, []))


manager = ConnectionManager()
