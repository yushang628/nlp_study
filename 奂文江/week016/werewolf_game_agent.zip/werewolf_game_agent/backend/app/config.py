from app.models.enums import Role

# OpenAI
OPENAI_API_KEY: str = "sk-7cb82743a40b4f888c434fa1d632b169"
OPENAI_MODEL: str = "deepseek-v4-pro"
OPENAI_BASE_URL: str = "https://api.deepseek.com"

# Phase timeouts (seconds)
DISCUSSION_TIMEOUT: int = 90
VOTE_TIMEOUT: int = 45
NIGHT_ACTION_TIMEOUT: int = 20

# Game defaults
DEFAULT_PLAYER_COUNT: int = 12
MAX_DISCUSSION_ROUNDS: int = 2

DEFAULT_ROLE_DISTRIBUTION: dict[Role, int] = {
    Role.WEREWOLF: 4,
    Role.VILLAGER: 4,
    Role.SEER: 1,
    Role.WITCH: 1,
    Role.HUNTER: 1,
    Role.GUARD: 1,
}
