import json
import os
from datetime import datetime
from pathlib import Path


LOG_DIR = Path("evolution_data")


class GameLogger:
    """Structured JSON logger for game events."""

    def __init__(self, game_id: str):
        self.game_id = game_id
        self.log_entries: list[dict] = []
        self.start_time = datetime.now()

    def log(self, event_type: str, **kwargs):
        entry = {
            "game_id": self.game_id,
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            **kwargs,
        }
        self.log_entries.append(entry)

    def save(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        path = LOG_DIR / f"{self.game_id}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({
                "game_id": self.game_id,
                "start_time": self.start_time.isoformat(),
                "events": self.log_entries,
            }, f, ensure_ascii=False, indent=2)
        return path
