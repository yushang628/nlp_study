import asyncio
from enum import StrEnum


class PhaseTimer:
    """Countdown timer that triggers a callback on expiry."""

    def __init__(self, timeout: float, on_timeout):
        self.timeout = timeout
        self.on_timeout = on_timeout
        self._task: asyncio.Task | None = None
        self._remaining: float = timeout
        self._started: bool = False
        self._cancelled: bool = False

    @property
    def remaining(self) -> float:
        if not self._started:
            return self.timeout
        return self._remaining

    async def start(self):
        self._started = True
        try:
            await asyncio.sleep(self.timeout)
            if not self._cancelled:
                await self.on_timeout()
        except asyncio.CancelledError:
            pass

    def cancel(self):
        self._cancelled = True
