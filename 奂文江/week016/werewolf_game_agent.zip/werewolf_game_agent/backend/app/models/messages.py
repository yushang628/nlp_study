from datetime import datetime

from pydantic import BaseModel, Field

from .enums import Phase


class ChatMessage(BaseModel):
    id: str = ""
    speaker_id: str
    speaker_name: str = ""
    content: str
    phase: Phase
    round_number: int
    is_private: bool = False
    timestamp: datetime = Field(default_factory=datetime.now)
