from datetime import datetime

from pydantic import BaseModel, Field

from .enums import ActionType, Phase, Role


class Action(BaseModel):
    actor_id: str
    action_type: ActionType
    target_id: str | None = None
    phase: Phase
    round_number: int
    reasoning: str = ""
    timestamp: datetime = Field(default_factory=datetime.now)


class NightDeath(BaseModel):
    player_id: str
    cause: str  # "werewolf", "witch_poison", "hunter_shot"
    role: Role | None = None


class SeerCheck(BaseModel):
    round_number: int
    target_id: str
    role: Role
