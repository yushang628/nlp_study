from pydantic import BaseModel, Field

from .enums import Role, Team


class Player(BaseModel):
    """Internal player state held by the engine — never sent to clients."""
    id: str
    name: str
    role: Role
    team: Team
    is_alive: bool = True
    is_human: bool = False
    seat_number: int

    # Witch state
    has_heal_potion: bool = True
    has_poison_potion: bool = True

    # Guard state
    last_protected_id: str | None = None

    # Hunter state
    can_shoot: bool = True

    # Idiot-like: can vote after being revealed by vote-out
    can_vote: bool = True


class PlayerPublic(BaseModel):
    """Sanitized player info visible to other players / spectators."""
    id: str
    name: str
    is_alive: bool
    is_human: bool
    role: Role | None = None
    seat_number: int
    can_vote: bool = True
