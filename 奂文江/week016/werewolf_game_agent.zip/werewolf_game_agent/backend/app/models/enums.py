from enum import StrEnum


class Role(StrEnum):
    WEREWOLF = "werewolf"
    VILLAGER = "villager"
    SEER = "seer"
    WITCH = "witch"
    HUNTER = "hunter"
    GUARD = "guard"


class Team(StrEnum):
    WEREWOLF = "werewolf"
    VILLAGER = "villager"

    @classmethod
    def for_role(cls, role: Role) -> "Team":
        return cls.WEREWOLF if role == Role.WEREWOLF else cls.VILLAGER


class Phase(StrEnum):
    LOBBY = "lobby"
    NIGHT_GUARD = "night_guard"
    NIGHT_WEREWOLF = "night_werewolf"
    NIGHT_SEER = "night_seer"
    NIGHT_WITCH = "night_witch"
    DAY_BREAK = "day_break"
    DAY_DISCUSSION = "day_discussion"
    DAY_VOTE = "day_vote"
    DAY_TRIAL = "day_trial"
    DAY_EXECUTION = "day_execution"
    DEATH_ACTIVATION = "death_activation"
    WIN_CHECK = "win_check"
    GAME_OVER = "game_over"


class ActionType(StrEnum):
    PROTECT = "protect"
    KILL = "kill"
    CHECK = "check"
    HEAL = "heal"
    POISON = "poison"
    VOTE = "vote"
    SHOOT = "shoot"
    SPEAK = "speak"
    REVEAL = "reveal"


class GameStatus(StrEnum):
    WAITING = "waiting"
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    FINISHED = "finished"


ROLE_TO_TEAM: dict[Role, Team] = {
    Role.WEREWOLF: Team.WEREWOLF,
    Role.VILLAGER: Team.VILLAGER,
    Role.SEER: Team.VILLAGER,
    Role.WITCH: Team.VILLAGER,
    Role.HUNTER: Team.VILLAGER,
    Role.GUARD: Team.VILLAGER,
}

ROLE_NAMES = {
    Role.WEREWOLF: "狼人",
    Role.VILLAGER: "村民",
    Role.SEER: "预言家",
    Role.WITCH: "女巫",
    Role.HUNTER: "猎人",
    Role.GUARD: "守卫",
}
