from pydantic import BaseModel, Field

from .enums import GameStatus, Phase, Role, Team
from .player import Player, PlayerPublic
from .actions import Action, NightDeath
from .messages import ChatMessage


DEFAULT_ROLES: dict[Role, int] = {
    Role.WEREWOLF: 4,
    Role.VILLAGER: 4,
    Role.SEER: 1,
    Role.WITCH: 1,
    Role.HUNTER: 1,
    Role.GUARD: 1,
}


class GameConfig(BaseModel):
    num_players: int = 12
    role_distribution: dict[Role, int] = Field(default_factory=lambda: dict(DEFAULT_ROLES))
    discussion_timeout: int = 90
    vote_timeout: int = 45
    night_action_timeout: int = 20
    ai_model: str = "gpt-4o"
    max_discussion_rounds: int = 2
    enable_private_wolf_chat: bool = True


class VoteResult(BaseModel):
    votes: dict[str, str] = Field(default_factory=dict)  # voter_id -> target_id
    eliminated_id: str | None = None
    was_tie: bool = False


class TimelineEvent(BaseModel):
    round_number: int
    phase: Phase
    icon: str = ""
    label: str = ""
    detail: str = ""


class GamePublicState(BaseModel):
    """Broadcast to all WebSocket clients."""
    phase: Phase = Phase.LOBBY
    round_number: int = 0
    players: list[PlayerPublic] = Field(default_factory=list)
    chat_log: list[ChatMessage] = Field(default_factory=list)
    vote_results: VoteResult | None = None
    night_deaths: list[NightDeath] = Field(default_factory=list)
    winner: Team | None = None
    timer_remaining: float | None = None
    current_speaker: str = ""  # name of player currently speaking
    speaker_index: int = 0
    total_speakers: int = 0
    timeline: list[TimelineEvent] = Field(default_factory=list)


class GameState(BaseModel):
    game_id: str = ""
    status: GameStatus = GameStatus.WAITING
    phase: Phase = Phase.LOBBY
    round_number: int = 0
    players: dict[str, Player] = Field(default_factory=dict)
    player_order: list[str] = Field(default_factory=list)
    public_state: GamePublicState = Field(default_factory=GamePublicState)
    night_actions: list[Action] = Field(default_factory=list)
    current_speaker_index: int = 0
    discussion_round: int = 0
    last_guard_target: str | None = None
    seer_checks: dict[str, list[dict]] = Field(default_factory=dict)
    night_victim: str | None = None  # Temporary: who wolves attacked this night (for witch)

    def to_public(self) -> GamePublicState:
        return self.public_state

    def get_player(self, player_id: str) -> Player:
        return self.players[player_id]

    def get_alive_players(self) -> list[Player]:
        return [p for p in self.players.values() if p.is_alive]

    def get_alive_player_ids(self) -> list[str]:
        return [p.id for p in self.players.values() if p.is_alive]

    def get_alive_werewolves(self) -> list[Player]:
        return [p for p in self.players.values() if p.is_alive and p.role == Role.WEREWOLF]

    def get_alive_villagers(self) -> list[Player]:
        return [p for p in self.players.values() if p.is_alive and p.team == Team.VILLAGER]
