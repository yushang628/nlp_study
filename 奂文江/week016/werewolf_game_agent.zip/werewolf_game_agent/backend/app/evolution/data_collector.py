"""Game log storage and retrieval for evolution analysis."""

import json
from pathlib import Path
from datetime import datetime

from app.models.game import GameState, GameConfig
from app.models.enums import Role, Team


EVOLUTION_DIR = Path("evolution_data")


class GameLogEntry:
    """Complete game record for analysis."""

    def __init__(self, state: GameState, config: GameConfig):
        self.game_id = state.game_id
        self.config = config
        self.winner = state.public_state.winner
        self.total_rounds = state.round_number
        self.players = [
            {
                "id": p.id,
                "name": p.name,
                "role": p.role.value,
                "team": p.team.value,
                "survived": p.is_alive,
            }
            for p in state.players.values()
        ]
        self.chat_log = [
            {
                "speaker": m.speaker_name,
                "speaker_id": m.speaker_id,
                "content": m.content,
                "round": m.round_number,
            }
            for m in state.public_state.chat_log
        ]
        self.night_actions = [
            {
                "actor": a.actor_id,
                "type": a.action_type.value,
                "target": a.target_id,
                "round": a.round_number,
                "reasoning": a.reasoning,
            }
            for a in state.night_actions
        ]
        self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            "game_id": self.game_id,
            "timestamp": self.timestamp,
            "winner": self.winner.value if self.winner else None,
            "total_rounds": self.total_rounds,
            "players": self.players,
            "chat_log": self.chat_log,
            "night_actions": self.night_actions,
        }


class DataCollector:
    """Collects and stores game logs for evolution analysis."""

    def __init__(self, generation: int = 0):
        self.generation = generation
        self.games: list[GameLogEntry] = []
        EVOLUTION_DIR.mkdir(parents=True, exist_ok=True)

    def add_game(self, state: GameState, config: GameConfig):
        entry = GameLogEntry(state, config)
        self.games.append(entry)
        self._save_game(entry)

    def _save_game(self, entry: GameLogEntry):
        gen_dir = EVOLUTION_DIR / f"gen_{self.generation}"
        gen_dir.mkdir(parents=True, exist_ok=True)
        path = gen_dir / f"{entry.game_id}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(entry.to_dict(), f, ensure_ascii=False, indent=2)

    def load_generation(self, generation: int) -> list[dict]:
        gen_dir = EVOLUTION_DIR / f"gen_{generation}"
        if not gen_dir.exists():
            return []
        games = []
        for f in gen_dir.glob("*.json"):
            with open(f, "r", encoding="utf-8") as fp:
                games.append(json.load(fp))
        return games

    def all_generations(self) -> list[int]:
        gens = []
        for d in EVOLUTION_DIR.iterdir():
            if d.is_dir() and d.name.startswith("gen_"):
                try:
                    gens.append(int(d.name.split("_")[1]))
                except ValueError:
                    pass
        return sorted(gens)
