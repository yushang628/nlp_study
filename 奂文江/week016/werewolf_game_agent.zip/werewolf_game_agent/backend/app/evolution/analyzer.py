"""LLM-powered game analysis — identifies strategy gaps and improvement areas."""

import os
from openai import AsyncOpenAI

from app.models.enums import Role, ROLE_NAMES


async def analyze_generation(
    games: list[dict],
    metrics: dict,
    current_prompts: dict[Role, str],
) -> dict:
    """Use a Coach LLM to analyze game logs and suggest improvements."""

    client = AsyncOpenAI(
        api_key=os.getenv("OPENAI_API_KEY", ""),
        base_url=os.getenv("OPENAI_BASE_URL") or None,
    )

    # Build a compact summary for the coach
    summary_lines = [
        f"共 {metrics['total_games']} 局游戏",
        f"狼人胜率: {metrics['werewolf_win_rate']:.1%}",
        f"好人胜率: {metrics['villager_win_rate']:.1%}",
        f"平均轮数: {metrics['avg_game_rounds']}",
    ]

    if metrics.get("role_metrics"):
        for role, rm in metrics["role_metrics"].items():
            summary_lines.append(
                f"  {ROLE_NAMES.get(Role(role), role)}: 存活率 {rm['survival_rate']:.1%}"
            )

    # Sample some game chat for pattern analysis
    chat_samples: list[str] = []
    for g in games[:3]:
        for msg in g.get("chat_log", [])[:5]:
            chat_samples.append(f"  [{msg.get('speaker', '?')}]: {msg.get('content', '')}")

    prompt = f"""你是一位狼人杀策略教练。请分析以下对局数据并给出改进建议。

=== 对局统计 ===
{chr(10).join(summary_lines)}

=== 发言样本 ===
{chr(10).join(chat_samples[:15])}

请分析：
1. 哪种角色的表现最需要改进？为什么？
2. 狼人阵营和好人阵营各自的主要策略缺陷是什么？
3. 针对每个角色，提供一条具体的策略改进建议。

请以 JSON 格式回复：
{{
  "weakest_role": "角色名",
  "wolf_team_issues": "狼人阵营的主要问题",
  "villager_team_issues": "好人阵营的主要问题",
  "role_suggestions": {{
    "werewolf": "狼人改进建议",
    "villager": "村民改进建议",
    "seer": "预言家改进建议",
    "witch": "女巫改进建议",
    "hunter": "猎人改进建议",
    "guard": "守卫改进建议"
  }},
  "summary": "总体分析总结"
}}
"""

    try:
        response = await client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            messages=[
                {"role": "system", "content": "你是狼人杀策略分析专家。请基于对局数据提供专业的策略分析。"},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3,
            max_tokens=1000,
            response_format={"type": "json_object"},
        )
        content = response.choices[0].message.content or "{}"
        import json
        return json.loads(content)
    except Exception as e:
        return {"error": str(e), "summary": "Analysis failed"}
