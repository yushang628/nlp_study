"""Multi-dimensional performance metrics for evolution tracking."""

from collections import Counter

from app.models.enums import Role, Team


def calculate_metrics(games: list[dict]) -> dict:
    """Calculate aggregate metrics from a list of game logs."""
    if not games:
        return {"total_games": 0}

    total = len(games)
    wolf_wins = sum(1 for g in games if g.get("winner") == Team.WEREWOLF.value)
    villager_wins = sum(1 for g in games if g.get("winner") == Team.VILLAGER.value)

    # Per-role survival rates
    role_survival: dict[str, list[int]] = {}
    for g in games:
        for p in g.get("players", []):
            role = p["role"]
            if role not in role_survival:
                role_survival[role] = []
            role_survival[role].append(1 if p["survived"] else 0)

    role_metrics = {}
    for role, survivals in role_survival.items():
        role_metrics[role] = {
            "survival_rate": sum(survivals) / len(survivals) if survivals else 0,
            "games_played": len(survivals),
        }

    # Average rounds
    avg_rounds = sum(g.get("total_rounds", 0) for g in games) / total if total else 0

    # Night action accuracy
    seer_checks = []
    witch_poisons = []
    for g in games:
        player_roles = {p["id"]: p["role"] for p in g.get("players", [])}
        for a in g.get("night_actions", []):
            if a["type"] == "check" and a.get("target"):
                target_role = player_roles.get(a["target"])
                is_wolf = target_role == Role.WEREWOLF.value
                seer_checks.append(is_wolf)
            elif a["type"] == "poison" and a.get("target"):
                target_role = player_roles.get(a["target"])
                is_wolf = target_role == Role.WEREWOLF.value
                witch_poisons.append(is_wolf)

    return {
        "total_games": total,
        "wolf_win_count": wolf_wins,
        "villager_win_count": villager_wins,
        "werewolf_win_rate": wolf_wins / total if total else 0,
        "villager_win_rate": villager_wins / total if total else 0,
        "avg_game_rounds": round(avg_rounds, 1),
        "role_metrics": role_metrics,
        "seer_wolf_check_rate": sum(seer_checks) / len(seer_checks) if seer_checks else 0,
        "witch_wolf_poison_rate": sum(witch_poisons) / len(witch_poisons) if witch_poisons else 0,
    }
