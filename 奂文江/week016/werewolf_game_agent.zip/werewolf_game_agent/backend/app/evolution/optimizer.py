"""Prompt optimizer — uses Coach LLM to refine strategy prompts per generation."""

import json
import os
from pathlib import Path
from openai import AsyncOpenAI

from app.models.enums import Role, ROLE_NAMES
from app.agents.prompt_manager import ROLE_STRATEGIES


PROMPT_VERSIONS_DIR = Path("evolution_data/prompt_versions")


class PromptOptimizer:
    """Manages prompt versions and generates improved prompts via LLM."""

    def __init__(self, generation: int = 0):
        self.generation = generation
        self._client = AsyncOpenAI(
            api_key=os.getenv("OPENAI_API_KEY", ""),
            base_url=os.getenv("OPENAI_BASE_URL") or None,
        )
        PROMPT_VERSIONS_DIR.mkdir(parents=True, exist_ok=True)
        self._load_or_init()

    def _load_or_init(self):
        """Load existing prompts or init from defaults."""
        path = PROMPT_VERSIONS_DIR / f"gen_{self.generation}.json"
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                self.strategies = json.load(f)
        else:
            self.strategies = {role.value: strategy for role, strategy in ROLE_STRATEGIES.items()}
            self._save()

    def _save(self):
        path = PROMPT_VERSIONS_DIR / f"gen_{self.generation}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.strategies, f, ensure_ascii=False, indent=2)

    def get_strategy(self, role: Role) -> str:
        return self.strategies.get(role.value, ROLE_STRATEGIES.get(role, ""))

    def get_all_strategies(self) -> dict[Role, str]:
        return {role: self.get_strategy(role) for role in Role}

    async def optimize(self, analysis_report: dict, metrics: dict) -> dict[Role, str]:
        """Generate improved strategies based on analysis."""
        suggestions = analysis_report.get("role_suggestions", {})

        for role in Role:
            current = self.strategies.get(role.value, ROLE_STRATEGIES.get(role, ""))
            suggestion = suggestions.get(role.value, "")

            if not suggestion:
                continue

            improved = await self._refine_one(role, current, suggestion, metrics)
            if improved:
                self.strategies[role.value] = improved

        self.generation += 1
        self._save()

        # Save as next generation
        next_path = PROMPT_VERSIONS_DIR / f"gen_{self.generation}.json"
        with open(next_path, "w", encoding="utf-8") as f:
            json.dump(self.strategies, f, ensure_ascii=False, indent=2)

        return {role: self.get_strategy(role) for role in Role}

    async def _refine_one(
        self, role: Role, current: str, suggestion: str, metrics: dict
    ) -> str | None:
        """Refine a single role's strategy via LLM."""
        role_name = ROLE_NAMES.get(role, role.value)
        role_metrics = metrics.get("role_metrics", {}).get(role.value, {})

        prompt = f"""你是狼人杀策略专家。请优化{role_name}的策略指引。

=== 当前策略 ===
{current}

=== 分析建议 ===
{suggestion}

=== 该角色数据 ===
存活率: {role_metrics.get('survival_rate', 0):.1%}

请输出优化后的策略指引（纯策略文本，不要包含头尾标记）。策略应具体、可操作，约200-400字。"""

        try:
            response = await self._client.chat.completions.create(
                model=os.getenv("OPENAI_MODEL", "gpt-4o"),
                messages=[
                    {"role": "system", "content": "你是狼人杀策略教练。请输出简洁、实用的角色策略指引。"},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.5,
                max_tokens=800,
            )
            return response.choices[0].message.content
        except Exception:
            return None

    @staticmethod
    def list_versions() -> list[int]:
        versions = []
        if PROMPT_VERSIONS_DIR.exists():
            for f in PROMPT_VERSIONS_DIR.glob("gen_*.json"):
                try:
                    versions.append(int(f.stem.split("_")[1]))
                except (ValueError, IndexError):
                    pass
        return sorted(versions)

    @staticmethod
    def rollback(generation: int):
        path = PROMPT_VERSIONS_DIR / f"gen_{generation}.json"
        if not path.exists():
            raise FileNotFoundError(f"Generation {generation} not found")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
