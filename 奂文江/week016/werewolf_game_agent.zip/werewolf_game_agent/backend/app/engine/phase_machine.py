from app.models.enums import Phase


NIGHT_PHASES = [
    Phase.NIGHT_GUARD,
    Phase.NIGHT_WEREWOLF,
    Phase.NIGHT_SEER,
    Phase.NIGHT_WITCH,
]

DAY_PHASES = [
    Phase.DAY_BREAK,
    Phase.DAY_DISCUSSION,
    Phase.DAY_VOTE,
    Phase.DAY_TRIAL,
    Phase.DAY_EXECUTION,
    Phase.DEATH_ACTIVATION,
]

PHASE_ORDER: list[Phase] = [
    Phase.LOBBY,
    Phase.NIGHT_GUARD,
    Phase.NIGHT_WEREWOLF,
    Phase.NIGHT_SEER,
    Phase.NIGHT_WITCH,
    Phase.DAY_BREAK,
    Phase.DAY_DISCUSSION,
    Phase.DAY_VOTE,
    Phase.DAY_TRIAL,
    Phase.DAY_EXECUTION,
    Phase.DEATH_ACTIVATION,
    Phase.WIN_CHECK,
    Phase.GAME_OVER,
]


class PhaseMachine:

    def __init__(self, phase: Phase = Phase.LOBBY):
        self.current = phase

    def next_after(self, current: Phase) -> Phase:
        idx = PHASE_ORDER.index(current)
        return PHASE_ORDER[idx + 1]

    def transition(self, to: Phase) -> Phase:
        self.current = to
        return self.current

    def next(self) -> Phase:
        self.current = self.next_after(self.current)
        return self.current

    def is_night(self) -> bool:
        return self.current in NIGHT_PHASES

    def is_day(self) -> bool:
        return self.current in DAY_PHASES

    @property
    def is_game_over(self) -> bool:
        return self.current == Phase.GAME_OVER

    def reset_night_cycle(self):
        """After daytime ends, go back to first night phase."""
        self.current = Phase.NIGHT_GUARD

    @staticmethod
    def night_phases() -> list[Phase]:
        return list(NIGHT_PHASES)

    @staticmethod
    def day_phases() -> list[Phase]:
        return list(DAY_PHASES)
