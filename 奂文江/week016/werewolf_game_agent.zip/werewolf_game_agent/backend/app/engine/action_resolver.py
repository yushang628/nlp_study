from dataclasses import dataclass, field

from app.models.enums import Role
from app.models.actions import NightDeath, Action


@dataclass
class NightResolution:
    wolf_target: str | None = None
    guard_target: str | None = None
    seer_target: str | None = None
    seer_result: Role | None = None
    witch_heal_target: str | None = None
    witch_poison_target: str | None = None
    deaths: list[NightDeath] = field(default_factory=list)
    protected: bool = False
    healed: bool = False


def resolve_night(
    wolf_target: str | None,
    guard_target: str | None,
    seer_target: str | None,
    seer_result: Role | None,
    witch_heal: str | None,
    witch_poison: str | None,
    guard_blocked: bool,  # True if guard repeated same target
) -> NightResolution:
    result = NightResolution(
        wolf_target=wolf_target,
        guard_target=guard_target,
        seer_target=seer_target,
        seer_result=seer_result,
    )

    valid_guard = guard_target is not None and not guard_blocked
    protected = valid_guard and wolf_target is not None and guard_target == wolf_target
    result.protected = protected

    healed = witch_heal is not None and witch_heal == wolf_target and wolf_target is not None
    result.healed = healed

    wolf_kills = not (protected or healed)
    if wolf_target and wolf_kills:
        result.deaths.append(NightDeath(
            player_id=wolf_target,
            cause="werewolf",
        ))

    if witch_poison:
        result.deaths.append(NightDeath(
            player_id=witch_poison,
            cause="witch_poison",
        ))

    return result
