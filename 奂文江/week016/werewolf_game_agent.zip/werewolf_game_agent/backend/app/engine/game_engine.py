"""Async game engine orchestrator — ties engine components, agents, and callbacks together."""

import asyncio
import random
import uuid
from collections import Counter
from typing import Callable, Awaitable

from app.models.enums import Role, Team, Phase, ActionType, GameStatus
from app.models.player import Player, PlayerPublic
from app.models.game import GameState, GamePublicState, GameConfig, VoteResult
from app.models.actions import Action, NightDeath
from app.models.messages import ChatMessage

from app.engine.phase_machine import PhaseMachine
from app.engine.action_resolver import resolve_night
from app.engine.vote_manager import tally_votes
from app.engine.win_checker import check_win

from app.agents.role_agents import BaseAgent, create_agent

StateCallback = Callable[[GameState], Awaitable[None]]

HUMAN_TIMEOUT = 60  # seconds for human input


class GameEngine:
    """Orchestrates a single werewolf game session."""

    def __init__(self, config: GameConfig, on_state_change: StateCallback | None = None):
        self.config = config
        self.state = GameState(game_id=str(uuid.uuid4())[:8])
        self.phase_machine = PhaseMachine()
        self.agents: dict[str, BaseAgent] = {}
        self._on_state_change = on_state_change
        self._pending_events: dict[str, asyncio.Event] = {}
        self._human_actions: dict[str, dict] = {}
        self._logger = None

    # ── setup ──────────────────────────────────────────────

    def setup_players(self, human_ids: list[str] | None = None):
        human_ids = human_ids or []
        roles = self._build_role_list()
        random.shuffle(roles)

        for i, role in enumerate(roles):
            pid = f"player_{i + 1}"
            name = f"玩家{i + 1}"
            is_human = pid in human_ids

            player = Player(
                id=pid, name=name, role=role,
                team=Team.for_role(role), is_human=is_human, seat_number=i + 1,
            )
            self.state.players[pid] = player
            self.state.player_order.append(pid)

            if not is_human:
                agent = create_agent(pid, name, role, model=self.config.ai_model)
                self.agents[pid] = agent

        self._init_public_state()

    def _build_role_list(self) -> list[Role]:
        roles = []
        for role, count in self.config.role_distribution.items():
            roles.extend([role] * count)
        return roles

    def _init_public_state(self):
        self.state.public_state = GamePublicState(
            phase=Phase.LOBBY, round_number=0,
            players=[
                PlayerPublic(
                    id=p.id, name=p.name, is_alive=p.is_alive,
                    is_human=p.is_human, seat_number=p.seat_number,
                    can_vote=p.can_vote,
                ) for p in self.state.players.values()
            ],
        )

    async def _notify_state(self):
        self.state.public_state.phase = self.state.phase
        self.state.public_state.round_number = self.state.round_number
        self.state.public_state.players = [
            PlayerPublic(
                id=p.id, name=p.name, is_alive=p.is_alive,
                is_human=p.is_human,
                role=(p.role if not p.is_alive else None),
                seat_number=p.seat_number, can_vote=p.can_vote,
            ) for p in self.state.players.values()
        ]
        if self._on_state_change:
            await self._on_state_change(self.state)

    # ── human input ────────────────────────────────────────

    def submit_human_action(self, player_id: str, action: dict):
        """Called from WebSocket handler when human submits an action."""
        print(f"[ENGINE] submit_human_action: player={player_id} action={action}")
        print(f"[ENGINE] pending_events keys: {list(self._pending_events.keys())}")
        self._human_actions[player_id] = action
        event = self._pending_events.get(player_id)
        print(f"[ENGINE] event found: {event is not None}")
        if event:
            event.set()
            print(f"[ENGINE] event SET for {player_id}")

    async def _wait_for_human(self, player_id: str, timeout: float = HUMAN_TIMEOUT) -> dict | None:
        """Wait for a human player to submit their action. Returns action dict or None on timeout."""
        print(f"[ENGINE] _wait_for_human START: player={player_id} phase={self.state.phase.value} timeout={timeout}")
        event = asyncio.Event()
        self._pending_events[player_id] = event
        self._human_actions.pop(player_id, None)  # clear stale

        try:
            await asyncio.wait_for(event.wait(), timeout=timeout)
            result = self._human_actions.pop(player_id, None)
            print(f"[ENGINE] _wait_for_human GOT: player={player_id} result={result}")
            return result
        except asyncio.TimeoutError:
            print(f"[ENGINE] _wait_for_human TIMEOUT: player={player_id}")
            return None
        finally:
            self._pending_events.pop(player_id, None)

    # ── main loop ──────────────────────────────────────────

    async def run(self):
        self.state.status = GameStatus.IN_PROGRESS
        self.state.round_number = 1
        self.phase_machine.transition(Phase.NIGHT_GUARD)
        self.state.phase = Phase.NIGHT_GUARD
        await self._notify_state()

        while not self.phase_machine.is_game_over:
            await self._run_night_phases()
            if self.phase_machine.is_game_over:
                break
            await self._run_day_phases()
            if self.phase_machine.is_game_over:
                break
            self.state.round_number += 1
            self.phase_machine.reset_night_cycle()
            self.state.phase = Phase.NIGHT_GUARD

        self.state.status = GameStatus.FINISHED
        self.state.phase = Phase.GAME_OVER
        winner = check_win(self.state)
        self.state.public_state.winner = winner
        self._reveal_dead_roles()
        await self._notify_state()

    def _reveal_dead_roles(self):
        for p in self.state.public_state.players:
            player = self.state.players[p.id]
            if not player.is_alive:
                p.role = player.role

    # ── helpers ────────────────────────────────────────────

    def _resolve_target(self, raw: str) -> str | None:
        """Normalize LLM/human output to an actual alive player ID.
        Handles: '玩家3' (name), 'player3' (no underscore), 'player_3' (correct), 'p3' etc."""
        if not raw:
            return None
        # Direct match
        if raw in self.state.players:
            return raw
        # Try adding underscore: 'player1' -> 'player_1'
        import re
        m = re.match(r'^player(\d+)$', raw)
        if m:
            pid = f"player_{m.group(1)}"
            if pid in self.state.players:
                return pid
        # Try matching by name
        for pid, p in self.state.players.items():
            if p.name == raw:
                return pid
        # Try partial match: '玩家 3' or '3'
        for pid, p in self.state.players.items():
            if raw in p.name or p.name in raw:
                return pid
        return None

    def _observe_all(self, event: str):
        """Push a game event to all alive AI agents' memory."""
        for pid, agent in self.agents.items():
            player = self.state.players.get(pid)
            if player and player.is_alive:
                agent.observe(f"[第{self.state.round_number}轮] {event}")

    def _observe_role(self, role: Role, event: str):
        """Push an event only to alive agents of a specific role."""
        for pid, agent in self.agents.items():
            player = self.state.players.get(pid)
            if player and player.is_alive and player.role == role:
                agent.observe(f"[第{self.state.round_number}轮] {event}")

    def _find_role_player(self, role: Role) -> str | None:
        for p in self.state.players.values():
            if p.is_alive and p.role == role:
                return p.id
        return None

    async def _act_or_wait(self, player_id: str, phase: Phase, action_key: str) -> dict | None:
        """Get AI decision or wait for human. Returns parsed result dict."""
        agent = self.agents.get(player_id)
        if agent:
            return await agent.decide(phase, action_key, self.state)

        player = self.state.players.get(player_id)
        if player and player.is_human:
            return await self._wait_for_human(player_id)

        return None

    # ── night phases ───────────────────────────────────────

    async def _run_night_phases(self):
        guard_action = await self._do_guard()
        wolf_action = await self._do_werewolf()
        seer_action = await self._do_seer()
        witch_result = await self._do_witch()
        self._resolve_night_and_apply(guard_action, wolf_action, seer_action, witch_result)

    async def _do_guard(self) -> Action | None:
        pid = self._find_role_player(Role.GUARD)
        if not pid:
            return None

        self.state.phase = Phase.NIGHT_GUARD
        await self._notify_state()

        result = await self._act_or_wait(pid, Phase.NIGHT_GUARD, "protect")
        if not result:
            return None

        target_id = self._resolve_target(result.get("target", ""))
        action = Action(
            actor_id=pid,
            action_type=ActionType.PROTECT,
            target_id=target_id,
            phase=Phase.NIGHT_GUARD,
            round_number=self.state.round_number,
            reasoning=result.get("reasoning", ""),
        )
        self.state.night_actions.append(action)
        self._log("guard_protect", actor=pid, target=action.target_id)
        if action.target_id:
            target = self.state.players.get(action.target_id)
            self._push_timeline("🛡️", "守卫守护", target.name if target else "?")
        return action

    async def _do_werewolf(self) -> Action | None:
        wolves = self.state.get_alive_werewolves()
        if not wolves:
            return None

        self.state.phase = Phase.NIGHT_WEREWOLF
        await self._notify_state()

        # All wolves decide in parallel (AI via LLM, human via wait)
        tasks = [self._act_or_wait(w.id, Phase.NIGHT_WEREWOLF, "kill") for w in wolves]
        results = await asyncio.gather(*tasks)

        choices = [self._resolve_target(r.get("target", "")) for r in results if r and r.get("target")]
        choices = [c for c in choices if c]  # filter None
        if not choices:
            return None

        counter = Counter(choices)
        target = counter.most_common(1)[0][0]

        action = Action(
            actor_id="werewolf_team",
            action_type=ActionType.KILL,
            target_id=target,
            phase=Phase.NIGHT_WEREWOLF,
            round_number=self.state.round_number,
            reasoning=f"Werewolf consensus: {dict(counter)}",
        )
        self.state.night_actions.append(action)
        self._log("werewolf_kill", target=target, votes=dict(counter))
        target_player = self.state.players.get(target)
        self._push_timeline("🐺", "狼人选刀", target_player.name if target_player else target)
        return action

    async def _do_seer(self) -> Action | None:
        pid = self._find_role_player(Role.SEER)
        if not pid:
            return None

        self.state.phase = Phase.NIGHT_SEER
        await self._notify_state()

        result = await self._act_or_wait(pid, Phase.NIGHT_SEER, "check")
        if not result:
            return None

        target_id = self._resolve_target(result.get("target", ""))
        action = Action(
            actor_id=pid,
            action_type=ActionType.CHECK,
            target_id=target_id,
            phase=Phase.NIGHT_SEER,
            round_number=self.state.round_number,
            reasoning=result.get("reasoning", ""),
        )
        self.state.night_actions.append(action)
        if target_id and target_id in self.state.players:
            checked_role = self.state.players[target_id].role
            if pid not in self.state.seer_checks:
                self.state.seer_checks[pid] = []
            self.state.seer_checks[pid].append({
                "round": self.state.round_number,
                "target": target_id,
                "role": checked_role.value,
            })
        self._log("seer_check", actor=pid, target=action.target_id)
        if action.target_id:
            checked = self.state.players.get(action.target_id)
            self._push_timeline("🔮", "预言家查验", checked.name if checked else "?")
        # Tell the seer agent what they found
        if action.target_id and action.target_id in self.state.players:
            checked = self.state.players[action.target_id]
            self._observe_role(Role.SEER, f"你查验了 {checked.name}，身份是{checked.role.value}")
        return action

    async def _do_witch(self) -> dict | None:
        pid = self._find_role_player(Role.WITCH)
        if not pid:
            return None

        self.state.phase = Phase.NIGHT_WITCH
        await self._notify_state()

        wolf_actions = [a for a in self.state.night_actions
                        if a.action_type == ActionType.KILL
                        and a.phase == Phase.NIGHT_WEREWOLF]
        wolf_target = wolf_actions[-1].target_id if wolf_actions else None
        self.state.night_victim = wolf_target

        result = await self._act_or_wait(pid, Phase.NIGHT_WITCH, "witch")
        # Normalize poison target
        if result and result.get("poison_target"):
            result["poison_target"] = self._resolve_target(result["poison_target"])
        self.state.night_victim = None
        self._log("witch_decide", actor=pid, result=result)
        return result

    def _resolve_night_and_apply(self, guard_action, wolf_action, seer_action, witch_result):
        wolf_target = wolf_action.target_id if wolf_action else None
        guard_target = guard_action.target_id if guard_action else None
        seer_target = seer_action.target_id if seer_action else None

        guard_blocked = False
        if guard_target and guard_action:
            guard_pid = guard_action.actor_id
            guard_player = self.state.players.get(guard_pid)
            if guard_player and guard_player.last_protected_id == guard_target:
                guard_blocked = True
            elif guard_player:
                guard_player.last_protected_id = guard_target

        seer_role = None
        if seer_target and seer_target in self.state.players:
            seer_role = self.state.players[seer_target].role

        heal = False
        poison_target = None
        if witch_result and "heal" in witch_result:
            heal = witch_result.get("heal", False)
            poison_target = witch_result.get("poison_target")
            witch_player = next(
                (p for p in self.state.players.values()
                 if p.role == Role.WITCH and p.is_alive), None
            )
            if witch_player:
                if heal and witch_player.has_heal_potion:
                    witch_player.has_heal_potion = False
                if poison_target and witch_player.has_poison_potion:
                    witch_player.has_poison_potion = False
                    self.state.night_actions.append(Action(
                        actor_id=witch_player.id,
                        action_type=ActionType.POISON,
                        target_id=poison_target,
                        phase=Phase.NIGHT_WITCH,
                        round_number=self.state.round_number,
                    ))

        resolution = resolve_night(
            wolf_target=wolf_target, guard_target=guard_target,
            seer_target=seer_target, seer_result=seer_role,
            witch_heal=wolf_target if heal else None,
            witch_poison=poison_target, guard_blocked=guard_blocked,
        )

        night_deaths = []
        for death in resolution.deaths:
            pid = death.player_id
            if pid in self.state.players:
                player = self.state.players[pid]
                death.role = player.role
                player.is_alive = False
                night_deaths.append(death)

        self.state.public_state.night_deaths = night_deaths
        self._log("night_resolution", deaths=[d.model_dump(mode='json') for d in night_deaths])

        # Timeline events
        if night_deaths:
            for d in night_deaths:
                victim = self.state.players.get(d.player_id)
                self._push_timeline("💀", "夜间死亡", f"{victim.name if victim else '?'}({d.cause})")
        else:
            self._push_timeline("☀️", "平安夜", "无人死亡")

        # Record events in agent memory
        for d in night_deaths:
            victim = self.state.players.get(d.player_id)
            victim_name = victim.name if victim else d.player_id
            self._observe_all(f"{victim_name} 于夜晚死亡(原因:{d.cause})")
        if resolution.protected:
            self._observe_role(Role.GUARD, f"你的守护挡住了狼人的攻击")
        if resolution.healed:
            victim = self.state.players.get(wolf_target) if wolf_target else None
            self._observe_role(Role.WITCH, f"你使用解药救了{victim.name}" if victim else "你使用了救药")
        if wolf_target and not resolution.protected and not resolution.healed:
            victim = self.state.players.get(wolf_target)
            victim_name = victim.name if victim else wolf_target
            self._observe_role(Role.WEREWOLF, f"狼队成功击杀了 {victim_name}")
        if poison_target:
            victim = self.state.players.get(poison_target)
            self._observe_role(Role.WITCH, f"你使用毒药毒杀了 {victim.name if victim else poison_target}")

    # ── day phases ─────────────────────────────────────────

    async def _run_day_phases(self):
        # DAY_BREAK
        self.state.phase = Phase.DAY_BREAK
        await self._notify_state()
        await self._check_win_and_maybe_end()
        if self.phase_machine.is_game_over:
            return

        # DAY_DISCUSSION
        self.state.phase = Phase.DAY_DISCUSSION
        await self._notify_state()
        await self._do_discussion()

        # DAY_VOTE
        self.state.phase = Phase.DAY_VOTE
        await self._notify_state()
        eliminated_id = await self._do_vote()

        # DAY_TRIAL + EXECUTION
        if eliminated_id and eliminated_id in self.state.players:
            self.state.phase = Phase.DAY_TRIAL
            await self._notify_state()
            agent = self.agents.get(eliminated_id)
            if agent:
                last_words = await agent.speak(Phase.DAY_TRIAL, self.state)
                content = last_words.get("content", "我是无辜的。")
                self.state.public_state.chat_log.append(ChatMessage(
                    id=str(uuid.uuid4())[:8],
                    speaker_id=eliminated_id,
                    speaker_name=self.state.players[eliminated_id].name,
                    content=content,
                    phase=Phase.DAY_TRIAL,
                    round_number=self.state.round_number,
                ))

            self.state.phase = Phase.DAY_EXECUTION
            self._execute_player(eliminated_id, "vote")
            await self._notify_state()

        # DEATH_ACTIVATION
        await self._handle_hunter_death()
        if self.phase_machine.is_game_over:
            return

        # WIN_CHECK
        await self._check_win_and_maybe_end()

    async def _do_discussion(self):
        alive = [p for p in self.state.player_order if self.state.players[p].is_alive]
        total = len(alive)

        for _ in range(self.config.max_discussion_rounds):
            for idx, pid in enumerate(alive):
                if not self.state.players[pid].is_alive:
                    continue
                self.state.current_speaker_index = idx
                self.state.public_state.current_speaker = self.state.players[pid].name
                self.state.public_state.speaker_index = idx + 1
                self.state.public_state.total_speakers = total
                await self._notify_state()

                player = self.state.players[pid]
                agent = self.agents.get(pid)

                if agent:
                    result = await agent.speak(Phase.DAY_DISCUSSION, self.state)
                    content = result.get("content", f"我是{player.name}，我觉得需要更多信息。")
                    intent = result.get("intent", "neutral")
                    msg = ChatMessage(
                        id=str(uuid.uuid4())[:8],
                        speaker_id=pid, speaker_name=player.name,
                        content=content, phase=Phase.DAY_DISCUSSION,
                        round_number=self.state.round_number,
                    )
                    self.state.public_state.chat_log.append(msg)
                    self._log("speech", speaker=pid, content=content, intent=intent)
                elif player.is_human:
                    # Wait for human to type their speech
                    print(f"[ENGINE] DISCUSSION: waiting for human {pid} ({player.name}) to speak...")
                    result = await self._wait_for_human(pid, timeout=120)
                    if result:
                        print(f"[ENGINE] DISCUSSION: human {pid} spoke: {result.get('content', '')[:50]}")
                    else:
                        print(f"[ENGINE] DISCUSSION: human {pid} timed out (skipping turn)")
                    await self._notify_state()

    async def _do_vote(self) -> str | None:
        votes: dict[str, str] = {}

        async def _one_vote(pid: str) -> tuple[str, str] | None:
            player = self.state.players.get(pid)
            if not player or not player.can_vote:
                return None

            agent = self.agents.get(pid)
            if agent:
                result = await agent.vote(Phase.DAY_VOTE, self.state)
                vote_for = result.get("vote_for", "abstain")
                if vote_for != "abstain":
                    vote_for = self._resolve_target(vote_for) or vote_for
                self._log("vote", voter=pid, target=vote_for)
                return (pid, vote_for)
            elif player.is_human:
                action = await self._wait_for_human(pid, timeout=60)
                if action:
                    vote_for = action.get("target", "abstain")
                    if vote_for != "abstain":
                        vote_for = self._resolve_target(vote_for) or vote_for
                    self._log("vote", voter=pid, target=vote_for)
                    return (pid, vote_for)
            return None

        tasks = [_one_vote(pid) for pid in self.state.get_alive_player_ids()]
        results = await asyncio.gather(*tasks)
        for r in results:
            if r:
                pid, target = r
                votes[pid] = target

        result = tally_votes(votes, self.state)
        self.state.public_state.vote_results = result

        # Record vote outcome
        if result.eliminated_id:
            eliminated = self.state.players.get(result.eliminated_id)
            if eliminated:
                vote_count = max(result.votes.values(), default=0)
                self._observe_all(f"投票结果: {eliminated.name} 被放逐({vote_count}票)")
                self._push_timeline("🗳️", "投票放逐", f"{eliminated.name}({vote_count}票)")
        return result.eliminated_id

    def _execute_player(self, player_id: str, cause: str):
        player = self.state.players.get(player_id)
        if player is None:
            return
        player.is_alive = False
        self._log("player_death", player_id=player_id, role=player.role.value, cause=cause)
        death = NightDeath(player_id=player_id, cause=cause, role=player.role)
        self.state.public_state.night_deaths = [death]
        self._observe_all(f"{player.name} 被{'投票放逐' if cause == 'vote' else '处决'}，身份是{player.role.value}")

    async def _handle_hunter_death(self):
        self.state.phase = Phase.DEATH_ACTIVATION
        dead_hunters = [
            p for p in self.state.players.values()
            if not p.is_alive and p.role == Role.HUNTER and p.can_shoot
        ]
        for hunter in dead_hunters:
            result = await self._act_or_wait(hunter.id, Phase.DEATH_ACTIVATION, "shoot")
            if not result:
                continue
            target = self._resolve_target(result.get("target", ""))
            if target and target in self.state.players and self.state.players[target].is_alive:
                self.state.players[target].is_alive = False
                hunter.can_shoot = False
                target_name = self.state.players[target].name
                self._observe_all(f"{hunter.name}(猎人) 死亡时开枪带走了 {target_name}")
                self._log("hunter_shoot", hunter=hunter.id, target=target)
                await self._check_win_and_maybe_end()

    async def _check_win_and_maybe_end(self):
        winner = check_win(self.state)
        if winner:
            self.state.public_state.winner = winner
            self._log("game_over", winner=winner.value)
            self.phase_machine.transition(Phase.GAME_OVER)

    def _push_timeline(self, icon: str, label: str, detail: str = ""):
        from app.models.game import TimelineEvent
        self.state.public_state.timeline.append(TimelineEvent(
            round_number=self.state.round_number,
            phase=self.state.phase,
            icon=icon, label=label, detail=detail,
        ))

    def _log(self, event_type: str, **kwargs):
        if self._logger:
            self._logger.log(event_type, **kwargs)
