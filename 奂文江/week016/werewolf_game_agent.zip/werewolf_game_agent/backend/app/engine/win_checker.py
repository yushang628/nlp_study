from app.models.enums import Role, Team
from app.models.game import GameState


def check_win(state: GameState) -> Team | None:
    alive_wolves = [p for p in state.players.values() if p.is_alive and p.role == Role.WEREWOLF]
    alive_villagers = [p for p in state.players.values() if p.is_alive and p.team == Team.VILLAGER]

    if len(alive_wolves) == 0:
        return Team.VILLAGER

    if len(alive_wolves) >= len(alive_villagers):
        return Team.WEREWOLF

    return None
