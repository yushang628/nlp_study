import random
from collections import Counter

from app.models.game import VoteResult, GameState


def tally_votes(votes: dict[str, str], state: GameState) -> VoteResult:
    """
    Count votes from alive players.
    votes: voter_id -> target_id (or "abstain" to skip)
    """
    valid_votes: dict[str, str] = {}
    target_counts: Counter[str] = Counter()

    alive_ids = state.get_alive_player_ids()

    for voter_id, target_id in votes.items():
        player = state.players.get(voter_id)
        if player is None or not player.is_alive or not player.can_vote:
            continue
        if target_id == "abstain":
            continue
        if target_id not in alive_ids:
            continue
        valid_votes[voter_id] = target_id
        target_counts[target_id] += 1

    result = VoteResult(votes=valid_votes)

    if not target_counts:
        return result

    max_count = max(target_counts.values())
    top_targets = [t for t, c in target_counts.items() if c == max_count]

    if len(top_targets) == 1:
        result.eliminated_id = top_targets[0]
    else:
        result.was_tie = True
        result.eliminated_id = random.choice(top_targets)

    return result
