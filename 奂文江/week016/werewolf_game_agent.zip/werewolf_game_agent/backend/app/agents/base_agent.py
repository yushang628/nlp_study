"""Abstract base agent with LLM integration — compatible with OpenAI and DeepSeek."""

import json
import os
import sys
from abc import ABC

from openai import AsyncOpenAI

from app.models.enums import Role, Team, Phase, ActionType
from app.models.actions import Action
from app.agents.prompt_manager import build_system_prompt, build_action_prompt
from app.agents.info_filter import build_observation
from app.agents.schema_defs import get_schema_config
from app.config import OPENAI_API_KEY as _CFG_KEY, OPENAI_MODEL as _CFG_MODEL, OPENAI_BASE_URL as _CFG_URL


def _safe_json_parse(raw: str) -> dict:
    """Parse JSON, gracefully handling truncated/incomplete responses."""
    import json
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # Try to fix truncated JSON by adding missing closing characters
    fixed = raw.rstrip()
    # Count unclosed braces
    open_braces = fixed.count("{") - fixed.count("}")
    open_brackets = fixed.count("[") - fixed.count("]")
    # If last char inside a string, close the string
    in_string = False
    for ch in fixed:
        if ch == '"':
            in_string = not in_string
    if in_string:
        fixed += '"'
    # Close remaining braces/brackets
    fixed += "}" * open_braces
    fixed += "]" * open_brackets

    try:
        return json.loads(fixed)
    except json.JSONDecodeError:
        pass

    # Extract whatever fields we can with regex
    import re
    result = {}
    for field in ["target", "vote_for", "content", "reasoning", "intent", "heal"]:
        m = re.search(rf'"{field}"\s*:\s*"([^"]*)', fixed)
        if m:
            result[field] = m.group(1)
    if not result:
        return {"error": "JSON parse failed", "content": fixed[:100]}
    return result


class BaseAgent(ABC):
    role: Role
    team: Team

    def __init__(self, player_id: str, name: str, role: Role, model: str | None = None):
        self.player_id = player_id
        self.name = name
        self._role = role
        self._team = Team.WEREWOLF if role == Role.WEREWOLF else Team.VILLAGER
        self.model = model or os.getenv("OPENAI_MODEL") or _CFG_MODEL or "gpt-4o"
        self._memory: list[dict] = []
        self._client = AsyncOpenAI(
            api_key=os.getenv("OPENAI_API_KEY") or _CFG_KEY or "",
            base_url=os.getenv("OPENAI_BASE_URL") or _CFG_URL or None,
        )

    def observe(self, event: str):
        """Record a game event in agent memory."""
        self._memory.append(event)
        if len(self._memory) > 30:
            self._memory = self._memory[-20:]

    async def decide(
        self,
        phase: Phase,
        action_key: str,
        game_state,  # GameState
    ) -> dict:
        """Core LLM decision pipeline."""
        observation = build_observation(game_state, self.player_id, self._memory)
        system_prompt = build_system_prompt(self._role, self.name, phase, observation)
        action_instruction = build_action_prompt(phase, self._role, observation)
        schema_config = get_schema_config(action_key)

        # Inject JSON format instruction into the prompt (DeepSeek compatible)
        full_user_prompt = f"""{action_instruction}

{schema_config['instruction']}

请严格按JSON格式回复，不要输出其他内容。"""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": full_user_prompt},
        ]

        try:
            response = await self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                response_format=schema_config["response_format"],
                temperature=0.7,
                max_tokens=600,
                timeout=30.0,
            )

            content = response.choices[0].message.content or "{}"
            # Handle truncated JSON: try to close unclosed braces/strings
            result = _safe_json_parse(content)
            return result

        except Exception as e:
            print(f"[Agent {self.name}] LLM error: {e}", file=sys.stderr)
            return {"error": str(e), "reasoning": "API call failed"}

    async def act(self, phase: Phase, action_key: str, game_state) -> Action:
        result = await self.decide(phase, action_key, game_state)

        return Action(
            actor_id=self.player_id,
            action_type=self._action_type_for_key(action_key),
            target_id=result.get("target") or result.get("vote_for"),
            phase=phase,
            round_number=game_state.round_number,
            reasoning=result.get("reasoning", ""),
        )

    async def speak(self, phase: Phase, game_state) -> dict:
        return await self.decide(phase, "speak", game_state)

    async def vote(self, phase: Phase, game_state) -> dict:
        return await self.decide(phase, "vote", game_state)

    @staticmethod
    def _action_type_for_key(key: str) -> ActionType:
        mapping = {
            "kill": ActionType.KILL,
            "protect": ActionType.PROTECT,
            "check": ActionType.CHECK,
            "witch": ActionType.POISON,
            "vote": ActionType.VOTE,
            "speak": ActionType.SPEAK,
            "shoot": ActionType.SHOOT,
        }
        return mapping.get(key, ActionType.SPEAK)
