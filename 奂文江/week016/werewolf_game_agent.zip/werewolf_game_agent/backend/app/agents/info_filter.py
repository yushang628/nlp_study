"""Information isolation: filters game state per player role."""

from app.models.enums import Role
from app.models.game import GameState


def build_observation(
    state: GameState,
    player_id: str,
    memory: list[str] | None = None,
) -> dict:
    """Return only the information this player should see."""
    player = state.players[player_id]
    role = player.role

    base = {
        "my_player_id": player_id,
        "my_name": player.name,
        "my_role": role.value,
        "my_team": player.team.value,
        "phase": state.phase.value,
        "round_number": state.round_number,
        "alive_players": [
            _public(p) for p in state.players.values() if p.is_alive
        ],
        "dead_players": [
            _public(p) for p in state.players.values() if not p.is_alive
        ],
        "public_chat": [
            {"speaker": m.speaker_name, "content": m.content}
            for m in state.public_state.chat_log[-20:]
        ],
        "night_deaths_this_round": [
            {"player_id": d.player_id, "cause": d.cause}
            for d in state.public_state.night_deaths
        ],
        "recent_events": memory[-10:] if memory else [],
    }

    # Werewolf: knows pack members
    if role == Role.WEREWOLF:
        base["fellow_werewolves"] = [
            p.name for p in state.players.values()
            if p.role == Role.WEREWOLF and p.id != player_id and p.is_alive
        ]

    # Seer: knows check history
    if role == Role.SEER:
        base["seer_checks"] = state.seer_checks.get(player_id, [])

    # Witch: knows potion status and victim
    if role == Role.WITCH:
        base["has_heal_potion"] = player.has_heal_potion
        base["has_poison_potion"] = player.has_poison_potion
        if state.night_victim:
            victim = state.players.get(state.night_victim)
            base["night_victim"] = {
                "id": state.night_victim,
                "name": victim.name if victim else "?",
            }

    # Guard: knows last protected
    if role == Role.GUARD:
        base["last_protected"] = player.last_protected_id

    return base


def _public(p) -> dict:
    return {
        "id": p.id,
        "name": p.name,
        "is_alive": p.is_alive,
        "is_human": p.is_human,
        "seat_number": p.seat_number,
        "can_vote": p.can_vote,
    }
