"""JSON schemas for structured output. Uses json_object (compatible with DeepSeek)."""

# Simple json_object format — DeepSeek compatible
# Each schema has a `format_instruction` that gets injected into the prompt

SCHEMAS = {
    "kill": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"target": "player_id", "reasoning": "选择理由"}
target 必须是存活玩家的 id。""",
    },
    "protect": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"target": "player_id", "reasoning": "选择理由"}
target 必须是存活玩家的 id，不能连续两晚守护同一人。""",
    },
    "check": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"target": "player_id", "reasoning": "选择理由"}
target 必须是存活玩家的 id。""",
    },
    "witch": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"heal": false, "poison_target": null, "reasoning": "决策理由"}
heal 为 true/false（是否用解药），poison_target 为玩家id或null（是否用毒药）。""",
    },
    "vote": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"vote_for": "player_id", "reasoning": "投票理由"}
vote_for 填玩家 id，或填 "abstain" 表示弃权。""",
    },
    "speak": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"content": "你的发言内容", "intent": "accuse/defend/question/inform/neutral"}
intent: accuse=指控某人, defend=为某人辩护, question=提问, inform=提供信息, neutral=中立发言""",
    },
    "shoot": {
        "response_format": {"type": "json_object"},
        "instruction": """回复格式（严格JSON）：
{"target": "player_id", "reasoning": "选择理由"}
你即将死亡，请选择一名存活玩家开枪带走。""",
    },
}


def get_schema_config(action_key: str) -> dict:
    """Return {response_format, instruction} for an action key."""
    return SCHEMAS.get(action_key, {
        "response_format": {"type": "json_object"},
        "instruction": "请以JSON格式回复。",
    })
