"""Role-specific agent implementations."""

from app.models.enums import Role, Phase, ActionType
from app.models.actions import Action
from app.agents.base_agent import BaseAgent


class WerewolfAgent(BaseAgent):
    role = Role.WEREWOLF


class VillagerAgent(BaseAgent):
    role = Role.VILLAGER


class SeerAgent(BaseAgent):
    role = Role.SEER


class WitchAgent(BaseAgent):
    role = Role.WITCH


class HunterAgent(BaseAgent):
    role = Role.HUNTER


class GuardAgent(BaseAgent):
    role = Role.GUARD


def create_agent(player_id: str, name: str, role: Role, model: str = "gpt-4o") -> BaseAgent:
    agent_cls = {
        Role.WEREWOLF: WerewolfAgent,
        Role.VILLAGER: VillagerAgent,
        Role.SEER: SeerAgent,
        Role.WITCH: WitchAgent,
        Role.HUNTER: HunterAgent,
        Role.GUARD: GuardAgent,
    }
    cls = agent_cls.get(role, VillagerAgent)
    return cls(player_id=player_id, name=name, role=role, model=model)
