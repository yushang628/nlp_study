"""System prompt construction for each role and phase."""

from app.models.enums import Role, Phase, ROLE_NAMES


def _role_identity(role: Role, player_name: str) -> str:
    name = ROLE_NAMES.get(role, role.value)
    return f"""=== 你的身份 ===
玩家名称：{player_name}
你的角色：{name}（{role.value}）
阵营：{'狼人阵营' if role == Role.WEREWOLF else '好人阵营'}
"""


GAME_RULES = """=== 游戏规则 ===
- 12人局：4狼人、4村民、1预言家、1女巫、1猎人、1守卫
- 夜晚顺序：守卫守护 → 狼人刀人 → 预言家查验 → 女巫用药
- 白天：所有存活玩家依次发言，然后投票放逐一名玩家
- 狼人胜利条件：存活狼人数 >= 存活好人数
- 好人胜利条件：所有狼人被消灭
- 女巫有一瓶解药（救人）和一瓶毒药（杀人），整局各用一次
- 守卫不能连续两晚守护同一人
- 猎人死亡时可以开枪带走一名玩家
"""


ROLE_STRATEGIES: dict[Role, str] = {
    Role.WEREWOLF: """=== 狼人策略 ===
- 你是狼人，目标是消灭所有好人而不被发现
- 夜晚：与同伴商量选择击杀目标，优先击杀预言家、女巫等关键角色
- 白天：伪装成村民，发表合理的推理，误导好人的判断
- 可以适当指控好人来转移视线，但不要过于激进暴露自己
- 注意听其他玩家的发言，寻找可以利用的矛盾点""",

    Role.VILLAGER: """=== 村民策略 ===
- 你是普通村民，没有特殊能力，唯一的武器是推理和投票
- 认真听取每个人的发言，寻找逻辑漏洞和矛盾
- 注意观察谁在引导舆论、谁在回避关键问题
- 投票时基于事实和逻辑，不要盲从
- 积极发言，帮助好人阵营理清局势""",

    Role.SEER: """=== 预言家策略 ===
- 你是预言家，每晚可以查验一名玩家的真实身份
- 谨慎选择查验目标：优先查发言可疑的玩家
- 如果查到狼人，在合适时机公开你的查验结果
- 不要过早暴露自己是预言家，否则会成为狼人的首要目标
- 如果被怀疑，可以适时公布身份来证明清白""",

    Role.WITCH: """=== 女巫策略 ===
- 你是女巫，拥有一瓶解药和一瓶毒药
- 解药：可以救活当夜被狼人击杀的玩家（第一晚一般建议救人）
- 毒药：可以毒杀一名玩家（谨慎使用，确认对方是狼才能用）
- 你会在夜晚得知谁被狼人袭击了
- 隐藏自己的身份，女巫是好人的重要武器""",

    Role.HUNTER: """=== 猎人策略 ===
- 你是猎人，死亡时可以开枪带走一名玩家
- 白天正常参与讨论和投票
- 如果被投票放逐或夜晚被杀，选择你最怀疑的玩家开枪
- 你的子弹很珍贵——尽量确认目标后再开枪
- 注意观察，在关键时刻亮出身份可能会改变局势""",

    Role.GUARD: """=== 守卫策略 ===
- 你是守卫，每晚可以守护一名玩家免于狼人袭击
- 不能连续两晚守护同一人
- 优先守护预言家、女巫等关键角色
- 预判狼人的击杀目标来做出有效守护
- 不要过早暴露自己是守卫，默默守护好人是你的职责""",
}


def build_system_prompt(
    role: Role,
    player_name: str,
    phase: Phase,
    observation: dict,
) -> str:
    parts = [
        "你正在玩一局狼人杀游戏。你的身份是保密的——除非游戏规则要求，否则绝不要公开透露你的角色。",
        _role_identity(role, player_name),
        GAME_RULES,
        ROLE_STRATEGIES.get(role, ""),
        f"=== 当前游戏状态 ===\n当前阶段：{phase.value}\n"
        f"第 {observation.get('round_number', 0)} 轮\n",
    ]

    if role == Role.WEREWOLF:
        allies = observation.get("fellow_werewolves", [])
        if allies:
            parts.append(f"你的狼队友：{', '.join(allies)}")

    if role == Role.WITCH:
        parts.append(f"解药：{'有' if observation.get('has_heal_potion') else '已用完'}")
        parts.append(f"毒药：{'有' if observation.get('has_poison_potion') else '已用完'}")

    parts.append(f"\n存活玩家：{', '.join(p['name'] for p in observation.get('alive_players', []))}")

    dead = observation.get("dead_players", [])
    if dead:
        parts.append(f"已死亡玩家：{', '.join(p['name'] for p in dead)}")

    chat = observation.get("public_chat", [])
    if chat:
        parts.append("\n=== 最近发言 ===")
        for m in chat[-10:]:
            parts.append(f"{m['speaker']}: {m['content']}")

    deaths = observation.get("night_deaths_this_round", [])
    if deaths:
        parts.append(f"\n昨晚死亡：{deaths}")

    events = observation.get("recent_events", [])
    if events:
        parts.append("\n=== 近期事件 ===")
        for e in events[-8:]:
            parts.append(f"- {e}")

    return "\n".join(parts)


def build_action_prompt(phase: Phase, role: Role, observation: dict) -> str:
    """Return the specific instruction for the current phase."""
    if phase == Phase.NIGHT_WITCH:
        victim = observation.get("night_victim", {})
        victim_name = victim.get("name", "未知") if victim else "无人"
        return f"今晚狼人袭击了【{victim_name}】！请决定是否使用解药救人（heal: true/false），以及是否使用毒药毒杀另一名玩家（poison_target: 玩家id 或 null）。"

    prompts = {
        Phase.NIGHT_GUARD: "请选择今晚要守护的玩家。不能连续守护同一人。",
        Phase.NIGHT_WEREWOLF: "请与其他狼人商议后，选择今晚要击杀的目标。",
        Phase.NIGHT_SEER: "请选择今晚要查验身份的玩家。",
        Phase.DAY_DISCUSSION: "轮到你发言了。基于你已知的信息和之前的讨论，发表你的观点。",
        Phase.DAY_VOTE: "请投票选择你认为应该被放逐的玩家（输入玩家名称或 'abstain' 表示弃权）。",
        Phase.DAY_TRIAL: "你是被投票选出的嫌疑人，请做最后陈述为自己辩护。",
        Phase.DEATH_ACTIVATION: "你即将死亡，请选择一名玩家开枪带走。",
    }
    return prompts.get(phase, "请根据你的角色和当前局势做出决策。")
