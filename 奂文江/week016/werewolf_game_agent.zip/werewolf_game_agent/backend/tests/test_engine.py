"""Unit tests for game engine components (no LLM calls)."""

import pytest
from app.models.enums import Role, Team, Phase
from app.models.player import Player, PlayerPublic
from app.models.game import GameState, GameConfig, GamePublicState
from app.models.actions import Action, NightDeath, ActionType

from app.engine.phase_machine import PhaseMachine
from app.engine.action_resolver import resolve_night
from app.engine.vote_manager import tally_votes
from app.engine.win_checker import check_win


def _make_player(pid: str, name: str, role: Role, alive: bool = True) -> Player:
    return Player(
        id=pid, name=name, role=role,
        team=Team.for_role(role),
        seat_number=int(pid.split("_")[1]) if "_" in pid else 1,
        is_alive=alive,
    )


def _make_state(players: list[Player]) -> GameState:
    state = GameState()
    for p in players:
        state.players[p.id] = p
        state.player_order.append(p.id)
    return state


# ── Phase Machine ──────────────────────────────────────────

def test_phase_order():
    pm = PhaseMachine(Phase.LOBBY)
    assert pm.current == Phase.LOBBY
    pm.next()
    assert pm.current == Phase.NIGHT_GUARD


def test_night_day_detection():
    pm = PhaseMachine(Phase.NIGHT_WEREWOLF)
    assert pm.is_night()
    assert not pm.is_day()
    pm.transition(Phase.DAY_DISCUSSION)
    assert pm.is_day()
    assert not pm.is_night()


def test_next_after_each_phase():
    pm = PhaseMachine()
    pm.transition(Phase.NIGHT_WITCH)
    assert pm.next_after(Phase.NIGHT_WITCH) == Phase.DAY_BREAK
    assert pm.next_after(Phase.WIN_CHECK) == Phase.GAME_OVER


# ── Action Resolver ────────────────────────────────────────

def test_wolf_kill_succeeds():
    r = resolve_night("p1", None, None, None, None, None, False)
    assert len(r.deaths) == 1
    assert r.deaths[0].player_id == "p1"
    assert r.deaths[0].cause == "werewolf"


def test_guard_blocks_wolf():
    r = resolve_night("p1", "p1", None, None, None, None, False)
    assert len(r.deaths) == 0
    assert r.protected is True


def test_guard_repeat_blocked():
    r = resolve_night("p1", "p1", None, None, None, None, True)
    assert len(r.deaths) == 1  # guard is blocked, wolf kills


def test_witch_heal_saves():
    r = resolve_night("p1", None, None, None, "p1", None, False)
    assert len(r.deaths) == 0
    assert r.healed is True


def test_witch_poison_kills():
    r = resolve_night(None, None, None, None, None, "p2", False)
    assert len(r.deaths) == 1
    assert r.deaths[0].cause == "witch_poison"


def test_guard_and_heal_both_apply():
    r = resolve_night("p1", "p1", None, None, "p1", "p3", False)
    assert len(r.deaths) == 1  # only poison kills
    assert r.deaths[0].player_id == "p3"


# ── Vote Manager ───────────────────────────────────────────

def test_simple_majority():
    state = _make_state([
        _make_player("p1", "A", Role.VILLAGER),
        _make_player("p2", "B", Role.WEREWOLF),
        _make_player("p3", "C", Role.VILLAGER),
    ])
    votes = {"p1": "p2", "p2": "p1", "p3": "p2"}
    result = tally_votes(votes, state)
    assert result.eliminated_id == "p2"


def test_tie_random_resolve():
    state = _make_state([
        _make_player("p1", "A", Role.VILLAGER),
        _make_player("p2", "B", Role.WEREWOLF),
    ])
    votes = {"p1": "p2", "p2": "p1"}
    result = tally_votes(votes, state)
    assert result.was_tie
    assert result.eliminated_id in ("p1", "p2")


def test_abstain_ignored():
    state = _make_state([
        _make_player("p1", "A", Role.VILLAGER),
        _make_player("p2", "B", Role.WEREWOLF),
        _make_player("p3", "C", Role.VILLAGER),
    ])
    votes = {"p1": "p2", "p2": "abstain", "p3": "p2"}
    result = tally_votes(votes, state)
    assert result.eliminated_id == "p2"


# ── Win Checker ────────────────────────────────────────────

def test_villagers_win_all_wolves_dead():
    state = _make_state([
        _make_player("p1", "A", Role.VILLAGER),
        _make_player("p2", "B", Role.WEREWOLF, alive=False),
        _make_player("p3", "C", Role.SEER),
    ])
    assert check_win(state) == Team.VILLAGER


def test_wolves_win_numbers_equal():
    state = _make_state([
        _make_player("p1", "A", Role.WEREWOLF),
        _make_player("p2", "B", Role.WEREWOLF),
        _make_player("p3", "C", Role.VILLAGER),
        _make_player("p4", "D", Role.VILLAGER),
    ])
    assert check_win(state) == Team.WEREWOLF


def test_no_winner_yet():
    state = _make_state([
        _make_player("p1", "A", Role.WEREWOLF),
        _make_player("p2", "B", Role.VILLAGER),
        _make_player("p3", "C", Role.VILLAGER),
        _make_player("p4", "D", Role.SEER),
    ])
    assert check_win(state) is None


# ── Serialization ─────────────────────────────────────────

def test_chat_message_serialization():
    from app.models.messages import ChatMessage
    from app.models.enums import Phase
    from datetime import datetime

    msg = ChatMessage(
        id="test1",
        speaker_id="p1",
        speaker_name="玩家1",
        content="我觉得玩家3很可疑",
        phase=Phase.DAY_DISCUSSION,
        round_number=1,
    )
    data = msg.model_dump()
    assert data["speaker_name"] == "玩家1"
    assert data["content"] == "我觉得玩家3很可疑"
    assert "timestamp" in data


def test_game_public_state_serialization():
    from app.models.game import GamePublicState, VoteResult
    from app.models.messages import ChatMessage
    from app.models.enums import Phase
    from app.models.player import PlayerPublic

    ps = GamePublicState(
        phase=Phase.DAY_DISCUSSION,
        round_number=1,
        players=[PlayerPublic(id="p1", name="玩家1", is_alive=True, is_human=True, seat_number=1, can_vote=True)],
        chat_log=[
            ChatMessage(id="m1", speaker_id="p1", speaker_name="玩家1", content="大家好", phase=Phase.DAY_DISCUSSION, round_number=1),
            ChatMessage(id="m2", speaker_id="p2", speaker_name="玩家2", content="我怀疑玩家3", phase=Phase.DAY_DISCUSSION, round_number=1),
        ],
        current_speaker="玩家2",
        speaker_index=2,
        total_speakers=10,
    )
    data = ps.model_dump()
    assert len(data["chat_log"]) == 2
    assert data["chat_log"][0]["speaker_name"] == "玩家1"
    assert data["current_speaker"] == "玩家2"
