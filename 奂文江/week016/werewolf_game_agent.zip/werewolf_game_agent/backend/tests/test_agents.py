"""Tests for agent info filter and prompt construction (no LLM calls)."""

from app.models.enums import Role, Team, Phase
from app.models.player import Player
from app.models.game import GameState
from app.agents.info_filter import build_observation


def _make_state_with_roles(roles: dict[str, Role]) -> GameState:
    state = GameState()
    for pid, role in roles.items():
        state.players[pid] = Player(
            id=pid, name=pid, role=role,
            team=Team.for_role(role),
            seat_number=1,
        )
    return state


def test_werewolf_sees_allies():
    state = _make_state_with_roles({
        "p1": Role.WEREWOLF,
        "p2": Role.WEREWOLF,
        "p3": Role.VILLAGER,
        "p4": Role.SEER,
    })
    obs = build_observation(state, "p1")
    assert "p2" in obs.get("fellow_werewolves", [])


def test_villager_sees_no_allies():
    state = _make_state_with_roles({
        "p1": Role.VILLAGER,
        "p2": Role.WEREWOLF,
        "p3": Role.WEREWOLF,
    })
    obs = build_observation(state, "p1")
    assert obs.get("fellow_werewolves") is None


def test_seer_does_not_see_wolves():
    state = _make_state_with_roles({
        "p1": Role.SEER,
        "p2": Role.WEREWOLF,
        "p3": Role.VILLAGER,
    })
    obs = build_observation(state, "p1")
    assert obs.get("fellow_werewolves") is None


def test_witch_sees_potions():
    state = _make_state_with_roles({"p1": Role.WITCH, "p2": Role.WEREWOLF})
    obs = build_observation(state, "p1")
    assert obs["has_heal_potion"] is True
    assert obs["has_poison_potion"] is True


def test_my_role_included():
    state = _make_state_with_roles({"p1": Role.SEER, "p2": Role.WEREWOLF})
    obs = build_observation(state, "p1")
    assert obs["my_role"] == "seer"
    assert obs["my_team"] == "villager"


def test_dead_players_listed():
    state = _make_state_with_roles({"p1": Role.VILLAGER, "p2": Role.WEREWOLF})
    state.players["p2"].is_alive = False
    obs = build_observation(state, "p1")
    assert len(obs["alive_players"]) == 1
    assert len(obs["dead_players"]) == 1


def test_guard_sees_last_protection():
    state = _make_state_with_roles({"p1": Role.GUARD, "p2": Role.WEREWOLF})
    state.players["p1"].last_protected_id = "p3"
    obs = build_observation(state, "p1")
    assert obs["last_protected"] == "p3"
